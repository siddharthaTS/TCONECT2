module.exports = {
	loginPage: async (ctx) => {
		if (ctx.session.userId) {
			return ctx.redirect("/home.html");
		}
		ctx.set("Cache-Control", "no-cache, no-store, must-revalidate");
		var data = {
			title: icplApp.appDisplayName + " | Login",
			appName: icplApp.appDisplayName,
		};
		return ctx.renderView("login", data);
	},
	home: async (ctx) => {
		const data = {title: icplApp.appDisplayName, viewName: "Home"};
		if (!ctx.session.userId) {
			return ctx.redirect("/login.html");
		} else {
			const model = require("../models/user")(ctx);
			const result = await model.details({_id: ctx.ObjectID(ctx.session.userId)}, {privileges: 1, _id: 0});
			data.privileges = result.doc.privileges;
			if (!result.status) {
				delete ctx.session.userId;
				return ctx.redirect("/login.html");
			}
		}
		ctx.set("Cache-Control", "no-cache, no-store, must-revalidate");
		return ctx.renderView("home", data);
	},
	myProfile: async (ctx) => {
		const data = {
			title: icplApp.appDisplayName,
			viewName: "My Profile",
			scriptPath: "/prod/js/views/myProfile.js",
		};
		if (!ctx.session.userId) {
			return ctx.redirect("/login.html");
		} else {
			const model = require("../models/user")(ctx);
			const result = await model.details({_id: ctx.ObjectID(ctx.session.userId)}, {userName: 1, userEmail: 1, contactNumber: 1, privileges: 1, _id: 0});
			data.privileges = result.doc.privileges;
			if (!result.status) {
				delete ctx.session.userId;
				return ctx.redirect("/login.html");
			}
			delete result.doc.privileges;
			data.currentUser = result.doc;
			data.currentUserId = ctx.session.userId;
			ctx.set("Cache-Control", "no-cache, no-store, must-revalidate");
			return ctx.renderView("myProfile", data);
		}
	},
	userManagement: async (ctx) => {
		const data = {
			title: icplApp.appDisplayName + " | User Management",
			viewName: "Users",
			scriptPath: "/prod/js/views/userManagement.js",
		};
		if (!ctx.session.userId) {
			return ctx.redirect("/login.html");
		} else {
			const model = require("../models/user")(ctx);
			const result = await model.details({_id: ctx.ObjectID(ctx.session.userId)}, {privileges: 1, _id: 0});
			data.privileges = result.doc.privileges;
			if (!result.status) {
				delete ctx.session.userId;
				return ctx.redirect("/login.html");
			}
		}
		const userModel = require("../models/user")(ctx);
		const result = await userModel.getAllCompanyUsersExtra("5eb2d65f5bbfeb46054a93b0");
		if (!result.status) {
			throw {};
		}
		data.users = result.doc.users;
		data.userRoles = ["Admin", "Taster", "Support"];
		data.roleMap = global.userRoleMap;
		data.masterPrivileges = global.masterPrivileges;
		data.locations = result.doc.locations;
		data.currentlyLoggedInUser = ctx.session.userId;
		ctx.set("Cache-Control", "no-cache, no-store, must-revalidate");
		return ctx.renderView("userManagement", data);
	},
	sellerManagement: async (ctx) => {
		const data = {
			title: icplApp.appDisplayName + " | Seller Management",
			viewName: "Sellers",
			scriptPath: "/prod/js/views/sellerManagement.js",
		};
		if (!ctx.session.userId) {
			return ctx.redirect("/login.html");
		} else {
			const model = require("../models/user")(ctx);
			const result = await model.details({_id: ctx.ObjectID(ctx.session.userId)}, {privileges: 1, _id: 0});
			data.privileges = result.doc.privileges;
			if (!result.status) {
				delete ctx.session.userId;
				return ctx.redirect("/login.html");
			}
		}
		const sellerModel = require("../models/seller")(ctx);
		const result = await sellerModel.list({companyId: ctx.ObjectID(global.hostCompanyId)});
		if (!result.status) {
			throw {};
		}
		data.sellers = result.docs;
		ctx.set("Cache-Control", "no-cache, no-store, must-revalidate");
		return ctx.renderView("sellerManagement", data);
	},
	locationManagement: async (ctx) => {
		const data = {
			title: icplApp.appDisplayName + " | Location Management",
			viewName: "Locations",
			scriptPath: "/prod/js/views/locationManagement.js",
		};
		if (!ctx.session.userId) {
			return ctx.redirect("/login.html");
		} else {
			const model = require("../models/user")(ctx);
			const result = await model.details({_id: ctx.ObjectID(ctx.session.userId)}, {privileges: 1, _id: 0});
			data.privileges = result.doc.privileges;
			if (!result.status) {
				delete ctx.session.userId;
				return ctx.redirect("/login.html");
			}
		}
		const model = require("../models/location")(ctx);
		const result = await model.list({companyId: ctx.ObjectID(global.hostCompanyId)});
		if (!result.status) {
			throw {};
		}
		data.locations = result.docs;
		ctx.set("Cache-Control", "no-cache, no-store, must-revalidate");
		return ctx.renderView("locationManagement", data);
	},
	categoryManagement: async (ctx) => {
		const data = {
			title: icplApp.appDisplayName + " | Category Management",
			viewName: "Categories",
			scriptPath: "/prod/js/views/categoryManagement.js",
		};
		if (!ctx.session.userId) {
			return ctx.redirect("/login.html");
		} else {
			const model = require("../models/user")(ctx);
			const result = await model.details({_id: ctx.ObjectID(ctx.session.userId)}, {privileges: 1, _id: 0});
			data.privileges = result.doc.privileges;
			if (!result.status) {
				delete ctx.session.userId;
				return ctx.redirect("/login.html");
			}
		}
		const model = require("../models/category")(ctx);
		const result = await model.list({companyId: ctx.ObjectID(global.hostCompanyId)});
		if (!result.status) {
			throw {};
		}
		data.categories = result.docs;
		ctx.set("Cache-Control", "no-cache, no-store, must-revalidate");
		return ctx.renderView("categoryManagement", data);
	},
	markManagement: async (ctx) => {
		const data = {
			title: icplApp.appDisplayName + " | Mark Management",
			viewName: "Marks",
			scriptPath: "/prod/js/views/markManagement.js",
		};
		if (!ctx.session.userId) {
			return ctx.redirect("/login.html");
		} else {
			const model = require("../models/user")(ctx);
			const result = await model.details({_id: ctx.ObjectID(ctx.session.userId)}, {privileges: 1, _id: 0});
			data.privileges = result.doc.privileges;
			if (!result.status) {
				delete ctx.session.userId;
				return ctx.redirect("/login.html");
			}
		}
		const model = require("../models/mark")(ctx);
		let result = await model.list({});
		if (!result.status) {
			throw {};
		}
		data.marks = result.docs;
		const locationModel = require("../models/location")(ctx);
		result = await locationModel.listWithCategory();
		if (!result.status) {
			throw {};
		}
		if (result.doc.locations) {
			data.locations = result.doc.locations;
		} else {
			data.locations = [];
		}
		if (result.doc.categories) {
			data.categories = result.doc.categories;
		} else {
			data.categories = [];
		}
		ctx.set("Cache-Control", "no-cache, no-store, must-revalidate");
		return ctx.renderView("markManagement", data);
	},
	gradeManagement: async (ctx) => {
		const data = {
			title: icplApp.appDisplayName + " | Grade Management",
			viewName: "Grades",
			scriptPath: "/prod/js/views/gradeManagement.js",
		};
		if (!ctx.session.userId) {
			return ctx.redirect("/login.html");
		} else {
			const model = require("../models/user")(ctx);
			const result = await model.details({_id: ctx.ObjectID(ctx.session.userId)}, {privileges: 1, _id: 0});
			data.privileges = result.doc.privileges;
			if (!result.status) {
				delete ctx.session.userId;
				return ctx.redirect("/login.html");
			}
		}
		const model = require("../models/grade")(ctx);
		const result = await model.list({companyId: ctx.ObjectID(global.hostCompanyId)});
		if (!result.status) {
			throw {};
		}
		data.grades = result.docs;
		const categoryModel = require("../models/category")(ctx);
		const caregoryResult = await categoryModel.list({companyId: ctx.ObjectID(global.hostCompanyId)}, {code: 1, name: 1});
		if (!caregoryResult.status) {
			throw {};
		}
		data.categories = caregoryResult.docs;
		ctx.set("Cache-Control", "no-cache, no-store, must-revalidate");
		return ctx.renderView("gradeManagement", data);
	},
	tastingParameterManagement: async (ctx) => {
		const data = {
			title: icplApp.appDisplayName + " | Tasting Parameters",
			viewName: "Parameters",
			scriptPath: "/prod/js/views/tastingParams.js",
		};
		if (!ctx.session.userId) {
			return ctx.redirect("/login.html");
		} else {
			const model = require("../models/user")(ctx);
			const result = await model.details({_id: ctx.ObjectID(ctx.session.userId)}, {privileges: 1, _id: 0});
			data.privileges = result.doc.privileges;
			if (!result.status) {
				delete ctx.session.userId;
				return ctx.redirect("/login.html");
			}
		}
		const model = require("../models/tastingParam")(ctx);
		let result = await model.list({companyId: ctx.ObjectID(global.hostCompanyId)});
		if (!result.status) {
			throw {};
		}
		data.params = result.docs;
		const categoryModel = require("../models/category")(ctx);
		result = await categoryModel.list({companyId: ctx.ObjectID(global.hostCompanyId)}, {name: 1, code: 1});
		if (!result.status) {
			throw {};
		}
		data.categories = result.docs;
		ctx.set("Cache-Control", "no-cache, no-store, must-revalidate");
		return ctx.renderView("tastingParameter", data);
	},
	groupManagement: async (ctx) => {
		const data = {
			title: icplApp.appDisplayName + " | Group Management",
			viewName: "Groups",
			scriptPath: "/prod/js/views/groupManagement.js",
		};
		if (!ctx.session.userId) {
			return ctx.redirect("/login.html");
		} else {
			const model = require("../models/user")(ctx);
			const result = await model.details({_id: ctx.ObjectID(ctx.session.userId)}, {privileges: 1, _id: 0});
			data.privileges = result.doc.privileges;
			if (!result.status) {
				delete ctx.session.userId;
				return ctx.redirect("/login.html");
			}
		}
		const model = require("../models/group")(ctx);
		const result = await model.list({companyId: ctx.ObjectID(global.hostCompanyId)});
		if (!result.status) {
			throw {};
		}
		data.groups = result.docs;
		ctx.set("Cache-Control", "no-cache, no-store, must-revalidate");
		return ctx.renderView("groupManagement", data);
	},
	auctionCenterManagement: async (ctx) => {
		const data = {
			title: icplApp.appDisplayName + " | Auction Center Management",
			viewName: "Auction Center",
			scriptPath: "/prod/js/views/auctionCenterManagement.js",
		};
		if (!ctx.session.userId) {
			return ctx.redirect("/login.html");
		} else {
			const model = require("../models/user")(ctx);
			const result = await model.details({_id: ctx.ObjectID(ctx.session.userId)}, {privileges: 1, _id: 0});
			data.privileges = result.doc.privileges;
			if (!result.status) {
				delete ctx.session.userId;
				return ctx.redirect("/login.html");
			}
		}
		const model = require("../models/auctionCenter")(ctx);
		const result = await model.list({companyId: ctx.ObjectID(global.hostCompanyId)});
		if (!result.status) {
			throw {};
		}
		data.auctionCenters = result.docs;
		ctx.set("Cache-Control", "no-cache, no-store, must-revalidate");
		return ctx.renderView("auctionCenterManagement", data);
	},
	groupSellerMapping: async (ctx) => {
		const data = {
			title: icplApp.appDisplayName + " | Group Seller Mapping",
			viewName: "Group Seller Mapping",
			scriptPath: "/prod/js/views/groupSellerMapping.js",
		};
		if (!ctx.session.userId) {
			return ctx.redirect("/login.html");
		} else {
			const model = require("../models/user")(ctx);
			const result = await model.details({_id: ctx.ObjectID(ctx.session.userId)}, {privileges: 1, _id: 0});
			data.privileges = result.doc.privileges;
			if (!result.status) {
				delete ctx.session.userId;
				return ctx.redirect("/login.html");
			}
		}
		const model = require("../models/groupSellerMapping")(ctx);
		let result = await model.list({companyId: ctx.ObjectID(global.hostCompanyId)});
		if (!result.status) {
			throw {};
		}
		result = model.serialize(result.docs);
		data.mappings = result.docs;
		const groupModel = require("../models/group")(ctx);
		const groupResult = await groupModel.listWithSellers();
		if (!groupResult.status) {
			throw {};
		}
		data.groups = groupResult.doc.groups;
		data.sellers = groupResult.doc.sellers;
		ctx.set("Cache-Control", "no-cache, no-store, must-revalidate");
		return ctx.renderView("groupSellerMapping", data);
	},
	sellerMarkMapping: async (ctx) => {
		const data = {
			title: icplApp.appDisplayName + " | Seller Mark Mapping",
			viewName: "Seller Mark Mapping",
			scriptPath: "/prod/js/views/sellerMarkMapping.js",
		};
		if (!ctx.session.userId) {
			return ctx.redirect("/login.html");
		} else {
			const model = require("../models/user")(ctx);
			const result = await model.details({_id: ctx.ObjectID(ctx.session.userId)}, {privileges: 1, _id: 0});
			data.privileges = result.doc.privileges;
			if (!result.status) {
				delete ctx.session.userId;
				return ctx.redirect("/login.html");
			}
		}
		const model = require("../models/sellerMarkMapping")(ctx);
		let result = await model.list({companyId: ctx.ObjectID(global.hostCompanyId)});
		if (!result.status) {
			throw {};
		}
		result = model.serialize(result.docs);
		data.mappings = result.docs;
		const sellerModel = require("../models/seller")(ctx);
		const sellerResult = await sellerModel.listWithMarks();
		if (!sellerResult.status) {
			throw {};
		}
		data.marks = sellerResult.doc.marks;
		data.sellers = sellerResult.doc.sellers;
		ctx.set("Cache-Control", "no-cache, no-store, must-revalidate");
		return ctx.renderView("sellerMarkMapping", data);
	},
	markEntityMapping: async (ctx) => {
		const data = {
			title: icplApp.appDisplayName + " | Mark Entity Mapping",
			viewName: "Mark Entity Mapping",
			scriptPath: "/prod/js/views/markEntityMapping.js",
		};
		if (!ctx.session.userId) {
			return ctx.redirect("/login.html");
		} else {
			const model = require("../models/user")(ctx);
			const result = await model.details({_id: ctx.ObjectID(ctx.session.userId)}, {privileges: 1, _id: 0});
			data.privileges = result.doc.privileges;
			if (!result.status) {
				delete ctx.session.userId;
				return ctx.redirect("/login.html");
			}
		}
		const model = require("../models/markEntityMapping")(ctx);
		const result = await model.list({companyId: ctx.ObjectID(global.hostCompanyId)});
		if (!result.status) {
			throw {};
		}
		data.mappings = result.docs;
		const markModel = require("../models/mark")(ctx);
		const markResult = await markModel.listWithAuctionCenterAndLocations();
		if (!markResult.status) {
			throw {};
		}
		data.marks = markResult.doc.marks;
		data.locations = markResult.doc.locations;
		data.centers = markResult.doc.centers;
		ctx.set("Cache-Control", "no-cache, no-store, must-revalidate");
		return ctx.renderView("markEntityMapping", data);
	},
	musterTastingInvoices: async (ctx) => {
		const data = {
			title: icplApp.appDisplayName + " | Muster Invoices",
			viewName: "Parameters",
			scriptPath: "/prod/js/views/musterInvoices.js",
		};
		if (!ctx.session.userId) {
			return ctx.redirect("/login.html");
		} else {
			const model = require("../models/user")(ctx);
			const result = await model.details({_id: ctx.ObjectID(ctx.session.userId)}, {privileges: 1, _id: 0});
			data.privileges = result.doc.privileges;
			if (!result.status) {
				delete ctx.session.userId;
				return ctx.redirect("/login.html");
			}
		}
		const model = require("../models/seller")(ctx);
		const result = await model.pendingMuster();
		if (!result.status) {
			throw {};
		}
		data.sellers = result.doc.sellers;
		for (let outer=0, oLen = data.sellers.length; outer<oLen; outer++) {
			data.sellers[outer].name = data.sellers[outer].seller[0].name;
			delete data.sellers[outer].markIds;
			delete data.sellers[outer].seller;
			for (let loop=0, length = data.sellers[outer].samples.length; loop<length; loop++) {
				data.sellers[outer].samples[loop].createdAt = data.sellers[outer].samples[loop].createdAt.getTime();
			}
		}
		data.grades = result.doc.grades;
		data.categories = result.doc.categories;
		data.users = result.doc.users;
		ctx.set("Cache-Control", "no-cache, no-store, must-revalidate");
		return ctx.renderView("musterTastingInvoices", data);
	},
	auctionTastingInvoices: async (ctx) => {
		const data = {
			title: icplApp.appDisplayName + " | Auction Invoices",
			viewName: "Parameters",
			scriptPath: "/prod/js/views/auctionInvoices.js",
		};
		if (!ctx.session.userId) {
			return ctx.redirect("/login.html");
		} else {
			const model = require("../models/user")(ctx);
			const result = await model.details({_id: ctx.ObjectID(ctx.session.userId)}, {privileges: 1, _id: 0});
			data.privileges = result.doc.privileges;
			if (!result.status) {
				delete ctx.session.userId;
				return ctx.redirect("/login.html");
			}
		}
		const dt = new Date();
		let _season = dt.getFullYear();
		if (dt.getMonth==0) {
			_season--;
		}
		const model = require("../models/auction")(ctx);
		const result = await model.listExtra({season: _season, status: "PENDING"});
		if (!result.status) {
			throw {};
		}
		data.auctions = result.doc.auctions;
		for (let loop=0, length = data.auctions.length; loop<length; loop++) {
			if (data.auctions[loop].tastingDate) {
				data.auctions[loop].tastingDate = data.auctions[loop].tastingDate.getTime();
			}
		}
		data.grades = result.doc.grades;
		data.marks = result.doc.marks;
		data.users = result.doc.users;
		data.locations = result.doc.locations;
		ctx.set("Cache-Control", "no-cache, no-store, must-revalidate");
		return ctx.renderView("auctionTastingInvoices", data);
	},
	financeTastingInvoices: async (ctx) => {
		const data = {
			title: icplApp.appDisplayName + " | Finance Invoices",
			viewName: "Parameters",
			scriptPath: "/prod/js/views/financeInvoices.js",
		};
		if (!ctx.session.userId) {
			return ctx.redirect("/login.html");
		} else {
			const model = require("../models/user")(ctx);
			const result = await model.details({_id: ctx.ObjectID(ctx.session.userId)}, {privileges: 1, _id: 0});
			data.privileges = result.doc.privileges;
			if (!result.status) {
				delete ctx.session.userId;
				return ctx.redirect("/login.html");
			}
		}
		/* const model = require("../models/tastingParam")(ctx);
		let result = await model.list({companyId: ctx.ObjectID(global.hostCompanyId)});
		if (!result.status) {
			throw {};
		}
		data.params = result.docs;
		const categoryModel = require("../models/category")(ctx);
		result = await categoryModel.list({companyId: ctx.ObjectID(global.hostCompanyId)}, {name: 1, code: 1});
		if (!result.status) {
			throw {};
		}
		data.categories = result.docs; */
		ctx.set("Cache-Control", "no-cache, no-store, must-revalidate");
		return ctx.renderView("financeTastingInvoices", data);
	},
	privateSaleTastingInvoices: async (ctx) => {
		const data = {
			title: icplApp.appDisplayName + " | Private Sale Invoices",
			viewName: "Parameters",
			scriptPath: "/prod/js/views/privateSaleInvoices.js",
		};
		if (!ctx.session.userId) {
			return ctx.redirect("/login.html");
		} else {
			const model = require("../models/user")(ctx);
			const result = await model.details({_id: ctx.ObjectID(ctx.session.userId)}, {privileges: 1, _id: 0});
			data.privileges = result.doc.privileges;
			if (!result.status) {
				delete ctx.session.userId;
				return ctx.redirect("/login.html");
			}
		}
		/* const model = require("../models/tastingParam")(ctx);
		let result = await model.list({companyId: ctx.ObjectID(global.hostCompanyId)});
		if (!result.status) {
			throw {};
		}
		data.params = result.docs;
		const categoryModel = require("../models/category")(ctx);
		result = await categoryModel.list({companyId: ctx.ObjectID(global.hostCompanyId)}, {name: 1, code: 1});
		if (!result.status) {
			throw {};
		}
		data.categories = result.docs; */
		ctx.set("Cache-Control", "no-cache, no-store, must-revalidate");
		return ctx.renderView("privateSaleTastingInvoices", data);
	},
	teaTasting: async (ctx) => {
		const data = {
			title: icplApp.appDisplayName + " | Tasting",
			viewName: "Parameters",
			scriptPath: "/prod/js/views/teaTasting.js",
		};
		if (!ctx.session.userId) {
			return ctx.redirect("/login.html");
		} else {
			const model = require("../models/user")(ctx);
			const result = await model.details({_id: ctx.ObjectID(ctx.session.userId)}, {privileges: 1, _id: 0});
			data.privileges = result.doc.privileges;
			if (!result.status) {
				delete ctx.session.userId;
				return ctx.redirect("/login.html");
			}
		}
		const tastingParamModel = require("../models/tastingParam")(ctx);
		let tastingParamResult = await tastingParamModel.listSorted();
		if (!tastingParamResult.status) {
			throw {};
		}
		data.params = tastingParamResult.docs;
		tastingParamResult = await tastingParamModel.categoryMapping();
		if (!tastingParamResult.status) {
			throw {};
		}
		data.categoryMapping = tastingParamResult.doc;
		const userModel = require("../models/user")(ctx);
		const userResult = await userModel.assignedPendingRecords(ctx.session.userId);
		data.locations = userResult.doc.locations;
		data.musters = userResult.doc.musters;
		data.auctions = userResult.doc.auctions;
		data.sellers = userResult.doc.sellers;
		data.marks = userResult.doc.marks;
		ctx.set("Cache-Control", "no-cache, no-store, must-revalidate");
		return ctx.renderView("teaTasting", data);
	},
	musterTastingReports: async (ctx) => {
		const data = {
			title: icplApp.appDisplayName + " | Muster Tasting Reports",
			viewName: "Parameters",
			scriptPath: "/prod/js/views/tastingReports.js",
		};
		if (!ctx.session.userId) {
			return ctx.redirect("/login.html");
		} else {
			const model = require("../models/user")(ctx);
			const result = await model.details({_id: ctx.ObjectID(ctx.session.userId)}, {privileges: 1, _id: 0});
			data.privileges = result.doc.privileges;
			if (!result.status) {
				delete ctx.session.userId;
				return ctx.redirect("/login.html");
			}
		}
		const markModel = require("../models/mark")(ctx);
		const markResult = await markModel.listWithSellers();
		if (!markResult.status) {
			throw {};
		}
		data.marks = markResult.doc.marks;
		data.clients = markResult.doc.sellers;
		data.locations = [];
		data.type = "MUSTER";
		ctx.set("Cache-Control", "no-cache, no-store, must-revalidate");
		return ctx.renderView("musterTastingReports", data);
	},
	auctionTastingReports: async (ctx) => {
		const data = {
			title: icplApp.appDisplayName + " | Auction Tasting Reports",
			viewName: "Parameters",
			scriptPath: "/prod/js/views/tastingReports.js",
		};
		if (!ctx.session.userId) {
			return ctx.redirect("/login.html");
		} else {
			const model = require("../models/user")(ctx);
			const result = await model.details({_id: ctx.ObjectID(ctx.session.userId)}, {privileges: 1, _id: 0});
			data.privileges = result.doc.privileges;
			if (!result.status) {
				delete ctx.session.userId;
				return ctx.redirect("/login.html");
			}
		}
		const acModel = require("../models/auctionCenter")(ctx);
		const acResult = await acModel.list();
		if (!acResult.status) {
			throw {};
		}
		data.clients = [];
		data.marks = [];
		data.locations = acResult.docs;
		data.type = "AUCTION";
		ctx.set("Cache-Control", "no-cache, no-store, must-revalidate");
		return ctx.renderView("auctionTastingReports", data);
	},
	financeTastingReports: async (ctx) => {
		const data = {
			title: icplApp.appDisplayName + " | Finance Tasting Reports",
			viewName: "Parameters",
			scriptPath: "/prod/js/views/tastingReports.js",
		};
		if (!ctx.session.userId) {
			return ctx.redirect("/login.html");
		} else {
			const model = require("../models/user")(ctx);
			const result = await model.details({_id: ctx.ObjectID(ctx.session.userId)}, {privileges: 1, _id: 0});
			data.privileges = result.doc.privileges;
			if (!result.status) {
				delete ctx.session.userId;
				return ctx.redirect("/login.html");
			}
		}
		data.clients = [];
		data.marks = [];
		data.locations = [];
		data.type = "FINANCE";
		ctx.set("Cache-Control", "no-cache, no-store, must-revalidate");
		return ctx.renderView("financeTastingReports", data);
	},
	privateSaleTastingReports: async (ctx) => {
		const data = {
			title: icplApp.appDisplayName + " | Private Tasting Reports",
			viewName: "Parameters",
			scriptPath: "/prod/js/views/tastingReports.js",
		};
		if (!ctx.session.userId) {
			return ctx.redirect("/login.html");
		} else {
			const model = require("../models/user")(ctx);
			const result = await model.details({_id: ctx.ObjectID(ctx.session.userId)}, {privileges: 1, _id: 0});
			data.privileges = result.doc.privileges;
			if (!result.status) {
				delete ctx.session.userId;
				return ctx.redirect("/login.html");
			}
		}
		data.clients = [];
		data.marks = [];
		data.locations = [];
		data.type = "PVT-SALE";
		ctx.set("Cache-Control", "no-cache, no-store, must-revalidate");
		return ctx.renderView("privateSaleTastingReports", data);
	},
	offline: async (ctx) => {
		ctx.set("Cache-Control", "no-cache, no-store, must-revalidate");
		return ctx.renderView("offline", {
			title: icplApp.appDisplayName,
		});
	},
	forgotPassword: async (ctx) => {
		ctx.set("Cache-Control", "no-cache, no-store, must-revalidate");
		return ctx.renderView("forgotPassword", {
			title: icplApp.appDisplayName,
		});
	},
};
