// eslint-disable-next-line no-unused-vars
const changeCase = require("change-case");
// eslint-disable-next-line no-unused-vars
const validatorUtil = require("validator");

function categoryValidator(input, validateExisting) {
	if (!validateExisting && (!(input.name && input.code && true))) {
		return {status: false, msg: "Parameter(s) missing."};
	}
	if (input.name) {
		if ((input.name.length < 2) || (input.name.length > 80)) {
			return {status: false, msg: "Invalid value for 'Name'."};
		}
	}
	if (input.name) {
		input.name = input.name.toUpperCase();
	}
	if (input.code) {
		if ((input.code.length < 1) || (input.code.length > 10)) {
			return {status: false, msg: "Invalid value for 'Code'."};
		}
	}
	if (input.code) {
		input.code = input.code.toUpperCase();
	}
	if (input.descriptiveRemarks == true) {
		input.descriptiveRemarks = true;
	} else if ((input.descriptiveRemarks != null) && (input.descriptiveRemarks != undefined)) {
		input.descriptiveRemarks = false;
	}
	const _ = require("lodash");
	input = _.omitBy(input, _.isNil);
	return {status: true, msg: "", data: input};
}

function sellerValidator(input, validateExisting) {
	if (!validateExisting && (!(input.name && input.code && input.mobile && input.email && input.contactPerson && input.city && input.state && input.pincode && input.address && input.gstin && input.cin && true))) {
		return {status: false, msg: "Parameter(s) missing."};
	}
	if (input.name) {
		if ((input.name.length < 4) || (input.name.length > 80)) {
			return {status: false, msg: "Invalid value for 'Seller Name'."};
		}
	}
	if (input.name) {
		input.name = input.name.toTitleCase();
	}
	if (input.code) {
		if ((input.code.length < 1) || (input.code.length > 10)) {
			return {status: false, msg: "Invalid value for 'Seller Code'."};
		}
	}
	if (input.code) {
		input.code = input.code.toUpperCase();
	}
	if (input.mobile) {
		if (input.mobile.length != 10 ) {
			return {status: false, msg: "Invalid value for 'Mobile'."};
		}
	}
	if (input.email) {
		if (!validatorUtil.isEmail(input.email)) {
			return {status: false, msg: "Invalid value for 'Email'."};
		}
	}
	if (input.contactPerson) {
		if ((input.contactPerson.length < 2) || (input.contactPerson.length > 40)) {
			return {status: false, msg: "Invalid value for 'Contact Person'."};
		}
	}
	if (input.contactPerson) {
		input.contactPerson = input.contactPerson.toTitleCase();
	}
	if (input.city) {
		if ((input.city.length < 2) || (input.city.length > 15)) {
			return {status: false, msg: "Invalid value for 'City'."};
		}
	}
	if (input.city) {
		input.city = input.city.toTitleCase();
	}
	if (input.state) {
		if ((input.state.length < 2) || (input.state.length > 15)) {
			return {status: false, msg: "Invalid value for 'State'."};
		}
	}
	if (input.state) {
		input.state = input.state.toTitleCase();
	}
	if (input.pincode != null) {
		input.pincode = Number(input.pincode);
		if (isNaN(input.pincode)) {
			return {status: false, msg: "Invalid value for 'Pincode'."};
		}
	}
	if ((input.pincode < 100000) || (input.pincode > 999999)) {
		return {status: false, msg: "Invalid value for 'Pincode'."};
	}
	if (input.address) {
		if ((input.address.length < 1) || (input.address.length > 120)) {
			return {status: false, msg: "Invalid value for 'Address'."};
		}
	}
	if (input.address) {
		input.address = input.address.toTitleCase();
	}
	if (input.gstin) {
		if ((input.gstin.length < 15) || (input.gstin.length > 15)) {
			return {status: false, msg: "Invalid value for 'GSTIN'."};
		}
	}
	if (input.gstin) {
		input.gstin = input.gstin.toUpperCase();
	}
	if (input.cin) {
		if ((input.cin.length < 10) || (input.cin.length > 25)) {
			return {status: false, msg: "Invalid value for 'CIN No'."};
		}
	}
	if (input.cin) {
		input.cin = input.cin.toUpperCase();
	}
	if (input.fssaiNo) {
		if ((input.fssaiNo.length < 14) || (input.fssaiNo.length > 14)) {
			return {status: false, msg: "Invalid value for 'FSSAI No'."};
		}
	}
	if (input.fssaiNo) {
		input.fssaiNo = input.fssaiNo.toUpperCase();
	}
	const _ = require("lodash");
	input = _.omitBy(input, _.isNil);
	return {status: true, msg: "", data: input};
}

function gradeValidator(input, validateExisting) {
	if (!validateExisting && (!(input.code && input.slno && input.category && input.subCategory && input.type && input.subType && true))) {
		return {status: false, msg: "Parameter(s) missing."};
	}
	if (input.code) {
		if ((input.code.length < 1) || (input.code.length > 15)) {
			return {status: false, msg: "Invalid value for 'Code'."};
		}
	}
	if (input.code) {
		input.code = input.code.toUpperCase();
	}
	if (input.slno != null) {
		input.slno = Number(input.slno);
		if (isNaN(input.slno)) {
			return {status: false, msg: "Invalid value for 'Order SLNo'."};
		}
	}
	if ((input.slno < 1) || (input.slno > 999)) {
		return {status: false, msg: "Invalid value for 'Order SLNo'."};
	}
	if (input.type) {
		if ((input.type.length < 1) || (input.type.length > 1)) {
			return {status: false, msg: "Invalid value for 'Type'."};
		}
	}
	if (input.type) {
		input.type = input.type.toUpperCase();
	}
	if (input.subType) {
		if ((input.subType.length < 1) || (input.subType.length > 1)) {
			return {status: false, msg: "Invalid value for 'Sub Type'."};
		}
	}
	if (input.subType) {
		input.subType = input.subType.toUpperCase();
	}
	const _ = require("lodash");
	input = _.omitBy(input, _.isNil);
	return {status: true, msg: "", data: input};
}

function locationValidator(input, validateExisting) {
	if (!validateExisting && (!(input.name && input.code && true))) {
		return {status: false, msg: "Parameter(s) missing."};
	}
	if (input.name) {
		if ((input.name.length < 4) || (input.name.length > 80)) {
			return {status: false, msg: "Invalid value for 'Name'."};
		}
	}
	if (input.name) {
		input.name = input.name.toUpperCase();
	}
	if (input.code) {
		if ((input.code.length < 1) || (input.code.length > 10)) {
			return {status: false, msg: "Invalid value for 'Code'."};
		}
	}
	if (input.code) {
		input.code = input.code.toUpperCase();
	}
	const _ = require("lodash");
	input = _.omitBy(input, _.isNil);
	return {status: true, msg: "", data: input};
}

function markValidator(input, validateExisting) {
	if (!validateExisting && (!(input.name && input.code && input.type && input.locationId && input.region && input.address && input.category && input.fssalNo && input.fssaiValidDate && input.teaBoardRegNo && true))) {
		return {status: false, msg: "Parameter(s) missing."};
	}
	if (input.name) {
		if ((input.name.length < 2) || (input.name.length > 80)) {
			return {status: false, msg: "Invalid value for 'Garden Name'."};
		}
	}
	if (input.name) {
		input.name = input.name.toTitleCase();
	}
	if (input.code) {
		if ((input.code.length < 1) || (input.code.length > 10)) {
			return {status: false, msg: "Invalid value for 'Garden Code'."};
		}
	}
	if (input.code) {
		input.code = input.code.toUpperCase();
	}
	if (input.type) {
		if ((input.type.length < 1) || (input.type.length > 1)) {
			return {status: false, msg: "Invalid value for 'Type'."};
		}
	}
	if (input.type) {
		input.type = input.type.toUpperCase();
	}
	if (input.region) {
		if ((input.region.length < 1) || (input.region.length > 20)) {
			return {status: false, msg: "Invalid value for 'Tea Region'."};
		}
	}
	if (input.region) {
		input.region = input.region.toTitleCase();
	}
	if (input.address) {
		if ((input.address.length < 1) || (input.address.length > 100)) {
			return {status: false, msg: "Invalid value for 'Address'."};
		}
	}
	if (input.address) {
		input.address = input.address.toTitleCase();
	}
	if (input.latitude != null) {
		input.latitude = Number(input.latitude);
		if (isNaN(input.latitude)) {
			return {status: false, msg: "Invalid value for 'Latitude'."};
		}
	}
	if (input.longitude != null) {
		input.longitude = Number(input.longitude);
		if (isNaN(input.longitude)) {
			return {status: false, msg: "Invalid value for 'Longitude'."};
		}
	}
	if (input.annualProduction != null) {
		input.annualProduction = Number(input.annualProduction);
		if (isNaN(input.annualProduction)) {
			return {status: false, msg: "Invalid value for 'Annual Production'."};
		}
	}
	if (input.haccp == true) {
		input.haccp = true;
	} else if ((input.haccp != null) && (input.haccp != undefined)) {
		input.haccp = false;
	}
	if (input.haccpDate != null) {
		input.haccpDate = Number(input.haccpDate);
		if (isNaN(input.haccpDate)) {
			return {status: false, msg: "Invalid value for 'HACCP Date'."};
		}
		const haccpDateValDt = new Date();
		haccpDateValDt.setTime(input.haccpDate);
		input.haccpDate = haccpDateValDt;
	}
	if (input.trustea == true) {
		input.trustea = true;
	} else if ((input.trustea != null) && (input.trustea != undefined)) {
		input.trustea = false;
	}
	if (input.trusteaValidUpto != null) {
		input.trusteaValidUpto = Number(input.trusteaValidUpto);
		if (isNaN(input.trusteaValidUpto)) {
			return {status: false, msg: "Invalid value for 'Trustea Valid Upto'."};
		}
		const trusteaValidUptoValDt = new Date();
		trusteaValidUptoValDt.setTime(input.trusteaValidUpto);
		input.trusteaValidUpto = trusteaValidUptoValDt;
	}
	if (input.rainforest == true) {
		input.rainforest = true;
	} else if ((input.rainforest != null) && (input.rainforest != undefined)) {
		input.rainforest = false;
	}
	if (input.raValidUpto != null) {
		input.raValidUpto = Number(input.raValidUpto);
		if (isNaN(input.raValidUpto)) {
			return {status: false, msg: "Invalid value for 'RA Valid Upto'."};
		}
		const raValidUptoValDt = new Date();
		raValidUptoValDt.setTime(input.raValidUpto);
		input.raValidUpto = raValidUptoValDt;
	}
	if (input.gardenISOValidUpto != null) {
		input.gardenISOValidUpto = Number(input.gardenISOValidUpto);
		if (isNaN(input.gardenISOValidUpto)) {
			return {status: false, msg: "Invalid value for 'Garden ISO Valid Upto'."};
		}
		const gardenISOValidUptoValDt = new Date();
		gardenISOValidUptoValDt.setTime(input.gardenISOValidUpto);
		input.gardenISOValidUpto = gardenISOValidUptoValDt;
	}
	if (input.fssaiValidDate != null) {
		input.fssaiValidDate = Number(input.fssaiValidDate);
		if (isNaN(input.fssaiValidDate)) {
			return {status: false, msg: "Invalid value for 'Fssai Valid Date'."};
		}
		const fssaiValidDateValDt = new Date();
		fssaiValidDateValDt.setTime(input.fssaiValidDate);
		input.fssaiValidDate = fssaiValidDateValDt;
	}
	if (input.organic == true) {
		input.organic = true;
	} else if ((input.organic != null) && (input.organic != undefined)) {
		input.organic = false;
	}
	if (input.gardenAdvance == true) {
		input.gardenAdvance = true;
	} else if ((input.gardenAdvance != null) && (input.gardenAdvance != undefined)) {
		input.gardenAdvance = false;
	}
	const _ = require("lodash");
	input = _.omitBy(input, _.isNil);
	return {status: true, msg: "", data: input};
}

function groupValidator(input, validateExisting) {
	if (!validateExisting && (!(input.name && input.code && input.contactPerson && input.email && input.address && true))) {
		return {status: false, msg: "Parameter(s) missing."};
	}
	if (input.name) {
		if ((input.name.length < 4) || (input.name.length > 80)) {
			return {status: false, msg: "Invalid value for 'Group Name'."};
		}
	}
	if (input.name) {
		input.name = input.name.toTitleCase();
	}
	if (input.code) {
		if ((input.code.length < 1) || (input.code.length > 10)) {
			return {status: false, msg: "Invalid value for 'Group Code'."};
		}
	}
	if (input.code) {
		input.code = input.code.toUpperCase();
	}
	if (input.contactPerson) {
		if ((input.contactPerson.length < 2) || (input.contactPerson.length > 40)) {
			return {status: false, msg: "Invalid value for 'Contact Person'."};
		}
	}
	if (input.contactPerson) {
		input.contactPerson = input.contactPerson.toTitleCase();
	}
	if (input.email) {
		if (!validatorUtil.isEmail(input.email)) {
			return {status: false, msg: "Invalid value for 'Email'."};
		}
	}
	if (input.address) {
		if ((input.address.length < 1) || (input.address.length > 120)) {
			return {status: false, msg: "Invalid value for 'Address'."};
		}
	}
	if (input.address) {
		input.address = input.address.toTitleCase();
	}
	const _ = require("lodash");
	input = _.omitBy(input, _.isNil);
	return {status: true, msg: "", data: input};
}

function auctionCenterValidator(input, validateExisting) {
	if (!validateExisting && (!(input.name && input.code && true))) {
		return {status: false, msg: "Parameter(s) missing."};
	}
	if (input.name) {
		if ((input.name.length < 4) || (input.name.length > 80)) {
			return {status: false, msg: "Invalid value for 'Auction Center Name'."};
		}
	}
	if (input.name) {
		input.name = input.name.toUpperCase();
	}
	if (input.code) {
		if ((input.code.length < 1) || (input.code.length > 10)) {
			return {status: false, msg: "Invalid value for 'Auction Center Code'."};
		}
	}
	if (input.code) {
		input.code = input.code.toUpperCase();
	}
	const _ = require("lodash");
	input = _.omitBy(input, _.isNil);
	return {status: true, msg: "", data: input};
}

function groupSellerMappingValidator(input, validateExisting) {
	if (!validateExisting && (!(input.group && input.seller && input.dateFrom && input.dateTo && true))) {
		return {status: false, msg: "Parameter(s) missing."};
	}
	if (input.dateFrom != null) {
		input.dateFrom = Number(input.dateFrom);
		if (isNaN(input.dateFrom)) {
			return {status: false, msg: "Invalid value for 'Date From'."};
		}
		const dateFromValDt = new Date();
		dateFromValDt.setTime(input.dateFrom);
		input.dateFrom = dateFromValDt;
	}
	if (input.dateTo != null) {
		input.dateTo = Number(input.dateTo);
		if (isNaN(input.dateTo)) {
			return {status: false, msg: "Invalid value for 'Date To'."};
		}
		const dateToValDt = new Date();
		dateToValDt.setTime(input.dateTo);
		input.dateTo = dateToValDt;
	}
	const _ = require("lodash");
	input = _.omitBy(input, _.isNil);
	return {status: true, msg: "", data: input};
}

function sellerMarkMappingValidator(input, validateExisting) {
	if (!validateExisting && (!(input.seller && input.mark && input.dateFrom && input.dateTo && true))) {
		return {status: false, msg: "Parameter(s) missing."};
	}
	if (input.dateFrom != null) {
		input.dateFrom = Number(input.dateFrom);
		if (isNaN(input.dateFrom)) {
			return {status: false, msg: "Invalid value for 'Date From'."};
		}
		const dateFromValDt = new Date();
		dateFromValDt.setTime(input.dateFrom);
		input.dateFrom = dateFromValDt;
	}
	if (input.dateTo != null) {
		input.dateTo = Number(input.dateTo);
		if (isNaN(input.dateTo)) {
			return {status: false, msg: "Invalid value for 'Date To'."};
		}
		const dateToValDt = new Date();
		dateToValDt.setTime(input.dateTo);
		input.dateTo = dateToValDt;
	}
	const _ = require("lodash");
	input = _.omitBy(input, _.isNil);
	return {status: true, msg: "", data: input};
}

function markACMappingValidator(input, validateExisting) {
	if (!validateExisting && (!(input.location && input.mark && input.auctionCenter && input.markEntityCode && input.eAuctionName && true))) {
		return {status: false, msg: "Parameter(s) missing."};
	}
	if (input.markEntityCode) {
		input.markEntityCode = input.markEntityCode.toUpperCase();
	}
	if (input.eAuctionName) {
		input.eAuctionName = input.eAuctionName.toUpperCase();
	}
	const _ = require("lodash");
	input = _.omitBy(input, _.isNil);
	return {status: true, msg: "", data: input};
}

module.exports = {
	createCategory: async (ctx) => {
		const nameVal = ctx.request.fields.name;
		const codeVal = ctx.request.fields.code;
		const descriptiveRemarksVal = ctx.request.fields.descriptiveRemarks;

		const now = new Date();
		const input = {
			name: nameVal,
			code: codeVal,
			descriptiveRemarks: descriptiveRemarksVal,
		};
		input.isActive = true;
		input.createdBy = ctx.session.userId || ctx.request.fields.userId;
		input.updatedBy = ctx.session.userId || ctx.request.fields.userId;
		if (!input.createdBy) {
			return ctx.ok({status: false, msg: "Session expired or invalid entry"});
		}
		input.companyId = ctx.request.fields.companyId || global.hostCompanyId;
		input.companyId = ctx.ObjectID(input.companyId);
		input.createdBy = ctx.ObjectID(input.createdBy);
		input.updatedBy = ctx.ObjectID(input.updatedBy);
		input.createdAt = now;
		input.updatedAt = now;

		const validationResult = categoryValidator(input);
		if (!validationResult.status) {
			return ctx.ok(validationResult);
		}
		const model = require("../models/category")(ctx);
		let result = await model.create(validationResult.data);
		if (!result.status) {
			return ctx.ok(result);
		}
		result = model.serialize([result.doc]);
		if (!result.status) {
			return ctx.ok(result);
		}
		return ctx.ok({status: true, msg: "OK", doc: result.docs[0]});
	},
	updateCategory: async (ctx) => {
		if (!(ctx.request.fields.find && ctx.request.fields.update)) {
			return ctx.ok({status: false, msg: "Parameter(s) missing."});
		}
		const categoryId = ctx.request.fields.find;
		const nameVal = ctx.request.fields.update.name;
		const codeVal = ctx.request.fields.update.code;
		const descriptiveRemarksVal = ctx.request.fields.update.descriptiveRemarks;
		const isActiveVal = ctx.request.fields.update.isActive;

		const now = new Date();
		let input = {
			name: nameVal,
			code: codeVal,
			descriptiveRemarks: descriptiveRemarksVal,
			isActive: isActiveVal,
		};

		const validationResult = categoryValidator(input, true);
		if (!validationResult.status) {
			return ctx.ok(validationResult);
		}
		input = validationResult.data;
		input.updatedBy = ctx.session.userId || ctx.request.fields.userId;
		if (!input.updatedBy) {
			return ctx.ok({status: false, msg: "Session expired or invalid entry"});
		}
		input.updatedBy = ctx.ObjectID(input.updatedBy);
		input.updatedAt = now;
		const model = require("../models/category")(ctx);
		let result = await model.update(categoryId, input);
		if (!result.status) {
			return ctx.ok(result);
		}
		result = model.serialize([result.doc]);
		if (!result.status) {
			return ctx.ok(result);
		}
		return ctx.ok({status: true, msg: "OK", doc: result.docs[0]});
	},
	bulkCreateCategory: async (ctx) => {
		if (!(ctx.session.userId || ctx.request.fields.userId)) {
			return ctx.ok({status: false, msg: "Session expired/invalid entry."});
		}
		const userId = ctx.session.userId || ctx.request.fields.userId;
		const companyId = ctx.request.fields.companyId || global.hostCompanyId;
		try {
			const uploadedFilePath = ctx.request.fields.upload[0].path;
			for (let loop = 0, length = ctx.request.files.length; loop < length; loop++) {
				if (ctx.request.files[loop].path != uploadedFilePath) {
					fs.unlinkSync(ctx.request.files[loop].path);
				}
			}
			if (!uploadedFilePath) {
				return ctx.ok({status: false, msg: "Parameter(s) missing."});
			}
			const XLSX = require("xlsx-style");
			let requiredJson = null;
			const workbook = XLSX.readFile(uploadedFilePath);
			const first_sheet_name = workbook.SheetNames[0];
			const worksheet = workbook.Sheets[first_sheet_name];
			requiredJson = XLSX.utils.sheet_to_json(worksheet);
			// const path = require("path");
			const fs = require("fs");
			fs.unlinkSync(uploadedFilePath);
			if (!requiredJson) {
				return ctx.ok({status: false, msg: "Uploaded file was empty or had data in unrecognised format."});
			}
			const validatorService = require("../services/bulkValidationService")(ctx);
			const validatedResult = await validatorService.validateCategories(requiredJson, userId, companyId);
			if (validatedResult.docs.length == 0 && validatedResult.outcome.length == 0) {
				return ctx.ok({
					status: false,
					msg: "Uploaded file was empty or had data in unrecognised format.",
				});
			} else if (validatedResult.docs.length == 0 && validatedResult.outcome.length > 0) {
				return ctx.ok({
					status: true,
					msg: "",
					outcome: validatedResult.outcome,
					successCount: 0,
				});
			} else {
				const model = require("../models/category")(ctx);
				const categoryResult = await model.bulkCreate(validatedResult.docs);
				if (!categoryResult.status) {
					return ctx.ok({status: false, msg: "Illegal or invalid values."});
				}
				for (var loop = 0, length = categoryResult.result.outcome.length; loop < length; loop++) {
					validatedResult.outcome[validatedResult.ref[loop]] = categoryResult.result.outcome[loop];
				}
				let categoryResult2 = await model.list({companyId: ctx.ObjectID(companyId)});
				if (categoryResult2.status) {
					categoryResult2 = model.serialize(categoryResult2.docs);
				}
				if (categoryResult2.status) {
					return ctx.ok({
						status: true,
						msg: "",
						outcome: validatedResult.outcome,
						successCount: categoryResult.result.successCount,
						docs: categoryResult2.docs,
					});
				} else {
					return ctx.ok({
						status: true,
						msg: "",
						outcome: validatedResult.outcome,
						successCount: categoryResult.result.successCount,
					});
				}
			}
		} catch (err) {
			console.log(err);
			return ctx.ok({status: false, msg: "Illegal or invalid values."});
		}
	},
	createSeller: async (ctx) => {
		const nameVal = ctx.request.fields.name;
		const codeVal = ctx.request.fields.code;
		const mobileVal = ctx.request.fields.mobile;
		const emailVal = ctx.request.fields.email;
		const contactPersonVal = ctx.request.fields.contactPerson;
		const cityVal = ctx.request.fields.city;
		const stateVal = ctx.request.fields.state;
		const pincodeVal = ctx.request.fields.pincode;
		const addressVal = ctx.request.fields.address;
		const gstinVal = ctx.request.fields.gstin;
		const cinVal = ctx.request.fields.cin;
		const fssaiNoVal = ctx.request.fields.fssaiNo;

		const now = new Date();
		const input = {
			name: nameVal,
			code: codeVal,
			mobile: mobileVal,
			email: emailVal,
			contactPerson: contactPersonVal,
			city: cityVal,
			state: stateVal,
			pincode: pincodeVal,
			address: addressVal,
			gstin: gstinVal,
			cin: cinVal,
			fssaiNo: fssaiNoVal,
		};
		input.isActive = true;
		input.createdBy = ctx.session.userId || ctx.request.fields.userId;
		input.updatedBy = ctx.session.userId || ctx.request.fields.userId;
		if (!input.createdBy) {
			return ctx.ok({status: false, msg: "Session expired or invalid entry"});
		}
		input.companyId = ctx.request.fields.companyId || global.hostCompanyId;
		input.companyId = ctx.ObjectID(input.companyId);
		input.createdBy = ctx.ObjectID(input.createdBy);
		input.updatedBy = ctx.ObjectID(input.updatedBy);
		input.createdAt = now;
		input.updatedAt = now;

		const validationResult = sellerValidator(input);
		if (!validationResult.status) {
			return ctx.ok(validationResult);
		}
		const model = require("../models/seller")(ctx);
		let result = await model.create(validationResult.data);
		if (!result.status) {
			return ctx.ok(result);
		}
		result = model.serialize([result.doc]);
		if (!result.status) {
			return ctx.ok(result);
		}
		return ctx.ok({status: true, msg: "OK", doc: result.docs[0]});
	},
	updateSeller: async (ctx) => {
		if (!(ctx.request.fields.find && ctx.request.fields.update)) {
			return ctx.ok({status: false, msg: "Parameter(s) missing."});
		}
		const sellerId = ctx.request.fields.find;
		const nameVal = ctx.request.fields.update.name;
		const codeVal = ctx.request.fields.update.code;
		const mobileVal = ctx.request.fields.update.mobile;
		const emailVal = ctx.request.fields.update.email;
		const contactPersonVal = ctx.request.fields.update.contactPerson;
		const cityVal = ctx.request.fields.update.city;
		const stateVal = ctx.request.fields.update.state;
		const pincodeVal = ctx.request.fields.update.pincode;
		const addressVal = ctx.request.fields.update.address;
		const gstinVal = ctx.request.fields.update.gstin;
		const cinVal = ctx.request.fields.update.cin;
		const fssaiNoVal = ctx.request.fields.update.fssaiNo;
		const isActiveVal = ctx.request.fields.update.isActive;

		const now = new Date();
		let input = {
			name: nameVal,
			code: codeVal,
			mobile: mobileVal,
			email: emailVal,
			contactPerson: contactPersonVal,
			city: cityVal,
			state: stateVal,
			pincode: pincodeVal,
			address: addressVal,
			gstin: gstinVal,
			cin: cinVal,
			fssaiNo: fssaiNoVal,
			isActive: isActiveVal,
		};

		const validationResult = sellerValidator(input, true);
		if (!validationResult.status) {
			return ctx.ok(validationResult);
		}
		input = validationResult.data;
		input.updatedBy = ctx.session.userId || ctx.request.fields.userId;
		if (!input.updatedBy) {
			return ctx.ok({status: false, msg: "Session expired or invalid entry"});
		}
		input.updatedBy = ctx.ObjectID(input.updatedBy);
		input.updatedAt = now;
		const model = require("../models/seller")(ctx);
		let result = await model.update(sellerId, input);
		if (!result.status) {
			return ctx.ok(result);
		}
		result = model.serialize([result.doc]);
		if (!result.status) {
			return ctx.ok(result);
		}
		return ctx.ok({status: true, msg: "OK", doc: result.docs[0]});
	},
	bulkCreateSeller: async (ctx) => {
		if (!(ctx.session.userId || ctx.request.fields.userId)) {
			return ctx.ok({status: false, msg: "Session expired/invalid entry."});
		}
		const userId = ctx.session.userId || ctx.request.fields.userId;
		const companyId = ctx.request.fields.companyId || global.hostCompanyId;
		try {
			const uploadedFilePath = ctx.request.fields.upload[0].path;
			for (let loop = 0, length = ctx.request.files.length; loop < length; loop++) {
				if (ctx.request.files[loop].path != uploadedFilePath) {
					fs.unlinkSync(ctx.request.files[loop].path);
				}
			}
			if (!uploadedFilePath) {
				return ctx.ok({status: false, msg: "Parameter(s) missing."});
			}
			const XLSX = require("xlsx-style");
			let requiredJson = null;
			const workbook = XLSX.readFile(uploadedFilePath);
			const first_sheet_name = workbook.SheetNames[0];
			const worksheet = workbook.Sheets[first_sheet_name];
			requiredJson = XLSX.utils.sheet_to_json(worksheet, {raw: true});
			// const path = require("path");
			const fs = require("fs");
			fs.unlinkSync(uploadedFilePath);
			if (!requiredJson) {
				return ctx.ok({status: false, msg: "Uploaded file was empty or had data in unrecognised format."});
			}
			const validatorService = require("../services/bulkValidationService")(ctx);
			const validatedResult = await validatorService.validateSellers(requiredJson, userId, companyId);
			if (validatedResult.docs.length == 0 && validatedResult.outcome.length == 0) {
				return ctx.ok({
					status: false,
					msg: "Uploaded file was empty or had data in unrecognised format.",
				});
			} else if (validatedResult.docs.length == 0 && validatedResult.outcome.length > 0) {
				return ctx.ok({
					status: true,
					msg: "",
					outcome: validatedResult.outcome,
					successCount: 0,
				});
			} else {
				const model = require("../models/seller")(ctx);
				const sellerResult = await model.bulkCreate(validatedResult.docs);
				if (!sellerResult.status) {
					return ctx.ok({status: false, msg: "Illegal or invalid values."});
				}
				for (var loop = 0, length = sellerResult.result.outcome.length; loop < length; loop++) {
					validatedResult.outcome[validatedResult.ref[loop]] = sellerResult.result.outcome[loop];
				}
				let sellerResult2 = await model.list({companyId: ctx.ObjectID(companyId)});
				if (sellerResult2.status) {
					sellerResult2 = model.serialize(sellerResult2.docs);
				}
				if (sellerResult2.status) {
					return ctx.ok({
						status: true,
						msg: "",
						outcome: validatedResult.outcome,
						successCount: sellerResult.result.successCount,
						docs: sellerResult2.docs,
					});
				} else {
					return ctx.ok({
						status: true,
						msg: "",
						outcome: validatedResult.outcome,
						successCount: sellerResult.result.successCount,
					});
				}
			}
		} catch (err) {
			console.log(err);
			return ctx.ok({status: false, msg: "Illegal or invalid values."});
		}
	},
	createGrade: async (ctx) => {
		const codeVal = ctx.request.fields.code;
		const slnoVal = ctx.request.fields.slno;
		const categoryVal = ctx.request.fields.category;
		const subCategoryVal = ctx.request.fields.subCategory;
		const typeVal = ctx.request.fields.type;
		const subTypeVal = ctx.request.fields.subType;

		const now = new Date();
		const input = {
			code: codeVal,
			slno: slnoVal,
			category: categoryVal,
			subCategory: subCategoryVal,
			type: typeVal,
			subType: subTypeVal,
		};
		input.isActive = true;
		input.createdBy = ctx.session.userId || ctx.request.fields.userId;
		input.updatedBy = ctx.session.userId || ctx.request.fields.userId;
		if (!input.createdBy) {
			return ctx.ok({status: false, msg: "Session expired or invalid entry"});
		}
		input.companyId = ctx.request.fields.companyId || global.hostCompanyId;
		input.companyId = ctx.ObjectID(input.companyId);
		input.createdBy = ctx.ObjectID(input.createdBy);
		input.updatedBy = ctx.ObjectID(input.updatedBy);
		input.createdAt = now;
		input.updatedAt = now;

		const validationResult = gradeValidator(input);
		if (!validationResult.status) {
			return ctx.ok(validationResult);
		}
		const model = require("../models/grade")(ctx);
		let result = await model.create(validationResult.data);
		if (!result.status) {
			return ctx.ok(result);
		}
		result = model.serialize([result.doc]);
		if (!result.status) {
			return ctx.ok(result);
		}
		return ctx.ok({status: true, msg: "OK", doc: result.docs[0]});
	},
	updateGrade: async (ctx) => {
		if (!(ctx.request.fields.find && ctx.request.fields.update)) {
			return ctx.ok({status: false, msg: "Parameter(s) missing."});
		}
		const gradeId = ctx.request.fields.find;
		const codeVal = ctx.request.fields.update.code;
		const slnoVal = ctx.request.fields.update.slno;
		const categoryVal = ctx.request.fields.update.category;
		const subCategoryVal = ctx.request.fields.update.subCategory;
		const typeVal = ctx.request.fields.update.type;
		const subTypeVal = ctx.request.fields.update.subType;
		const isActiveVal = ctx.request.fields.update.isActive;

		const now = new Date();
		let input = {
			code: codeVal,
			slno: slnoVal,
			category: categoryVal,
			subCategory: subCategoryVal,
			type: typeVal,
			subType: subTypeVal,
			isActive: isActiveVal,
		};

		const validationResult = gradeValidator(input, true);
		if (!validationResult.status) {
			return ctx.ok(validationResult);
		}
		input = validationResult.data;
		input.updatedBy = ctx.session.userId || ctx.request.fields.userId;
		if (!input.updatedBy) {
			return ctx.ok({status: false, msg: "Session expired or invalid entry"});
		}
		input.updatedBy = ctx.ObjectID(input.updatedBy);
		input.updatedAt = now;
		const model = require("../models/grade")(ctx);
		let result = await model.update(gradeId, input);
		if (!result.status) {
			return ctx.ok(result);
		}
		result = model.serialize([result.doc]);
		if (!result.status) {
			return ctx.ok(result);
		}
		return ctx.ok({status: true, msg: "OK", doc: result.docs[0]});
	},
	bulkCreateGrade: async (ctx) => {
		if (!(ctx.session.userId || ctx.request.fields.userId)) {
			return ctx.ok({status: false, msg: "Session expired/invalid entry."});
		}
		const userId = ctx.session.userId || ctx.request.fields.userId;
		const companyId = ctx.request.fields.companyId || global.hostCompanyId;
		try {
			const uploadedFilePath = ctx.request.fields.upload[0].path;
			for (let loop = 0, length = ctx.request.files.length; loop < length; loop++) {
				if (ctx.request.files[loop].path != uploadedFilePath) {
					fs.unlinkSync(ctx.request.files[loop].path);
				}
			}
			if (!uploadedFilePath) {
				return ctx.ok({status: false, msg: "Parameter(s) missing."});
			}
			const XLSX = require("xlsx-style");
			let requiredJson = null;
			const workbook = XLSX.readFile(uploadedFilePath);
			const first_sheet_name = workbook.SheetNames[0];
			const worksheet = workbook.Sheets[first_sheet_name];
			requiredJson = XLSX.utils.sheet_to_json(worksheet, {raw: true});
			// const path = require("path");
			const fs = require("fs");
			fs.unlinkSync(uploadedFilePath);
			if (!requiredJson) {
				return ctx.ok({status: false, msg: "Uploaded file was empty or had data in unrecognised format."});
			}
			const validatorService = require("../services/bulkValidationService")(ctx);
			const validatedResult = await validatorService.validateGrades(requiredJson, userId, companyId);
			if (validatedResult.docs.length == 0 && validatedResult.outcome.length == 0) {
				return ctx.ok({
					status: false,
					msg: "Uploaded file was empty or had data in unrecognised format.",
				});
			} else if (validatedResult.docs.length == 0 && validatedResult.outcome.length > 0) {
				return ctx.ok({
					status: true,
					msg: "",
					outcome: validatedResult.outcome,
					successCount: 0,
				});
			} else {
				const model = require("../models/grade")(ctx);
				const gradeResult = await model.bulkCreate(validatedResult.docs);
				if (!gradeResult.status) {
					return ctx.ok({status: false, msg: "Illegal or invalid values."});
				}
				for (var loop = 0, length = gradeResult.result.outcome.length; loop < length; loop++) {
					validatedResult.outcome[validatedResult.ref[loop]] = gradeResult.result.outcome[loop];
				}
				let gradeResult2 = await model.list({companyId: ctx.ObjectID(companyId)});
				if (gradeResult2.status) {
					gradeResult2 = model.serialize(gradeResult2.docs);
				}
				if (gradeResult2.status) {
					return ctx.ok({
						status: true,
						msg: "",
						outcome: validatedResult.outcome,
						successCount: gradeResult.result.successCount,
						docs: gradeResult2.docs,
					});
				} else {
					return ctx.ok({
						status: true,
						msg: "",
						outcome: validatedResult.outcome,
						successCount: gradeResult.result.successCount,
					});
				}
			}
		} catch (err) {
			console.log(err);
			return ctx.ok({status: false, msg: "Illegal or invalid values."});
		}
	},
	createLocation: async (ctx) => {
		const nameVal = ctx.request.fields.name;
		const codeVal = ctx.request.fields.code;

		const now = new Date();
		const input = {
			name: nameVal,
			code: codeVal,
		};
		input.isActive = true;
		input.createdBy = ctx.session.userId || ctx.request.fields.userId;
		input.updatedBy = ctx.session.userId || ctx.request.fields.userId;
		if (!input.createdBy) {
			return ctx.ok({status: false, msg: "Session expired or invalid entry"});
		}
		input.companyId = ctx.request.fields.companyId || global.hostCompanyId;
		input.companyId = ctx.ObjectID(input.companyId);
		input.createdBy = ctx.ObjectID(input.createdBy);
		input.updatedBy = ctx.ObjectID(input.updatedBy);
		input.createdAt = now;
		input.updatedAt = now;

		const validationResult = locationValidator(input);
		if (!validationResult.status) {
			return ctx.ok(validationResult);
		}
		const model = require("../models/location")(ctx);
		let result = await model.create(validationResult.data);
		if (!result.status) {
			return ctx.ok(result);
		}
		result = model.serialize([result.doc]);
		if (!result.status) {
			return ctx.ok(result);
		}
		return ctx.ok({status: true, msg: "OK", doc: result.docs[0]});
	},
	updateLocation: async (ctx) => {
		if (!(ctx.request.fields.find && ctx.request.fields.update)) {
			return ctx.ok({status: false, msg: "Parameter(s) missing."});
		}
		const locationId = ctx.request.fields.find;
		const nameVal = ctx.request.fields.update.name;
		const codeVal = ctx.request.fields.update.code;
		const isActiveVal = ctx.request.fields.update.isActive;

		const now = new Date();
		let input = {
			name: nameVal,
			code: codeVal,
			isActive: isActiveVal,
		};

		const validationResult = locationValidator(input, true);
		if (!validationResult.status) {
			return ctx.ok(validationResult);
		}
		input = validationResult.data;
		input.updatedBy = ctx.session.userId || ctx.request.fields.userId;
		if (!input.updatedBy) {
			return ctx.ok({status: false, msg: "Session expired or invalid entry"});
		}
		input.updatedBy = ctx.ObjectID(input.updatedBy);
		input.updatedAt = now;
		const model = require("../models/location")(ctx);
		let result = await model.update(locationId, input);
		if (!result.status) {
			return ctx.ok(result);
		}
		result = model.serialize([result.doc]);
		if (!result.status) {
			return ctx.ok(result);
		}
		return ctx.ok({status: true, msg: "OK", doc: result.docs[0]});
	},
	bulkCreateLocation: async (ctx) => {
		if (!(ctx.session.userId || ctx.request.fields.userId)) {
			return ctx.ok({status: false, msg: "Session expired/invalid entry."});
		}
		const userId = ctx.session.userId || ctx.request.fields.userId;
		const companyId = ctx.request.fields.companyId || global.hostCompanyId;
		try {
			const uploadedFilePath = ctx.request.fields.upload[0].path;
			for (let loop = 0, length = ctx.request.files.length; loop < length; loop++) {
				if (ctx.request.files[loop].path != uploadedFilePath) {
					fs.unlinkSync(ctx.request.files[loop].path);
				}
			}
			if (!uploadedFilePath) {
				return ctx.ok({status: false, msg: "Parameter(s) missing."});
			}
			const XLSX = require("xlsx-style");
			let requiredJson = null;
			const workbook = XLSX.readFile(uploadedFilePath);
			const first_sheet_name = workbook.SheetNames[0];
			const worksheet = workbook.Sheets[first_sheet_name];
			requiredJson = XLSX.utils.sheet_to_json(worksheet);
			// const path = require("path");
			const fs = require("fs");
			fs.unlinkSync(uploadedFilePath);
			if (!requiredJson) {
				return ctx.ok({status: false, msg: "Uploaded file was empty or had data in unrecognised format."});
			}
			const validatorService = require("../services/bulkValidationService")(ctx);
			const validatedResult = await validatorService.validateLocations(requiredJson, userId, companyId);
			if (validatedResult.docs.length == 0 && validatedResult.outcome.length == 0) {
				return ctx.ok({
					status: false,
					msg: "Uploaded file was empty or had data in unrecognised format.",
				});
			} else if (validatedResult.docs.length == 0 && validatedResult.outcome.length > 0) {
				return ctx.ok({
					status: true,
					msg: "",
					outcome: validatedResult.outcome,
					successCount: 0,
				});
			} else {
				const model = require("../models/location")(ctx);
				const locationResult = await model.bulkCreate(validatedResult.docs);
				if (!locationResult.status) {
					return ctx.ok({status: false, msg: "Illegal or invalid values."});
				}
				for (var loop = 0, length = locationResult.result.outcome.length; loop < length; loop++) {
					validatedResult.outcome[validatedResult.ref[loop]] = locationResult.result.outcome[loop];
				}
				let locationResult2 = await model.list({companyId: ctx.ObjectID(companyId)});
				if (locationResult2.status) {
					locationResult2 = model.serialize(locationResult2.docs);
				}
				if (locationResult2.status) {
					return ctx.ok({
						status: true,
						msg: "",
						outcome: validatedResult.outcome,
						successCount: locationResult.result.successCount,
						docs: locationResult2.docs,
					});
				} else {
					return ctx.ok({
						status: true,
						msg: "",
						outcome: validatedResult.outcome,
						successCount: locationResult.result.successCount,
					});
				}
			}
		} catch (err) {
			console.log(err);
			return ctx.ok({status: false, msg: "Illegal or invalid values."});
		}
	},
	createMark: async (ctx) => {
		const nameVal = ctx.request.fields.name;
		const codeVal = ctx.request.fields.code;
		const typeVal = ctx.request.fields.type;
		const locationIdVal = ctx.request.fields.locationId;
		const regionVal = ctx.request.fields.region;
		const addressVal = ctx.request.fields.address;
		const latitudeVal = ctx.request.fields.latitude;
		const longitudeVal = ctx.request.fields.longitude;
		const categoryVal = ctx.request.fields.category;
		const annualProductionVal = ctx.request.fields.annualProduction;
		const ctmNoVal = ctx.request.fields.ctmNo;
		const haccpVal = ctx.request.fields.haccp;
		const haccpDateVal = ctx.request.fields.haccpDate;
		const trusteaVal = ctx.request.fields.trustea;
		const trusteaValidUptoVal = ctx.request.fields.trusteaValidUpto;
		const rainforestVal = ctx.request.fields.rainforest;
		const raValidUptoVal = ctx.request.fields.raValidUpto;
		const gardenISOVal = ctx.request.fields.gardenISO;
		const gardenISOValidUptoVal = ctx.request.fields.gardenISOValidUpto;
		const fssalNoVal = ctx.request.fields.fssalNo;
		const fssaiValidDateVal = ctx.request.fields.fssaiValidDate;
		const organicVal = ctx.request.fields.organic;
		const teaBoardRegNoVal = ctx.request.fields.teaBoardRegNo;
		const gardenAdvanceVal = ctx.request.fields.gardenAdvance;

		const now = new Date();
		const input = {
			name: nameVal,
			code: codeVal,
			type: typeVal,
			locationId: locationIdVal,
			region: regionVal,
			address: addressVal,
			latitude: latitudeVal,
			longitude: longitudeVal,
			category: categoryVal,
			annualProduction: annualProductionVal,
			ctmNo: ctmNoVal,
			haccp: haccpVal,
			haccpDate: haccpDateVal,
			trustea: trusteaVal,
			trusteaValidUpto: trusteaValidUptoVal,
			rainforest: rainforestVal,
			raValidUpto: raValidUptoVal,
			gardenISO: gardenISOVal,
			gardenISOValidUpto: gardenISOValidUptoVal,
			fssalNo: fssalNoVal,
			fssaiValidDate: fssaiValidDateVal,
			organic: organicVal,
			teaBoardRegNo: teaBoardRegNoVal,
			gardenAdvance: gardenAdvanceVal,
		};
		input.isActive = true;
		input.createdBy = ctx.session.userId || ctx.request.fields.userId;
		input.updatedBy = ctx.session.userId || ctx.request.fields.userId;
		if (!input.createdBy) {
			return ctx.ok({status: false, msg: "Session expired or invalid entry"});
		}
		input.companyId = ctx.request.fields.companyId || global.hostCompanyId;
		input.companyId = ctx.ObjectID(input.companyId);
		input.createdBy = ctx.ObjectID(input.createdBy);
		input.updatedBy = ctx.ObjectID(input.updatedBy);
		input.createdAt = now;
		input.updatedAt = now;

		const validationResult = markValidator(input);
		if (!validationResult.status) {
			return ctx.ok(validationResult);
		}
		const model = require("../models/mark")(ctx);
		let result = await model.create(validationResult.data);
		if (!result.status) {
			return ctx.ok(result);
		}
		result = model.serialize([result.doc]);
		if (!result.status) {
			return ctx.ok(result);
		}
		return ctx.ok({status: true, msg: "OK", doc: result.docs[0]});
	},
	updateMark: async (ctx) => {
		if (!(ctx.request.fields.find && ctx.request.fields.update)) {
			return ctx.ok({status: false, msg: "Parameter(s) missing."});
		}
		const markId = ctx.request.fields.find;
		const nameVal = ctx.request.fields.update.name;
		const codeVal = ctx.request.fields.update.code;
		const typeVal = ctx.request.fields.update.type;
		const locationIdVal = ctx.request.fields.update.locationId;
		const regionVal = ctx.request.fields.update.region;
		const addressVal = ctx.request.fields.update.address;
		const latitudeVal = ctx.request.fields.update.latitude;
		const longitudeVal = ctx.request.fields.update.longitude;
		const categoryVal = ctx.request.fields.update.category;
		const annualProductionVal = ctx.request.fields.update.annualProduction;
		const ctmNoVal = ctx.request.fields.update.ctmNo;
		const haccpVal = ctx.request.fields.update.haccp;
		const haccpDateVal = ctx.request.fields.update.haccpDate;
		const trusteaVal = ctx.request.fields.update.trustea;
		const trusteaValidUptoVal = ctx.request.fields.update.trusteaValidUpto;
		const rainforestVal = ctx.request.fields.update.rainforest;
		const raValidUptoVal = ctx.request.fields.update.raValidUpto;
		const gardenISOVal = ctx.request.fields.update.gardenISO;
		const gardenISOValidUptoVal = ctx.request.fields.update.gardenISOValidUpto;
		const fssalNoVal = ctx.request.fields.update.fssalNo;
		const fssaiValidDateVal = ctx.request.fields.update.fssaiValidDate;
		const organicVal = ctx.request.fields.update.organic;
		const teaBoardRegNoVal = ctx.request.fields.update.teaBoardRegNo;
		const gardenAdvanceVal = ctx.request.fields.update.gardenAdvance;
		const isActiveVal = ctx.request.fields.update.isActive;

		const now = new Date();
		let input = {
			name: nameVal,
			code: codeVal,
			type: typeVal,
			locationId: locationIdVal,
			region: regionVal,
			address: addressVal,
			latitude: latitudeVal,
			longitude: longitudeVal,
			category: categoryVal,
			annualProduction: annualProductionVal,
			ctmNo: ctmNoVal,
			haccp: haccpVal,
			haccpDate: haccpDateVal,
			trustea: trusteaVal,
			trusteaValidUpto: trusteaValidUptoVal,
			rainforest: rainforestVal,
			raValidUpto: raValidUptoVal,
			gardenISO: gardenISOVal,
			gardenISOValidUpto: gardenISOValidUptoVal,
			fssalNo: fssalNoVal,
			fssaiValidDate: fssaiValidDateVal,
			organic: organicVal,
			teaBoardRegNo: teaBoardRegNoVal,
			gardenAdvance: gardenAdvanceVal,
			isActive: isActiveVal,
		};

		const validationResult = markValidator(input, true);
		if (!validationResult.status) {
			return ctx.ok(validationResult);
		}
		input = validationResult.data;
		input.updatedBy = ctx.session.userId || ctx.request.fields.userId;
		if (!input.updatedBy) {
			return ctx.ok({status: false, msg: "Session expired or invalid entry"});
		}
		input.updatedBy = ctx.ObjectID(input.updatedBy);
		input.updatedAt = now;
		const model = require("../models/mark")(ctx);
		let result = await model.update(markId, input);
		if (!result.status) {
			return ctx.ok(result);
		}
		result = model.serialize([result.doc]);
		if (!result.status) {
			return ctx.ok(result);
		}
		return ctx.ok({status: true, msg: "OK", doc: result.docs[0]});
	},
	bulkCreateMark: async (ctx) => {
		if (!(ctx.session.userId || ctx.request.fields.userId)) {
			return ctx.ok({status: false, msg: "Session expired/invalid entry."});
		}
		const userId = ctx.session.userId || ctx.request.fields.userId;
		const companyId = ctx.request.fields.companyId || global.hostCompanyId;
		try {
			const uploadedFilePath = ctx.request.fields.upload[0].path;
			for (let loop = 0, length = ctx.request.files.length; loop < length; loop++) {
				if (ctx.request.files[loop].path != uploadedFilePath) {
					fs.unlinkSync(ctx.request.files[loop].path);
				}
			}
			if (!uploadedFilePath) {
				return ctx.ok({status: false, msg: "Parameter(s) missing."});
			}
			const XLSX = require("xlsx-style");
			let requiredJson = null;
			const workbook = XLSX.readFile(uploadedFilePath);
			const first_sheet_name = workbook.SheetNames[0];
			const worksheet = workbook.Sheets[first_sheet_name];
			requiredJson = XLSX.utils.sheet_to_json(worksheet, {raw: true});
			// const path = require("path");
			const fs = require("fs");
			fs.unlinkSync(uploadedFilePath);
			if (!requiredJson) {
				return ctx.ok({status: false, msg: "Uploaded file was empty or had data in unrecognised format."});
			}
			const validatorService = require("../services/bulkValidationService")(ctx);
			const validatedResult = await validatorService.validateMarks(requiredJson, userId, companyId);
			if (validatedResult.docs.length == 0 && validatedResult.outcome.length == 0) {
				return ctx.ok({
					status: false,
					msg: "Uploaded file was empty or had data in unrecognised format.",
				});
			} else if (validatedResult.docs.length == 0 && validatedResult.outcome.length > 0) {
				return ctx.ok({
					status: true,
					msg: "",
					outcome: validatedResult.outcome,
					successCount: 0,
				});
			} else {
				const model = require("../models/mark")(ctx);
				const markResult = await model.bulkCreate(validatedResult.docs);
				if (!markResult.status) {
					return ctx.ok({status: false, msg: "Illegal or invalid values."});
				}
				for (var loop = 0, length = markResult.result.outcome.length; loop < length; loop++) {
					validatedResult.outcome[validatedResult.ref[loop]] = markResult.result.outcome[loop];
				}
				let markResult2 = await model.list({companyId: ctx.ObjectID(companyId)});
				if (markResult2.status) {
					markResult2 = model.serialize(markResult2.docs);
				}
				if (markResult2.status) {
					return ctx.ok({
						status: true,
						msg: "",
						outcome: validatedResult.outcome,
						successCount: markResult.result.successCount,
						docs: markResult2.docs,
					});
				} else {
					return ctx.ok({
						status: true,
						msg: "",
						outcome: validatedResult.outcome,
						successCount: markResult.result.successCount,
					});
				}
			}
		} catch (err) {
			console.log(err);
			return ctx.ok({status: false, msg: "Illegal or invalid values."});
		}
	},
	updateTastingParam: async (ctx) => {
		if (!(ctx.request.fields.name && ctx.request.fields.values && ctx.request.fields.categories)) {
			return ctx.ok({status: false, msg: "Parameter(s) missing."});
		}
		let enableNotes = ctx.request.fields.enableNotes;
		if (!enableNotes) {
			enableNotes = false;
		} else {
			enableNotes = true;
		}
		let copyGradesByType = ctx.request.fields.copyGradesByType;
		if (!copyGradesByType) {
			copyGradesByType = false;
		} else {
			copyGradesByType = true;
		}
		const notes = ctx.request.fields.notes;
		const categories = ctx.request.fields.categories;
		const companyId = global.hostCompanyId;
		let userId = ctx.session.userId;
		if (!userId) {
			userId = ctx.request.fields.userId;
		}
		if (!(companyId && userId)) {
			return ctx.ok({status: false, msg: "Invalid request."});
		}
		const _id = ctx.request.fields._id;
		let slno = ctx.request.fields.slno;
		if (slno) {
			slno = Number(slno);
			if (isNaN(slno)) {
				return ctx.ok({status: false, msg: "Invalid Sl no."});
			}
		}
		const name = ctx.request.fields.name;
		const values = ctx.request.fields.values;
		const now = new Date();
		const input = {
			_id: _id,
			slno: slno,
			name: name.trim().toUpperCase(),
			values: values,
			enableNotes: enableNotes,
			copyGradesByType: copyGradesByType,
			categories: categories,
		};
		if (notes) {
			input.notes = notes;
		}
		if (!_id) {
			input.companyId = companyId;
			input.createdAt = now;
			input.createdBy = userId;
			input.isActive = true;
		} else {
			input.isActive = ctx.request.fields.isActive;
		}
		input.updatedAt = now;
		input.updatedBy = userId;
		const model = require("../models/tastingParam")(ctx);
		const result = await model.update(input);
		return ctx.ok(result);
	},
	createGroup: async (ctx) => {
		const nameVal = ctx.request.fields.name;
		const codeVal = ctx.request.fields.code;
		const contactPersonVal = ctx.request.fields.contactPerson;
		const emailVal = ctx.request.fields.email;
		const addressVal = ctx.request.fields.address;

		const now = new Date();
		const input = {
			name: nameVal,
			code: codeVal,
			contactPerson: contactPersonVal,
			email: emailVal,
			address: addressVal,
		};
		input.isActive = true;
		input.createdBy = ctx.session.userId || ctx.request.fields.userId;
		input.updatedBy = ctx.session.userId || ctx.request.fields.userId;
		if (!input.createdBy) {
			return ctx.ok({status: false, msg: "Session expired or invalid entry"});
		}
		input.companyId = ctx.request.fields.companyId || global.hostCompanyId;
		input.companyId = ctx.ObjectID(input.companyId);
		input.createdBy = ctx.ObjectID(input.createdBy);
		input.updatedBy = ctx.ObjectID(input.updatedBy);
		input.createdAt = now;
		input.updatedAt = now;

		const validationResult = groupValidator(input);
		if (!validationResult.status) {
			return ctx.ok(validationResult);
		}
		const model = require("../models/group")(ctx);
		let result = await model.create(validationResult.data);
		if (!result.status) {
			return ctx.ok(result);
		}
		result = model.serialize([result.doc]);
		if (!result.status) {
			return ctx.ok(result);
		}
		return ctx.ok({status: true, msg: "OK", doc: result.docs[0]});
	},
	updateGroup: async (ctx) => {
		if (!(ctx.request.fields.find && ctx.request.fields.update)) {
			return ctx.ok({status: false, msg: "Parameter(s) missing."});
		}
		const groupId = ctx.request.fields.find;
		const nameVal = ctx.request.fields.update.name;
		const codeVal = ctx.request.fields.update.code;
		const contactPersonVal = ctx.request.fields.update.contactPerson;
		const emailVal = ctx.request.fields.update.email;
		const addressVal = ctx.request.fields.update.address;
		const isActiveVal = ctx.request.fields.update.isActive;

		const now = new Date();
		let input = {
			name: nameVal,
			code: codeVal,
			contactPerson: contactPersonVal,
			email: emailVal,
			address: addressVal,
			isActive: isActiveVal,
		};

		const validationResult = groupValidator(input, true);
		if (!validationResult.status) {
			return ctx.ok(validationResult);
		}
		input = validationResult.data;
		input.updatedBy = ctx.session.userId || ctx.request.fields.userId;
		if (!input.updatedBy) {
			return ctx.ok({status: false, msg: "Session expired or invalid entry"});
		}
		input.updatedBy = ctx.ObjectID(input.updatedBy);
		input.updatedAt = now;
		const model = require("../models/group")(ctx);
		let result = await model.update(groupId, input);
		if (!result.status) {
			return ctx.ok(result);
		}
		result = model.serialize([result.doc]);
		if (!result.status) {
			return ctx.ok(result);
		}
		return ctx.ok({status: true, msg: "OK", doc: result.docs[0]});
	},
	bulkCreateGroup: async (ctx) => {
		if (!(ctx.session.userId || ctx.request.fields.userId)) {
			return ctx.ok({status: false, msg: "Session expired/invalid entry."});
		}
		const userId = ctx.session.userId || ctx.request.fields.userId;
		const companyId = ctx.request.fields.companyId || global.hostCompanyId;
		try {
			const uploadedFilePath = ctx.request.fields.upload[0].path;
			for (let loop = 0, length = ctx.request.files.length; loop < length; loop++) {
				if (ctx.request.files[loop].path != uploadedFilePath) {
					fs.unlinkSync(ctx.request.files[loop].path);
				}
			}
			if (!uploadedFilePath) {
				return ctx.ok({status: false, msg: "Parameter(s) missing."});
			}
			const XLSX = require("xlsx-style");
			let requiredJson = null;
			const workbook = XLSX.readFile(uploadedFilePath);
			const first_sheet_name = workbook.SheetNames[0];
			const worksheet = workbook.Sheets[first_sheet_name];
			requiredJson = XLSX.utils.sheet_to_json(worksheet, {raw: true});
			// const path = require("path");
			const fs = require("fs");
			fs.unlinkSync(uploadedFilePath);
			if (!requiredJson) {
				return ctx.ok({status: false, msg: "Uploaded file was empty or had data in unrecognised format."});
			}
			const validatorService = require("../services/bulkValidationService")(ctx);
			const validatedResult = await validatorService.validateGroups(requiredJson, userId, companyId);
			if (validatedResult.docs.length == 0 && validatedResult.outcome.length == 0) {
				return ctx.ok({
					status: false,
					msg: "Uploaded file was empty or had data in unrecognised format.",
				});
			} else if (validatedResult.docs.length == 0 && validatedResult.outcome.length > 0) {
				return ctx.ok({
					status: true,
					msg: "",
					outcome: validatedResult.outcome,
					successCount: 0,
				});
			} else {
				const model = require("../models/group")(ctx);
				const groupResult = await model.bulkCreate(validatedResult.docs);
				if (!groupResult.status) {
					return ctx.ok({status: false, msg: "Illegal or invalid values."});
				}
				for (var loop = 0, length = groupResult.result.outcome.length; loop < length; loop++) {
					validatedResult.outcome[validatedResult.ref[loop]] = groupResult.result.outcome[loop];
				}
				let groupResult2 = await model.list({companyId: ctx.ObjectID(companyId)});
				if (groupResult2.status) {
					groupResult2 = model.serialize(groupResult2.docs);
				}
				if (groupResult2.status) {
					return ctx.ok({
						status: true,
						msg: "",
						outcome: validatedResult.outcome,
						successCount: groupResult.result.successCount,
						docs: groupResult2.docs,
					});
				} else {
					return ctx.ok({
						status: true,
						msg: "",
						outcome: validatedResult.outcome,
						successCount: groupResult.result.successCount,
					});
				}
			}
		} catch (err) {
			console.log(err);
			return ctx.ok({status: false, msg: "Illegal or invalid values."});
		}
	},
	createAuctionCenter: async (ctx) => {
		const nameVal = ctx.request.fields.name;
		const codeVal = ctx.request.fields.code;

		const now = new Date();
		const input = {
			name: nameVal,
			code: codeVal,
		};
		input.isActive = true;
		input.createdBy = ctx.session.userId || ctx.request.fields.userId;
		input.updatedBy = ctx.session.userId || ctx.request.fields.userId;
		if (!input.createdBy) {
			return ctx.ok({status: false, msg: "Session expired or invalid entry"});
		}
		input.companyId = ctx.request.fields.companyId || global.hostCompanyId;
		input.companyId = ctx.ObjectID(input.companyId);
		input.createdBy = ctx.ObjectID(input.createdBy);
		input.updatedBy = ctx.ObjectID(input.updatedBy);
		input.createdAt = now;
		input.updatedAt = now;

		const validationResult = auctionCenterValidator(input);
		if (!validationResult.status) {
			return ctx.ok(validationResult);
		}
		const model = require("../models/auctionCenter")(ctx);
		let result = await model.create(validationResult.data);
		if (!result.status) {
			return ctx.ok(result);
		}
		result = model.serialize([result.doc]);
		if (!result.status) {
			return ctx.ok(result);
		}
		return ctx.ok({status: true, msg: "OK", doc: result.docs[0]});
	},
	updateAuctionCenter: async (ctx) => {
		if (!(ctx.request.fields.find && ctx.request.fields.update)) {
			return ctx.ok({status: false, msg: "Parameter(s) missing."});
		}
		const auctionCenterId = ctx.request.fields.find;
		const nameVal = ctx.request.fields.update.name;
		const codeVal = ctx.request.fields.update.code;
		const isActiveVal = ctx.request.fields.update.isActive;

		const now = new Date();
		let input = {
			name: nameVal,
			code: codeVal,
			isActive: isActiveVal,
		};

		const validationResult = auctionCenterValidator(input, true);
		if (!validationResult.status) {
			return ctx.ok(validationResult);
		}
		input = validationResult.data;
		input.updatedBy = ctx.session.userId || ctx.request.fields.userId;
		if (!input.updatedBy) {
			return ctx.ok({status: false, msg: "Session expired or invalid entry"});
		}
		input.updatedBy = ctx.ObjectID(input.updatedBy);
		input.updatedAt = now;
		const model = require("../models/auctionCenter")(ctx);
		let result = await model.update(auctionCenterId, input);
		if (!result.status) {
			return ctx.ok(result);
		}
		result = model.serialize([result.doc]);
		if (!result.status) {
			return ctx.ok(result);
		}
		return ctx.ok({status: true, msg: "OK", doc: result.docs[0]});
	},
	bulkCreateAuctionCenter: async (ctx) => {
		if (!(ctx.session.userId || ctx.request.fields.userId)) {
			return ctx.ok({status: false, msg: "Session expired/invalid entry."});
		}
		const userId = ctx.session.userId || ctx.request.fields.userId;
		const companyId = ctx.request.fields.companyId || global.hostCompanyId;
		try {
			const uploadedFilePath = ctx.request.fields.upload[0].path;
			for (let loop = 0, length = ctx.request.files.length; loop < length; loop++) {
				if (ctx.request.files[loop].path != uploadedFilePath) {
					fs.unlinkSync(ctx.request.files[loop].path);
				}
			}
			if (!uploadedFilePath) {
				return ctx.ok({status: false, msg: "Parameter(s) missing."});
			}
			const XLSX = require("xlsx-style");
			let requiredJson = null;
			const workbook = XLSX.readFile(uploadedFilePath);
			const first_sheet_name = workbook.SheetNames[0];
			const worksheet = workbook.Sheets[first_sheet_name];
			requiredJson = XLSX.utils.sheet_to_json(worksheet, {raw: true});
			// const path = require("path");
			const fs = require("fs");
			fs.unlinkSync(uploadedFilePath);
			if (!requiredJson) {
				return ctx.ok({status: false, msg: "Uploaded file was empty or had data in unrecognised format."});
			}
			const validatorService = require("../services/bulkValidationService")(ctx);
			const validatedResult = await validatorService.validateAuctionCenters(requiredJson, userId, companyId);
			if (validatedResult.docs.length == 0 && validatedResult.outcome.length == 0) {
				return ctx.ok({
					status: false,
					msg: "Uploaded file was empty or had data in unrecognised format.",
				});
			} else if (validatedResult.docs.length == 0 && validatedResult.outcome.length > 0) {
				return ctx.ok({
					status: true,
					msg: "",
					outcome: validatedResult.outcome,
					successCount: 0,
				});
			} else {
				const model = require("../models/auctionCenter")(ctx);
				const auctionCenterResult = await model.bulkCreate(validatedResult.docs);
				if (!auctionCenterResult.status) {
					return ctx.ok({status: false, msg: "Illegal or invalid values."});
				}
				for (var loop = 0, length = auctionCenterResult.result.outcome.length; loop < length; loop++) {
					validatedResult.outcome[validatedResult.ref[loop]] = auctionCenterResult.result.outcome[loop];
				}
				let auctionCenterResult2 = await model.list({companyId: ctx.ObjectID(companyId)});
				if (auctionCenterResult2.status) {
					auctionCenterResult2 = model.serialize(auctionCenterResult2.docs);
				}
				if (auctionCenterResult2.status) {
					return ctx.ok({
						status: true,
						msg: "",
						outcome: validatedResult.outcome,
						successCount: auctionCenterResult.result.successCount,
						docs: auctionCenterResult2.docs,
					});
				} else {
					return ctx.ok({
						status: true,
						msg: "",
						outcome: validatedResult.outcome,
						successCount: auctionCenterResult.result.successCount,
					});
				}
			}
		} catch (err) {
			console.log(err);
			return ctx.ok({status: false, msg: "Illegal or invalid values."});
		}
	},
	createGroupSellerMapping: async (ctx) => {
		const groupVal = ctx.request.fields.group;
		const sellerVal = ctx.request.fields.seller;
		const dateFromVal = ctx.request.fields.dateFrom;
		const dateToVal = ctx.request.fields.dateTo;

		const now = new Date();
		const input = {
			group: groupVal,
			seller: sellerVal,
			dateFrom: dateFromVal,
			dateTo: dateToVal,
		};
		input.isActive = true;
		input.createdBy = ctx.session.userId || ctx.request.fields.userId;
		input.updatedBy = ctx.session.userId || ctx.request.fields.userId;
		if (!input.createdBy) {
			return ctx.ok({status: false, msg: "Session expired or invalid entry"});
		}
		input.companyId = ctx.request.fields.companyId || global.hostCompanyId;
		input.companyId = ctx.ObjectID(input.companyId);
		input.createdBy = ctx.ObjectID(input.createdBy);
		input.updatedBy = ctx.ObjectID(input.updatedBy);
		input.createdAt = now;
		input.updatedAt = now;

		const validationResult = groupSellerMappingValidator(input);
		if (!validationResult.status) {
			return ctx.ok(validationResult);
		}
		const model = require("../models/groupSellerMapping")(ctx);
		let result = await model.create(validationResult.data);
		if (!result.status) {
			return ctx.ok(result);
		}
		result = model.serialize([result.doc]);
		if (!result.status) {
			return ctx.ok(result);
		}
		return ctx.ok({status: true, msg: "OK", doc: result.docs[0]});
	},
	updateGroupSellerMapping: async (ctx) => {
		if (!(ctx.request.fields.find && ctx.request.fields.update)) {
			return ctx.ok({status: false, msg: "Parameter(s) missing."});
		}
		const groupSellerMappingId = ctx.request.fields.find;
		const groupVal = ctx.request.fields.update.group;
		const sellerVal = ctx.request.fields.update.seller;
		const dateFromVal = ctx.request.fields.update.dateFrom;
		const dateToVal = ctx.request.fields.update.dateTo;
		const isActiveVal = ctx.request.fields.update.isActive;

		const now = new Date();
		let input = {
			group: groupVal,
			seller: sellerVal,
			dateFrom: dateFromVal,
			dateTo: dateToVal,
			isActive: isActiveVal,
		};

		const validationResult = groupSellerMappingValidator(input, true);
		if (!validationResult.status) {
			return ctx.ok(validationResult);
		}
		input = validationResult.data;
		input.updatedBy = ctx.session.userId || ctx.request.fields.userId;
		if (!input.updatedBy) {
			return ctx.ok({status: false, msg: "Session expired or invalid entry"});
		}
		input.updatedBy = ctx.ObjectID(input.updatedBy);
		input.updatedAt = now;
		const model = require("../models/groupSellerMapping")(ctx);
		let result = await model.update(groupSellerMappingId, input);
		if (!result.status) {
			return ctx.ok(result);
		}
		result = model.serialize([result.doc]);
		if (!result.status) {
			return ctx.ok(result);
		}
		return ctx.ok({status: true, msg: "OK", doc: result.docs[0]});
	},
	bulkCreateGroupSellerMapping: async (ctx) => {
		if (!(ctx.session.userId || ctx.request.fields.userId)) {
			return ctx.ok({status: false, msg: "Session expired/invalid entry."});
		}
		const userId = ctx.session.userId || ctx.request.fields.userId;
		const companyId = ctx.request.fields.companyId || global.hostCompanyId;
		try {
			const uploadedFilePath = ctx.request.fields.upload[0].path;
			for (let loop = 0, length = ctx.request.files.length; loop < length; loop++) {
				if (ctx.request.files[loop].path != uploadedFilePath) {
					fs.unlinkSync(ctx.request.files[loop].path);
				}
			}
			if (!uploadedFilePath) {
				return ctx.ok({status: false, msg: "Parameter(s) missing."});
			}
			const XLSX = require("xlsx-style");
			let requiredJson = null;
			const workbook = XLSX.readFile(uploadedFilePath);
			const first_sheet_name = workbook.SheetNames[0];
			const worksheet = workbook.Sheets[first_sheet_name];
			requiredJson = XLSX.utils.sheet_to_json(worksheet, {raw: true});
			// const path = require("path");
			const fs = require("fs");
			fs.unlinkSync(uploadedFilePath);
			if (!requiredJson) {
				return ctx.ok({status: false, msg: "Uploaded file was empty or had data in unrecognised format."});
			}
			const validatorService = require("../services/bulkValidationService")(ctx);
			const validatedResult = await validatorService.validateGroupSellerMappings(requiredJson, userId, companyId);
			if (validatedResult.docs.length == 0 && validatedResult.outcome.length == 0) {
				return ctx.ok({
					status: false,
					msg: "Uploaded file was empty or had data in unrecognised format.",
				});
			} else if (validatedResult.docs.length == 0 && validatedResult.outcome.length > 0) {
				return ctx.ok({
					status: true,
					msg: "",
					outcome: validatedResult.outcome,
					successCount: 0,
				});
			} else {
				const model = require("../models/groupSellerMapping")(ctx);
				const groupSellerMappingResult = await model.bulkCreate(validatedResult.docs);
				if (!groupSellerMappingResult.status) {
					return ctx.ok({status: false, msg: "Illegal or invalid values."});
				}
				for (var loop = 0, length = groupSellerMappingResult.result.outcome.length; loop < length; loop++) {
					validatedResult.outcome[validatedResult.ref[loop]] = groupSellerMappingResult.result.outcome[loop];
				}
				let groupSellerMappingResult2 = await model.list({companyId: ctx.ObjectID(companyId)});
				if (groupSellerMappingResult2.status) {
					groupSellerMappingResult2 = model.serialize(groupSellerMappingResult2.docs);
				}
				if (groupSellerMappingResult2.status) {
					return ctx.ok({
						status: true,
						msg: "",
						outcome: validatedResult.outcome,
						successCount: groupSellerMappingResult.result.successCount,
						docs: groupSellerMappingResult2.docs,
					});
				} else {
					return ctx.ok({
						status: true,
						msg: "",
						outcome: validatedResult.outcome,
						successCount: groupSellerMappingResult.result.successCount,
					});
				}
			}
		} catch (err) {
			console.log(err);
			return ctx.ok({status: false, msg: "Illegal or invalid values."});
		}
	},
	createSellerMarkMapping: async (ctx) => {
		const sellerVal = ctx.request.fields.seller;
		const markVal = ctx.request.fields.mark;
		const dateFromVal = ctx.request.fields.dateFrom;
		const dateToVal = ctx.request.fields.dateTo;

		const now = new Date();
		const input = {
			seller: sellerVal,
			mark: markVal,
			dateFrom: dateFromVal,
			dateTo: dateToVal,
		};
		input.isActive = true;
		input.createdBy = ctx.session.userId || ctx.request.fields.userId;
		input.updatedBy = ctx.session.userId || ctx.request.fields.userId;
		if (!input.createdBy) {
			return ctx.ok({status: false, msg: "Session expired or invalid entry"});
		}
		input.companyId = ctx.request.fields.companyId || global.hostCompanyId;
		input.companyId = ctx.ObjectID(input.companyId);
		input.createdBy = ctx.ObjectID(input.createdBy);
		input.updatedBy = ctx.ObjectID(input.updatedBy);
		input.createdAt = now;
		input.updatedAt = now;

		const validationResult = sellerMarkMappingValidator(input);
		if (!validationResult.status) {
			return ctx.ok(validationResult);
		}
		const model = require("../models/sellerMarkMapping")(ctx);
		let result = await model.create(validationResult.data);
		if (!result.status) {
			return ctx.ok(result);
		}
		result = model.serialize([result.doc]);
		if (!result.status) {
			return ctx.ok(result);
		}
		return ctx.ok({status: true, msg: "OK", doc: result.docs[0]});
	},
	updateSellerMarkMapping: async (ctx) => {
		if (!(ctx.request.fields.find && ctx.request.fields.update)) {
			return ctx.ok({status: false, msg: "Parameter(s) missing."});
		}
		const sellerMarkMappingId = ctx.request.fields.find;
		const sellerVal = ctx.request.fields.update.seller;
		const markVal = ctx.request.fields.update.mark;
		const dateFromVal = ctx.request.fields.update.dateFrom;
		const dateToVal = ctx.request.fields.update.dateTo;
		const isActiveVal = ctx.request.fields.update.isActive;

		const now = new Date();
		let input = {
			seller: sellerVal,
			mark: markVal,
			dateFrom: dateFromVal,
			dateTo: dateToVal,
			isActive: isActiveVal,
		};

		const validationResult = sellerMarkMappingValidator(input, true);
		if (!validationResult.status) {
			return ctx.ok(validationResult);
		}
		input = validationResult.data;
		input.updatedBy = ctx.session.userId || ctx.request.fields.userId;
		if (!input.updatedBy) {
			return ctx.ok({status: false, msg: "Session expired or invalid entry"});
		}
		input.updatedBy = ctx.ObjectID(input.updatedBy);
		input.updatedAt = now;
		const model = require("../models/sellerMarkMapping")(ctx);
		let result = await model.update(sellerMarkMappingId, input);
		if (!result.status) {
			return ctx.ok(result);
		}
		result = model.serialize([result.doc]);
		if (!result.status) {
			return ctx.ok(result);
		}
		return ctx.ok({status: true, msg: "OK", doc: result.docs[0]});
	},
	bulkCreateSellerMarkMapping: async (ctx) => {
		if (!(ctx.session.userId || ctx.request.fields.userId)) {
			return ctx.ok({status: false, msg: "Session expired/invalid entry."});
		}
		const userId = ctx.session.userId || ctx.request.fields.userId;
		const companyId = ctx.request.fields.companyId || global.hostCompanyId;
		try {
			const uploadedFilePath = ctx.request.fields.upload[0].path;
			for (let loop = 0, length = ctx.request.files.length; loop < length; loop++) {
				if (ctx.request.files[loop].path != uploadedFilePath) {
					fs.unlinkSync(ctx.request.files[loop].path);
				}
			}
			if (!uploadedFilePath) {
				return ctx.ok({status: false, msg: "Parameter(s) missing."});
			}
			const XLSX = require("xlsx-style");
			let requiredJson = null;
			const workbook = XLSX.readFile(uploadedFilePath);
			const first_sheet_name = workbook.SheetNames[0];
			const worksheet = workbook.Sheets[first_sheet_name];
			requiredJson = XLSX.utils.sheet_to_json(worksheet, {raw: true});
			// const path = require("path");
			const fs = require("fs");
			fs.unlinkSync(uploadedFilePath);
			if (!requiredJson) {
				return ctx.ok({status: false, msg: "Uploaded file was empty or had data in unrecognised format."});
			}
			const validatorService = require("../services/bulkValidationService")(ctx);
			const validatedResult = await validatorService.validateSellerMarkMappings(requiredJson, userId, companyId);
			if (validatedResult.docs.length == 0 && validatedResult.outcome.length == 0) {
				return ctx.ok({
					status: false,
					msg: "Uploaded file was empty or had data in unrecognised format.",
				});
			} else if (validatedResult.docs.length == 0 && validatedResult.outcome.length > 0) {
				return ctx.ok({
					status: true,
					msg: "",
					outcome: validatedResult.outcome,
					successCount: 0,
				});
			} else {
				const model = require("../models/sellerMarkMapping")(ctx);
				const sellerMarkMappingResult = await model.bulkCreate(validatedResult.docs);
				if (!sellerMarkMappingResult.status) {
					return ctx.ok({status: false, msg: "Illegal or invalid values."});
				}
				for (var loop = 0, length = sellerMarkMappingResult.result.outcome.length; loop < length; loop++) {
					validatedResult.outcome[validatedResult.ref[loop]] = sellerMarkMappingResult.result.outcome[loop];
				}
				let sellerMarkMappingResult2 = await model.list({companyId: ctx.ObjectID(companyId)});
				if (sellerMarkMappingResult2.status) {
					sellerMarkMappingResult2 = model.serialize(sellerMarkMappingResult2.docs);
				}
				if (sellerMarkMappingResult2.status) {
					return ctx.ok({
						status: true,
						msg: "",
						outcome: validatedResult.outcome,
						successCount: sellerMarkMappingResult.result.successCount,
						docs: sellerMarkMappingResult2.docs,
					});
				} else {
					return ctx.ok({
						status: true,
						msg: "",
						outcome: validatedResult.outcome,
						successCount: sellerMarkMappingResult.result.successCount,
					});
				}
			}
		} catch (err) {
			console.log(err);
			return ctx.ok({status: false, msg: "Illegal or invalid values."});
		}
	},
	createMarkACMapping: async (ctx) => {
		const locationVal = ctx.request.fields.location;
		const markVal = ctx.request.fields.mark;
		const auctionCenterVal = ctx.request.fields.auctionCenter;
		const markEntityCodeVal = ctx.request.fields.markEntityCode;
		const eAuctionNameVal = ctx.request.fields.eAuctionName;

		const now = new Date();
		const input = {
			location: locationVal,
			mark: markVal,
			auctionCenter: auctionCenterVal,
			markEntityCode: markEntityCodeVal,
			eAuctionName: eAuctionNameVal,
		};
		input.isActive = true;
		input.createdBy = ctx.session.userId || ctx.request.fields.userId;
		input.updatedBy = ctx.session.userId || ctx.request.fields.userId;
		if (!input.createdBy) {
			return ctx.ok({status: false, msg: "Session expired or invalid entry"});
		}
		input.companyId = ctx.request.fields.companyId || global.hostCompanyId;
		input.companyId = ctx.ObjectID(input.companyId);
		input.createdBy = ctx.ObjectID(input.createdBy);
		input.updatedBy = ctx.ObjectID(input.updatedBy);
		input.createdAt = now;
		input.updatedAt = now;

		const validationResult = markACMappingValidator(input);
		if (!validationResult.status) {
			return ctx.ok(validationResult);
		}
		const model = require("../models/markEntityMapping")(ctx);
		let result = await model.create(validationResult.data);
		if (!result.status) {
			return ctx.ok(result);
		}
		result = model.serialize([result.doc]);
		if (!result.status) {
			return ctx.ok(result);
		}
		return ctx.ok({status: true, msg: "OK", doc: result.docs[0]});
	},
	updateMarkACMapping: async (ctx) => {
		if (!(ctx.request.fields.find && ctx.request.fields.update)) {
			return ctx.ok({status: false, msg: "Parameter(s) missing."});
		}
		const markACMappingId = ctx.request.fields.find;
		const locationVal = ctx.request.fields.update.location;
		const markVal = ctx.request.fields.update.mark;
		const auctionCenterVal = ctx.request.fields.update.auctionCenter;
		const markEntityCodeVal = ctx.request.fields.update.markEntityCode;
		const eAuctionNameVal = ctx.request.fields.update.eAuctionName;
		const isActiveVal = ctx.request.fields.update.isActive;

		const now = new Date();
		let input = {
			location: locationVal,
			mark: markVal,
			auctionCenter: auctionCenterVal,
			markEntityCode: markEntityCodeVal,
			eAuctionName: eAuctionNameVal,
			isActive: isActiveVal,
		};

		const validationResult = markACMappingValidator(input, true);
		if (!validationResult.status) {
			return ctx.ok(validationResult);
		}
		input = validationResult.data;
		input.updatedBy = ctx.session.userId || ctx.request.fields.userId;
		if (!input.updatedBy) {
			return ctx.ok({status: false, msg: "Session expired or invalid entry"});
		}
		input.updatedBy = ctx.ObjectID(input.updatedBy);
		input.updatedAt = now;
		const model = require("../models/markEntityMapping")(ctx);
		let result = await model.update(markACMappingId, input);
		if (!result.status) {
			return ctx.ok(result);
		}
		result = model.serialize([result.doc]);
		if (!result.status) {
			return ctx.ok(result);
		}
		return ctx.ok({status: true, msg: "OK", doc: result.docs[0]});
	},
	bulkCreateMarkACMapping: async (ctx) => {
		if (!(ctx.session.userId || ctx.request.fields.userId)) {
			return ctx.ok({status: false, msg: "Session expired/invalid entry."});
		}
		const userId = ctx.session.userId || ctx.request.fields.userId;
		const companyId = ctx.request.fields.companyId || global.hostCompanyId;
		try {
			const uploadedFilePath = ctx.request.fields.upload[0].path;
			for (let loop = 0, length = ctx.request.files.length; loop < length; loop++) {
				if (ctx.request.files[loop].path != uploadedFilePath) {
					fs.unlinkSync(ctx.request.files[loop].path);
				}
			}
			if (!uploadedFilePath) {
				return ctx.ok({status: false, msg: "Parameter(s) missing."});
			}
			const XLSX = require("xlsx-style");
			let requiredJson = null;
			const workbook = XLSX.readFile(uploadedFilePath);
			const first_sheet_name = workbook.SheetNames[0];
			const worksheet = workbook.Sheets[first_sheet_name];
			requiredJson = XLSX.utils.sheet_to_json(worksheet, {raw: true});
			// const path = require("path");
			const fs = require("fs");
			fs.unlinkSync(uploadedFilePath);
			if (!requiredJson) {
				return ctx.ok({status: false, msg: "Uploaded file was empty or had data in unrecognised format."});
			}
			const validatorService = require("../services/bulkValidationService")(ctx);
			const validatedResult = await validatorService.validateMarkACMappings(requiredJson, userId, companyId);
			if (validatedResult.docs.length == 0 && validatedResult.outcome.length == 0) {
				return ctx.ok({
					status: false,
					msg: "Uploaded file was empty or had data in unrecognised format.",
				});
			} else if (validatedResult.docs.length == 0 && validatedResult.outcome.length > 0) {
				return ctx.ok({
					status: true,
					msg: "",
					outcome: validatedResult.outcome,
					successCount: 0,
				});
			} else {
				const model = require("../models/markEntityMapping")(ctx);
				const markACMappingResult = await model.bulkCreate(validatedResult.docs);
				if (!markACMappingResult.status) {
					return ctx.ok({status: false, msg: "Illegal or invalid values."});
				}
				for (var loop = 0, length = markACMappingResult.result.outcome.length; loop < length; loop++) {
					validatedResult.outcome[validatedResult.ref[loop]] = markACMappingResult.result.outcome[loop];
				}
				let markACMappingResult2 = await model.list({companyId: ctx.ObjectID(companyId)});
				if (markACMappingResult2.status) {
					markACMappingResult2 = model.serialize(markACMappingResult2.docs);
				}
				if (markACMappingResult2.status) {
					return ctx.ok({
						status: true,
						msg: "",
						outcome: validatedResult.outcome,
						successCount: markACMappingResult.result.successCount,
						docs: markACMappingResult2.docs,
					});
				} else {
					return ctx.ok({
						status: true,
						msg: "",
						outcome: validatedResult.outcome,
						successCount: markACMappingResult.result.successCount,
					});
				}
			}
		} catch (err) {
			console.log(err);
			return ctx.ok({status: false, msg: "Illegal or invalid values."});
		}
	},
};
