const hbs = require("handlebars");
const nodemailer = require("nodemailer");
const Email = require("email-templates");
const path = require("path");
const fs = require("fs");

var partialsDir = path.join(__dirname, "../emails", "partials");
var partialFilenames = fs.readdirSync(partialsDir);

partialFilenames.forEach(function(filename) {
	var matches = /^([^.]+).handlebars$/.exec(filename);
	if (!matches) {
		return;
	}
	var partialname = matches[1];
	var template = fs.readFileSync(partialsDir + "/" + filename, "utf8");
	hbs.registerPartial(partialname, template);
});

const transport = nodemailer.createTransport({
	host: "smtp.zoho.com",
	port: 465,
	secure: true,
	auth: {
		user: "no-reply-mpower@illimitable.in",
		pass: "manpower",
	},
	tls: {
		rejectUnauthorized: false,
	},
});

const email = new Email({
	message: {
		from: "\"Do Not Reply\" <no-reply-mpower@illimitable.in>",
	},
	transport: transport,
	htmlToText: false,
	views: {
		options: {
			extension: "handlebars",
		},
	},
	juice: true,
	preview: false,
	send: true,
	juiceResources: {
		preserveImportant: true,
		webResources: {
			relativeTo: path.join(__dirname, "../emails"),
		},
	},
});

email.config.views.options.engineSource.requires.handlebars = hbs;

icplApp.email = email;
