/* eslint no-useless-escape: 0 */

// const ChangeCase = require("change-case");
const emailRegex = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
const _ = require("lodash");
const moment = require("moment");
// const dayOfWeeks = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"];
const offset = new Date().getTimezoneOffsetMills();
const excelDateToJSDate = function(date) {
	return new Date(Math.round(((date - 25569)*86400*1000)+offset));
};

const isValidDate = function(d) {
	if (Object.prototype.toString.call(d) === "[object Date]") {
		if (isNaN(d.getTime())) {
			return false;
		} else {
			return true;
		}
	} else {
		return false;
	}
};

const userValidationMap = {
	username: {
		name: "userName",
		min: {
			val: 5,
			msg: "username must be atleast 5 character long.",
		},
		max: {
			val: 30,
			msg: "username can maximum be 30 character long.",
		},
		nullable: {
			val: false,
			msg: "username is required.",
		},
		transform: "TitleCase",
	},
	code: {
		name: "code",
		min: {
			val: 2,
			msg: "code must be atleast 2 character long.",
		},
		max: {
			val: 5,
			msg: "code can maximum be 5 character long.",
		},
		nullable: {
			val: false,
			msg: "code is required.",
		},
		transform: "UpperCase",
	},
	emailid: {
		name: "userEmail",
		max: {
			val: 30,
			msg: "emailid can maximum be 30 character long.",
		},
		email: {
			val: true,
			msg: "emailid must be a valid Email Id",
		},
		nullable: {
			val: false,
			msg: "emailid is required.",
		},
		transform: "LowerCase",
	},
	contactnumber: {
		name: "contactNumber",
		length: {
			val: 10,
			msg: "contactnumber must be a 10 digit number.",
		},
		numeric: {
			val: true,
			msg: "contactnumber must be Numeric.",
		},
		nullable: {
			val: true,
			msg: "",
		},
	},
	usertype: {
		name: "userType",
		exists: {
			val: true,
			msg: "usertype must be an existing User Type.",
		},
		nullable: {
			val: false,
			msg: "usertype is required.",
		},
		custom: {
			val: null,
			msg: "invalid usertype",
		},
	},
	loginid: {
		name: "loginId",
		min: {
			val: 5,
			msg: "loginid must be atleast 4 character long.",
		},
		max: {
			val: 30,
			msg: "loginid can maximum be 20 character long.",
		},
		nullable: {
			val: false,
			msg: "loginid is required.",
		},
		transform: "LowerCase",
	},
	password: {
		name: "password",
		min: {
			val: 5,
			msg: "password must be atleast 5 character long.",
		},
		max: {
			val: 30,
			msg: "password can maximum be 10 character long.",
		},
		nullable: {
			val: false,
			msg: "password is required.",
		},
		custom: {
			val: null,
			msg: "invalid password",
		},
	},
	reportsto: {
		name: "parentUserId",
		nullable: {
			val: true,
			msg: "",
		},
	},
};

const categoriesValidationMap = {
	name: {
		name: "name",
		label: "Name",
		nullable: {
			val: false,
			msg: "Name is required.",
		},
		min: {
			val: 2,
			msg: "Name must be atleast 2 character long",
		},
		max: {
			val: 80,
			msg: "Name can maximum be 80 character long",
		},
		transform: "UpperCase",
	},
	code: {
		name: "code",
		label: "Code",
		nullable: {
			val: false,
			msg: "Code is required.",
		},
		min: {
			val: 1,
			msg: "Code must be atleast 1 character long",
		},
		max: {
			val: 10,
			msg: "Code can maximum be 10 character long",
		},
		transform: "UpperCase",
	},
	descriptiveremark: {
		name: "descriptiveRemarks",
		label: "Descriptive Remark",
		nullable: {
			val: false,
			msg: "Descriptive Remark is required.",
		},
		transform: "Boolean",
	},
};

const sellersValidationMap = {
	sellername: {
		name: "name",
		label: "Seller Name",
		nullable: {
			val: false,
			msg: "Seller Name is required.",
		},
		min: {
			val: 4,
			msg: "Seller Name must be atleast 4 character long",
		},
		max: {
			val: 80,
			msg: "Seller Name can maximum be 80 character long",
		},
		transform: "TitleCase",
	},
	sellercode: {
		name: "code",
		label: "Seller Code",
		nullable: {
			val: false,
			msg: "Seller Code is required.",
		},
		min: {
			val: 1,
			msg: "Seller Code must be atleast 1 character long",
		},
		max: {
			val: 10,
			msg: "Seller Code can maximum be 10 character long",
		},
		transform: "UpperCase",
	},
	mobile: {
		name: "mobile",
		label: "Mobile",
		nullable: {
			val: false,
			msg: "Mobile is required.",
		},
	},
	email: {
		name: "email",
		label: "Email",
		nullable: {
			val: false,
			msg: "Email is required.",
		},
		email: {
			val: null,
			msg: "Email must be a valid email address.",
		},
	},
	contactperson: {
		name: "contactPerson",
		label: "Contact Person",
		nullable: {
			val: false,
			msg: "Contact Person is required.",
		},
		min: {
			val: 2,
			msg: "Contact Person must be atleast 2 character long",
		},
		max: {
			val: 40,
			msg: "Contact Person can maximum be 40 character long",
		},
		transform: "TitleCase",
	},
	city: {
		name: "city",
		label: "City",
		nullable: {
			val: false,
			msg: "City is required.",
		},
		min: {
			val: 2,
			msg: "City must be atleast 2 character long",
		},
		max: {
			val: 15,
			msg: "City can maximum be 15 character long",
		},
		transform: "TitleCase",
	},
	state: {
		name: "state",
		label: "State",
		nullable: {
			val: false,
			msg: "State is required.",
		},
		min: {
			val: 2,
			msg: "State must be atleast 2 character long",
		},
		max: {
			val: 15,
			msg: "State can maximum be 15 character long",
		},
		transform: "TitleCase",
	},
	pincode: {
		name: "pincode",
		label: "Pincode",
		nullable: {
			val: false,
			msg: "Pincode is required.",
		},
		numeric: {
			val: null,
			msg: "Pincode must be a valid number.",
		},
		gtEqualTo: {
			val: 100000,
			msg: "Pincode must be greater than or equal to  100000",
		},
		ltEqualTo: {
			val: 999999,
			msg: "Pincode must be less than or equal to  999999",
		},
		transform: "Number",
	},
	address: {
		name: "address",
		label: "Address",
		nullable: {
			val: false,
			msg: "Address is required.",
		},
		min: {
			val: 1,
			msg: "Address must be atleast 1 character long",
		},
		max: {
			val: 120,
			msg: "Address can maximum be 120 character long",
		},
		transform: "TitleCase",
	},
	gstin: {
		name: "gstin",
		label: "GSTIN",
		nullable: {
			val: false,
			msg: "GSTIN is required.",
		},
		min: {
			val: 15,
			msg: "GSTIN must be atleast 15 character long",
		},
		max: {
			val: 15,
			msg: "GSTIN can maximum be 15 character long",
		},
		transform: "UpperCase",
	},
	cinno: {
		name: "cin",
		label: "CIN No",
		nullable: {
			val: false,
			msg: "CIN No is required.",
		},
		min: {
			val: 10,
			msg: "CIN No must be atleast 10 character long",
		},
		max: {
			val: 25,
			msg: "CIN No can maximum be 25 character long",
		},
		transform: "UpperCase",
	},
	fssaino: {
		name: "fssaiNo",
		label: "FSSAI No",
		nullable: {
			val: true,
			msg: "",
		},
		min: {
			val: 14,
			msg: "FSSAI No must be atleast 14 character long",
		},
		max: {
			val: 14,
			msg: "FSSAI No can maximum be 14 character long",
		},
		transform: "UpperCase",
	},
};

const gradesValidationMap = {
	code: {
		name: "code",
		label: "Code",
		nullable: {
			val: false,
			msg: "Code is required.",
		},
		min: {
			val: 1,
			msg: "Code must be atleast 1 character long",
		},
		max: {
			val: 15,
			msg: "Code can maximum be 15 character long",
		},
		transform: "UpperCase",
	},
	orderslno: {
		name: "slno",
		label: "Order SLNo",
		nullable: {
			val: false,
			msg: "Order SLNo is required.",
		},
		numeric: {
			val: null,
			msg: "Order SLNo must be a valid number.",
		},
		gtEqualTo: {
			val: 1,
			msg: "Order SLNo must be greater than or equal to  1",
		},
		ltEqualTo: {
			val: 999,
			msg: "Order SLNo must be less than or equal to  999",
		},
		transform: "Number",
	},
	teacategory: {
		name: "category",
		label: "Tea Category",
		nullable: {
			val: false,
			msg: "Tea Category is required.",
		},
		custom: {
			val: null,
			msg: "Tea Category must be a valid Tea Category",
		},
	},
	subcategory: {
		name: "subCategory",
		label: "Sub Category",
		nullable: {
			val: false,
			msg: "Sub Category is required.",
		},
		custom: {
			val: null,
			msg: "Sub Category must be a valid Sub Category",
		},
	},
	type: {
		name: "type",
		label: "Type",
		nullable: {
			val: false,
			msg: "Type is required.",
		},
		custom: {
			val: null,
			msg: "Type must be one of 'Broken','Fannings','Dust','Wholeleaf','Green Tea'",
		},
	},
	subtype: {
		name: "subType",
		label: "Sub Type",
		nullable: {
			val: false,
			msg: "Sub Type is required.",
		},
		custom: {
			val: null,
			msg: "Type must be one of 'Primary' or 'Secondary'",
		},
	},
};

const locationsValidationMap = {
	name: {
		name: "name",
		label: "Name",
		nullable: {
			val: false,
			msg: "Name is required.",
		},
		min: {
			val: 4,
			msg: "Name must be atleast 4 character long",
		},
		max: {
			val: 80,
			msg: "Name can maximum be 80 character long",
		},
		transform: "UpperCase",
	},
	code: {
		name: "code",
		label: "Code",
		nullable: {
			val: false,
			msg: "Code is required.",
		},
		min: {
			val: 1,
			msg: "Code must be atleast 1 character long",
		},
		max: {
			val: 10,
			msg: "Code can maximum be 10 character long",
		},
		transform: "UpperCase",
	},
};

const marksValidationMap = {
	gardenname: {
		name: "name",
		label: "Garden Name",
		nullable: {
			val: false,
			msg: "Garden Name is required.",
		},
		min: {
			val: 2,
			msg: "Garden Name must be atleast 2 character long",
		},
		max: {
			val: 80,
			msg: "Garden Name can maximum be 80 character long",
		},
		transform: "TitleCase",
	},
	gardencode: {
		name: "code",
		label: "Garden Code",
		nullable: {
			val: false,
			msg: "Garden Code is required.",
		},
		min: {
			val: 1,
			msg: "Garden Code must be atleast 1 character long",
		},
		max: {
			val: 10,
			msg: "Garden Code can maximum be 10 character long",
		},
		transform: "UpperCase",
	},
	type: {
		name: "type",
		label: "Type",
		nullable: {
			val: false,
			msg: "Type is required.",
		},
		custom: {
			val: null,
			msg: "Type must be one of 'Own Leaf' or 'Bought Leaf'",
		},
	},
	location: {
		name: "locationId",
		label: "Location",
		nullable: {
			val: false,
			msg: "Location is required.",
		},
		custom: {
			val: null,
			msg: "Location must be a valid Location",
		},
	},
	tearegion: {
		name: "region",
		label: "Tea Region",
		nullable: {
			val: false,
			msg: "Tea Region is required.",
		},
		min: {
			val: 1,
			msg: "Tea Region must be atleast 1 character long",
		},
		max: {
			val: 20,
			msg: "Tea Region can maximum be 20 character long",
		},
		transform: "TitleCase",
	},
	address: {
		name: "address",
		label: "Address",
		nullable: {
			val: false,
			msg: "Address is required.",
		},
		min: {
			val: 1,
			msg: "Address must be atleast 1 character long",
		},
		max: {
			val: 100,
			msg: "Address can maximum be 100 character long",
		},
		transform: "TitleCase",
	},
	latitude: {
		name: "latitude",
		label: "Latitude",
		nullable: {
			val: true,
			msg: "",
		},
		numeric: {
			val: null,
			msg: "Latitude must be a valid number.",
		},
		transform: "Number",
	},
	longitude: {
		name: "longitude",
		label: "Longitude",
		nullable: {
			val: true,
			msg: "",
		},
		numeric: {
			val: null,
			msg: "Longitude must be a valid number.",
		},
		transform: "Number",
	},
	teacategory: {
		name: "category",
		label: "Tea Category",
		nullable: {
			val: false,
			msg: "Tea Category is required.",
		},
		custom: {
			val: null,
			msg: "Tea Category must be a valid Tea Category",
		},
	},
	annualproduction: {
		name: "annualProduction",
		label: "Annual Production",
		nullable: {
			val: true,
			msg: "",
		},
		numeric: {
			val: null,
			msg: "Annual Production must be a valid number.",
		},
		transform: "Number",
	},
	ctmno: {
		name: "ctmNo",
		label: "CTM No",
		nullable: {
			val: true,
			msg: "",
		},
	},
	haccp: {
		name: "haccp",
		label: "HACCP",
		nullable: {
			val: false,
			msg: "HACCP is required.",
		},
		transform: "Boolean",
	},
	haccpdate: {
		name: "haccpDate",
		label: "HACCP Date",
		nullable: {
			val: true,
			msg: "",
		},
		transform: "Date",
	},
	trustea: {
		name: "trustea",
		label: "Trustea",
		nullable: {
			val: false,
			msg: "Trustea is required.",
		},
		transform: "Boolean",
	},
	trusteavalidupto: {
		name: "trusteaValidUpto",
		label: "Trustea Valid Upto",
		nullable: {
			val: true,
			msg: "",
		},
		transform: "Date",
	},
	rainforest: {
		name: "rainforest",
		label: "Rainforest",
		nullable: {
			val: false,
			msg: "Rainforest is required.",
		},
		transform: "Boolean",
	},
	ravalidupto: {
		name: "raValidUpto",
		label: "RA Valid Upto",
		nullable: {
			val: true,
			msg: "",
		},
		transform: "Date",
	},
	gardeniso: {
		name: "gardenISO",
		label: "Garden ISO",
		nullable: {
			val: true,
			msg: "",
		},
	},
	gardenisovalidupto: {
		name: "gardenISOValidUpto",
		label: "Garden ISO Valid Upto",
		nullable: {
			val: true,
			msg: "",
		},
		transform: "Date",
	},
	fssaino: {
		name: "fssalNo",
		label: "FSSAI No",
		nullable: {
			val: false,
			msg: "FSSAI No is required.",
		},
	},
	fssaivaliddate: {
		name: "fssaiValidDate",
		label: "Fssai Valid Date",
		nullable: {
			val: false,
			msg: "Fssai Valid Date is required.",
		},
		transform: "Date",
	},
	organic: {
		name: "organic",
		label: "Organic",
		nullable: {
			val: false,
			msg: "Organic is required.",
		},
		transform: "Boolean",
	},
	teaboardregistrationno: {
		name: "teaBoardRegNo",
		label: "Tea Board Registration No",
		nullable: {
			val: false,
			msg: "Tea Board Registration No is required.",
		},
	},
	gardenadvance: {
		name: "gardenAdvance",
		label: "Garden Advance",
		nullable: {
			val: false,
			msg: "Garden Advance is required.",
		},
		transform: "Boolean",
	},
};

const groupsValidationMap = {
	groupname: {
		name: "name",
		label: "Group Name",
		nullable: {
			val: false,
			msg: "Group Name is required.",
		},
		min: {
			val: 4,
			msg: "Group Name must be atleast 4 character long",
		},
		max: {
			val: 80,
			msg: "Group Name can maximum be 80 character long",
		},
		transform: "TitleCase",
	},
	groupcode: {
		name: "code",
		label: "Group Code",
		nullable: {
			val: false,
			msg: "Group Code is required.",
		},
		min: {
			val: 1,
			msg: "Group Code must be atleast 1 character long",
		},
		max: {
			val: 10,
			msg: "Group Code can maximum be 10 character long",
		},
		transform: "UpperCase",
	},
	contactperson: {
		name: "contactPerson",
		label: "Contact Person",
		nullable: {
			val: false,
			msg: "Contact Person is required.",
		},
		min: {
			val: 2,
			msg: "Contact Person must be atleast 2 character long",
		},
		max: {
			val: 40,
			msg: "Contact Person can maximum be 40 character long",
		},
		transform: "TitleCase",
	},
	email: {
		name: "email",
		label: "Email",
		nullable: {
			val: false,
			msg: "Email is required.",
		},
		email: {
			val: null,
			msg: "Email must be a valid email address.",
		},
	},
	address: {
		name: "address",
		label: "Address",
		nullable: {
			val: false,
			msg: "Address is required.",
		},
		min: {
			val: 1,
			msg: "Address must be atleast 1 character long",
		},
		max: {
			val: 120,
			msg: "Address can maximum be 120 character long",
		},
		transform: "TitleCase",
	},
};

const auctionCentersValidationMap = {
	auctioncentername: {
		name: "name",
		label: "Auction Center Name",
		nullable: {
			val: false,
			msg: "Auction Center Name is required.",
		},
		min: {
			val: 4,
			msg: "Auction Center Name must be atleast 4 character long",
		},
		max: {
			val: 80,
			msg: "Auction Center Name can maximum be 80 character long",
		},
		transform: "UpperCase",
	},
	auctioncentercode: {
		name: "code",
		label: "Auction Center Code",
		nullable: {
			val: false,
			msg: "Auction Center Code is required.",
		},
		min: {
			val: 1,
			msg: "Auction Center Code must be atleast 1 character long",
		},
		max: {
			val: 10,
			msg: "Auction Center Code can maximum be 10 character long",
		},
		transform: "UpperCase",
	},
};

const groupSellerMappingsValidationMap = {
	groupcode: {
		name: "group",
		label: "Group Code",
		nullable: {
			val: false,
			msg: "Group Code is required.",
		},
		custom: {
			val: null,
			msg: "Group Code must be a valid Group Code",
		},
	},
	sellercode: {
		name: "seller",
		label: "Seller Code",
		nullable: {
			val: false,
			msg: "Seller Code is required.",
		},
		custom: {
			val: null,
			msg: "Seller Code must be a valid Seller Code",
		},
	},
	datefrom: {
		name: "dateFrom",
		label: "Date From",
		nullable: {
			val: false,
			msg: "Date From is required.",
		},
		transform: "Date",
	},
	dateto: {
		name: "dateTo",
		label: "Date To",
		nullable: {
			val: false,
			msg: "Date To is required.",
		},
		transform: "Date",
	},
};

const sellerMarkMappingsValidationMap = {
	sellercode: {
		name: "seller",
		label: "Seller Code",
		nullable: {
			val: false,
			msg: "Seller Code is required.",
		},
		custom: {
			val: null,
			msg: "Seller Code must be a valid Seller Code",
		},
	},
	markcode: {
		name: "mark",
		label: "Mark Code",
		nullable: {
			val: false,
			msg: "Mark Code is required.",
		},
		custom: {
			val: null,
			msg: "Mark Code must be a valid Mark Code",
		},
	},
	datefrom: {
		name: "dateFrom",
		label: "Date From",
		nullable: {
			val: false,
			msg: "Date From is required.",
		},
		transform: "Date",
	},
	dateto: {
		name: "dateTo",
		label: "Date To",
		nullable: {
			val: false,
			msg: "Date To is required.",
		},
		transform: "Date",
	},
};

const markACMappingsValidationMap = {
	location: {
		name: "location",
		label: "Location",
		nullable: {
			val: false,
			msg: "Location is required.",
		},
		custom: {
			val: null,
			msg: "Location must be a valid Location",
		},
	},
	markcode: {
		name: "mark",
		label: "Mark Code",
		nullable: {
			val: false,
			msg: "Mark Code is required.",
		},
		custom: {
			val: null,
			msg: "Mark Code must be a valid Mark Code",
		},
	},
	auctioncenter: {
		name: "auctionCenter",
		label: "Auction Center",
		nullable: {
			val: false,
			msg: "Auction Center is required.",
		},
		custom: {
			val: null,
			msg: "Auction Center must be a valid Auction Center",
		},
	},
	markentitycode: {
		name: "markEntityCode",
		label: "Mark Entity Code",
		nullable: {
			val: false,
			msg: "Mark Entity Code is required.",
		},
		transform: "UpperCase",
	},
	eauctionname: {
		name: "eAuctionName",
		label: "E-Auction Name",
		nullable: {
			val: false,
			msg: "E-Auction Name is required.",
		},
		transform: "UpperCase",
	},
};

const doValidation = async function(ctx, docs, validationMap, currentUser, companyId, excludeList) {
	const now = new Date();
	const validatedDocs = [];
	const outcome = [];
	const referencePos = [];
	for (let loop = 0, length = docs.length; loop < length; loop++) {
		const doc = {};
		doc._id = new ctx.ObjectID();
		doc.companyId = companyId;
		doc.isActive = true;
		doc.createdBy = currentUser;
		doc.updatedBy = currentUser;
		doc.createdAt = now;
		doc.updatedAt = now;
		const keys = Object.keys(validationMap);
		let isValidated = true;
		for (let keyLoop = 0, keyLength = keys.length; keyLoop < keyLength; keyLoop++) {
			let param = docs[loop][keys[keyLoop]];
			if ((!param) && (validationMap[keys[keyLoop]].label)) {
				const __ref = validationMap[keys[keyLoop]].label;
				param = docs[loop][__ref];
			}
			if (typeof param === "string" || param instanceof String) {
				if ((!param || (param.trim && (param.trim().length == 0))) && (!validationMap[keys[keyLoop]].nullable.val)) {
					outcome.push(validationMap[keys[keyLoop]].nullable.msg);
					isValidated = false;
					break;
				}
				if (param && param.length == 0) {
					param = null;
				} else if (param && (typeof param === "string" || param instanceof String)) {
					param = param.toString().trim();
				}
				if (validationMap[keys[keyLoop]].min && param && (param.length < validationMap[keys[keyLoop]].min.val)) {
					outcome.push(validationMap[keys[keyLoop]].min.msg);
					isValidated = false;
					break;
				}
				if (validationMap[keys[keyLoop]].max && param && (param.length > validationMap[keys[keyLoop]].max.val)) {
					outcome.push(validationMap[keys[keyLoop]].max.msg);
					isValidated = false;
					break;
				}
				if (validationMap[keys[keyLoop]].email && param && (!emailRegex.test(param))) {
					outcome.push(validationMap[keys[keyLoop]].email.msg);
					isValidated = false;
					break;
				}
			}
			if (validationMap[keys[keyLoop]].numeric && param && (isNaN(param))) {
				outcome.push(validationMap[keys[keyLoop]].numeric.msg);
				isValidated = false;
				break;
			}

			if (validationMap[keys[keyLoop]].gtEqualTo && param) {
				try {
					const _vl = Number(param);
					if (_vl < validationMap[keys[keyLoop]].gtEqualTo.val) {
						throw {};
					}
				} catch (err) {
					outcome.push(validationMap[keys[keyLoop]].gtEqualTo.msg);
					isValidated = false;
					break;
				}
			}

			if (validationMap[keys[keyLoop]].ltEqualTo && param) {
				try {
					const _vl = Number(param);
					if (_vl > validationMap[keys[keyLoop]].ltEqualTo.val) {
						throw {};
					}
				} catch (err) {
					outcome.push(validationMap[keys[keyLoop]].ltEqualTo.msg);
					isValidated = false;
					break;
				}
			}

			if (validationMap[keys[keyLoop]].custom && validationMap[keys[keyLoop]].custom.val && param) {
				const customValidationResult = await validationMap[keys[keyLoop]].custom.val(param, doc);
				if (!customValidationResult) {
					outcome.push(validationMap[keys[keyLoop]].custom.msg);
					isValidated = false;
					break;
				}
			}

			if (validationMap[keys[keyLoop]].transform && param) {
				switch (validationMap[keys[keyLoop]].transform) {
				case "TitleCase":
					if (typeof param === "string" || param instanceof String) {
						param = param.toTitleCase();
					}
					break;
				case "UpperCase":
					if (typeof param === "string" || param instanceof String) {
						param = param.toUpperCase();
					}
					break;
				case "LowerCase":
					if (typeof param === "string" || param instanceof String) {
						param = param.toLowerCase();
					}
					break;
				case "Number":
					param = Number(param);
					break;
				case "Date":
					if (typeof param === "number") {
						try {
							param = excelDateToJSDate(param);
							if (!isValidDate(param)) {
								outcome.push("Must be a valid date");
								isValidated = false;
								break;
							}
						} catch (err) {
							outcome.push("Must be a valid date");
							isValidated = false;
							break;
						}
					} else {
						try {
							const m = moment(param, "DD/MM/YYYY");
							if (!m.isValid()) {
								throw {};
							}
							param = m.toDate();
						} catch (err) {
							outcome.push("Must be a valid date with the format 'DD/MM/YYYY'");
							isValidated = false;
							break;
						}
					}
					break;
				case "Boolean":
					if (typeof param !== "boolean") {
						param = param.toString().toLowerCase();
						if (param == "true") {
							param = true;
						} else {
							param = false;
						}
					}
					break;
				}
				if (!isValidated) {
					break;
				}
			}
			if (excludeList.indexOf(keys[keyLoop]) < 0) {
				doc[validationMap[keys[keyLoop]].name] = param;
			}
		}
		if (isValidated) {
			referencePos.push(loop);
			validatedDocs.push(doc);
			outcome.push("");
		}
	}
	return {ref: referencePos, docs: validatedDocs, outcome: outcome};
};

module.exports = (ctx) => {
	return {
		validateUsers: async (docs, currentUser, companyId) => {
			const userModel = require("../models/user")(ctx);
			const userResult = await userModel.getAllCompanyUsers(companyId, {loginId: 1});
			if (!userResult.status) {
				return {ref: [], docs: [], outcome: []};
			}
			// const companyModel = require("../models/company")(ctx);
			// const companyResult = await companyModel.details({_id: companyId}, {_id: 0, userRoles: 1});
			// if (!companyResult.status) {
			//	return {ref: [], docs: [], outcome: []};
			// }
			const existingUsers = userResult.docs;
			// const loginIds = _.map(existingUsers, "loginId");
			const userTypes = ["Admin", "Taster", "Support"];
			const validationMap = JSON.parse(JSON.stringify(userValidationMap));
			// const appService = require("./appService");
			const bcrypt = require("bcrypt");
			const saltRounds = 10;
			validationMap.password.custom.val = async function(input, validatedObj) {
				try {
					input = await bcrypt.hash(input, saltRounds);
					validatedObj.password = input;
					return true;
				} catch (err) {
					return false;
				}
			};
			validationMap.usertype.custom.val = async function(input, validatedObj) {
				try {
					if (userTypes.indexOf(input)<0) {
						return false;
					}
					validatedObj.privileges = global.userRoleMap[input];
					validatedObj.userType = input;
					if (!validatedObj.privileges) {
						validatedObj.privileges = {};
					}
					validatedObj.parentUserId = existingUsers[0]._id;
					return true;
				} catch (err) {
					return false;
				}
			};
			/* validationMap.reportsto.custom.val = async function(input, validatedObj) {
				try {
					const loginIdIndex = loginIds.indexOf(input.trim());
					if (loginIdIndex >= 0) {
						validatedObj.parentUserId = existingUsers[loginIdIndex]._id;
						return true;
					}
					return false;
				} catch (err) {
					return false;
				}
			}; */
			const result = await doValidation(ctx, docs, validationMap, currentUser, companyId, ["password", "usertype", "reportsto"]);

			return result;
		},
		validateCategories: async (docs, currentUser, companyId) => {
			const validationMap = JSON.parse(JSON.stringify(categoriesValidationMap));
			const result = await doValidation(ctx, docs, validationMap, currentUser, companyId, []);
			return result;
		},
		validateSellers: async (docs, currentUser, companyId) => {
			const validationMap = JSON.parse(JSON.stringify(sellersValidationMap));
			const result = await doValidation(ctx, docs, validationMap, currentUser, companyId, []);
			return result;
		},
		validateGrades: async (docs, currentUser, companyId) => {
			const validationMap = JSON.parse(JSON.stringify(gradesValidationMap));
			const model = require("../models/category")(ctx);
			const result = await model.list({companyId: ctx.ObjectID(global.hostCompanyId)});
			if (!result.status) {
				return {ref: [], docs: [], outcome: []};
			}
			const categories = result.docs;
			const categoryCodes = _.map(categories, "code");
			validationMap.type.custom.val = async function(input, validatedObj) {
				const tmp = input.toUpperCase();
				const nameArr = ["BROKEN", "FANNINGS", "DUST", "WHOLELEAF", "GREEN TEA"];
				const valArr = ["B", "F", "D", "W", "G"];
				const index = nameArr.indexOf(tmp);
				if (index < 0) {
					return false;
				}
				validatedObj["type"] = valArr[index];
				return true;
			};
			validationMap.subtype.custom.val = async function(input, validatedObj) {
				const tmp = input.toUpperCase();
				const nameArr = ["PRIMARY", "SECONDARY"];
				const valArr = ["P", "S"];
				const index = nameArr.indexOf(tmp);
				if (index < 0) {
					return false;
				}
				validatedObj["subType"] = valArr[index];
				return true;
			};
			validationMap.teacategory.custom.val = async function(input, validatedObj) {
				const tmp = input.toUpperCase();
				const index = categoryCodes.indexOf(tmp);
				if (index < 0) {
					return false;
				}
				validatedObj["category"] = categories[index]._id;
				return true;
			};
			validationMap.subcategory.custom.val = async function(input, validatedObj) {
				const tmp = input.toUpperCase();
				const index = categoryCodes.indexOf(tmp);
				if (index < 0) {
					return false;
				}
				validatedObj["subCategory"] = categories[index]._id;
				return true;
			};
			const fResult = await doValidation(ctx, docs, validationMap, currentUser, companyId, ["type", "subtype", "teacategory", "subcategory"]);
			return fResult;
		},
		validateLocations: async (docs, currentUser, companyId) => {
			const validationMap = JSON.parse(JSON.stringify(locationsValidationMap));
			const result = await doValidation(ctx, docs, validationMap, currentUser, companyId, []);
			return result;
		},
		validateMarks: async (docs, currentUser, companyId) => {
			const validationMap = JSON.parse(JSON.stringify(marksValidationMap));
			const model = require("../models/location")(ctx);
			const result = await model.listWithCategory();
			if (!result.status) {
				return {ref: [], docs: [], outcome: []};
			}
			const locations = result.doc.locations;
			const categories = result.doc.categories;
			const locationCodes = _.map(locations, "code");
			const categoryCodes = _.map(categories, "code");
			validationMap.type.custom.val = async function(input, validatedObj) {
				const tmp = input.toUpperCase();
				const nameArr = ["OWN LEAF", "BOUGHT LEAF"];
				const valArr = ["O", "B"];
				const index = nameArr.indexOf(tmp);
				if (index < 0) {
					return false;
				}
				validatedObj["type"] = valArr[index];
				return true;
			};
			validationMap.location.custom.val = async function(input, validatedObj) {
				const tmp = input.toUpperCase();
				const index = locationCodes.indexOf(tmp);
				if (index < 0) {
					return false;
				}
				validatedObj["locationId"] = locations[index]._id;
				return true;
			};
			validationMap.teacategory.custom.val = async function(input, validatedObj) {
				const tmp = input.toUpperCase();
				const index = categoryCodes.indexOf(tmp);
				if (index < 0) {
					return false;
				}
				validatedObj["category"] = categories[index]._id;
				return true;
			};
			const fResult = await doValidation(ctx, docs, validationMap, currentUser, companyId, ["type", "location", "teacategory"]);
			return fResult;
		},
		validateGroups: async (docs, currentUser, companyId) => {
			const validationMap = JSON.parse(JSON.stringify(groupsValidationMap));
			const result = await doValidation(ctx, docs, validationMap, currentUser, companyId, []);
			return result;
		},
		validateAuctionCenters: async (docs, currentUser, companyId) => {
			const validationMap = JSON.parse(JSON.stringify(auctionCentersValidationMap));
			const result = await doValidation(ctx, docs, validationMap, currentUser, companyId, []);
			return result;
		},
		validateGroupSellerMappings: async (docs, currentUser, companyId) => {
			const validationMap = JSON.parse(JSON.stringify(groupSellerMappingsValidationMap));
			const model = require("../models/group")(ctx);
			const result = await model.listWithSellers();
			if (!result.status) {
				return {ref: [], docs: [], outcome: []};
			}
			const groups = result.doc.groups;
			const sellers = result.doc.sellers;
			const groupCodes = _.map(groups, "code");
			const sellerCodes = _.map(sellers, "code");
			validationMap.groupcode.custom.val = async function(input, validatedObj) {
				const tmp = input.toUpperCase();
				const index = groupCodes.indexOf(tmp);
				if (index < 0) {
					return false;
				}
				validatedObj["group"] = groups[index]._id;
				return true;
			};
			validationMap.sellercode.custom.val = async function(input, validatedObj) {
				const tmp = input.toUpperCase();
				const index = sellerCodes.indexOf(tmp);
				if (index < 0) {
					return false;
				}
				validatedObj["seller"] = sellers[index]._id;
				return true;
			};
			const fResult = await doValidation(ctx, docs, validationMap, currentUser, companyId, ["groupcode", "sellercode"]);
			return fResult;
		},
		validateSellerMarkMappings: async (docs, currentUser, companyId) => {
			const validationMap = JSON.parse(JSON.stringify(sellerMarkMappingsValidationMap));
			const model = require("../models/seller")(ctx);
			const result = await model.listWithMarks();
			if (!result.status) {
				return {ref: [], docs: [], outcome: []};
			}
			const marks = result.doc.marks;
			const sellers = result.doc.sellers;
			const markCodes = _.map(marks, "code");
			const sellerCodes = _.map(sellers, "code");
			validationMap.sellercode.custom.val = async function(input, validatedObj) {
				const tmp = input.toUpperCase();
				const index = sellerCodes.indexOf(tmp);
				if (index < 0) {
					return false;
				}
				validatedObj["seller"] = sellers[index]._id;
				return true;
			};
			validationMap.markcode.custom.val = async function(input, validatedObj) {
				const tmp = input.toUpperCase();
				const index = markCodes.indexOf(tmp);
				if (index < 0) {
					return false;
				}
				validatedObj["mark"] = marks[index]._id;
				return true;
			};
			const fResult = await doValidation(ctx, docs, validationMap, currentUser, companyId, ["sellercode", "markcode"]);
			return fResult;
		},
		validateMarkACMappings: async (docs, currentUser, companyId) => {
			const validationMap = JSON.parse(JSON.stringify(markACMappingsValidationMap));
			const model = require("../models/mark")(ctx);
			const result = await model.listWithAuctionCenterAndLocations();
			if (!result.status) {
				return {ref: [], docs: [], outcome: []};
			}
			const marks = result.doc.marks;
			const locations = result.doc.locations;
			const centers = result.doc.centers;
			const markCodes = _.map(marks, "code");
			const locationCodes = _.map(locations, "code");
			const centerCodes = _.map(centers, "code");
			validationMap.location.custom.val = async function(input, validatedObj) {
				const tmp = input.toUpperCase();
				const index = locationCodes.indexOf(tmp);
				if (index < 0) {
					return false;
				}
				validatedObj["location"] = locations[index]._id;
				return true;
			};
			validationMap.markcode.custom.val = async function(input, validatedObj) {
				const tmp = input.toUpperCase();
				const index = markCodes.indexOf(tmp);
				if (index < 0) {
					return false;
				}
				validatedObj["mark"] = marks[index]._id;
				return true;
			};
			validationMap.auctioncenter.custom.val = async function(input, validatedObj) {
				const tmp = input.toUpperCase();
				const index = centerCodes.indexOf(tmp);
				if (index < 0) {
					return false;
				}
				validatedObj["auctionCenter"] = centers[index]._id;
				return true;
			};
			const fResult = await doValidation(ctx, docs, validationMap, currentUser, companyId, ["location", "markcode", "auctioncenter"]);
			return fResult;
		},
	};
};
