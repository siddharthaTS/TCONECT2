
const defaultErrorMsg = "Encountered an unexpected error, unable to validate transactions";
const logoImage = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAFQAAACBCAYAAABemJ1dAAAABHNCSVQICAgIfAhkiAAAIABJREFUeJztfXtUVFX7/ydgZhy5jYLDVQTEFzCVS4lQKALeUBEvlWCFaCZoJVipdPGCvl4zgyzFXhXSEtJMNBMUb6Am8hqKmoApICrgCDI4DOOcweb3x5mz5xxmBgbU3rV+6/tZi7V0n8vs/Zy9n/3c9wuqNpUa/zAoisKpopM4eOIgzl86D+kjaZffIRQI8ar/K3gt4nW88tKrsDS3fA497Tpe+CcJWlNbg+zD2diXtw8NDx9wromsROjr0BfO9s5wEDvCytwSPQQ98Fj5GI/kMtRJanG3/i7u1N3R+QC2vWwxaVQUZk6ZCRdHl39qOHrxjxC0tKwUB4/nIPtwNhRKBQCagJ5uXvB/0R8jA0fCu7+3UbNMJpehsqYSpy+cwvlLRaioKicEFgqEmDxmCqaPnw4fb5/nOiZDeK4EpSgKqZmp2LpnC2nzcvfEzKlxmBA6UYeAFEWBz+dz2uStcvxe8jv+/vuJ3qUtk8uQW5CLjJ93oLyygrRHhk3ExuRNOu973nhuBC0tK0XyF4vJIF2d3LBwdhIiQsaDZ8Yj9xVfKcaBY7+govIG7tTfgU1vG+xavwtiGzEoisLYWWMBAD0EfDS3yJCxLgOe7p46v6dqUyG34Ai+ytiE6ru3AQAe/TywMfnLf3S2mjyPl+468D1ikqIJMZPiknA04ygmhUdxiAkAOfk5uN8oQVJcIrav3g55Swuyft0DAMj+LQt2tnY4mnEUuTuPwtfbB+v/s548u/fIXsxfPg8rN6egsqYSk8KjcHRnPpLikiAUCHHz9k3EJEVjW1b68ximXjxTglIUhSUbFmF52nIolArY9rJF+sp0JMYlgc/nY1tWOipYyxIA7GzEEFlaY0RACLz7e6OXdS9y7cjpXMyYFEOWbXL8JxgZEAIAyD+bjxVpyyGy6gWpTIrXP3gNhcUF4PP5SIxLQlZqNmx794FCqcC6bevw4ZqFoCjqWQ5XP1RtKvWz+HvY/FA97b1paudgJ7VzsJN62nvT1DW1NeT6xasX1c7BTuqhU4eqb1TfIO3f/fSdeujUoep3P5ujHjp1qHrae9PUD5sfqlVtKnV4XLj64tWLen9vVGyY+pvdm8n/N27/Qh0c/Qrnnnv37+n0qaGp4ZmM19DfM5mhzbJmvPnhDFwoLQIAxETOwK4vdsFB7MC5z9XJDYG+wzB7yWzUSeoAADai3pA2N2HksFAEDBmKW3duobKmEgDg2McR9Q/qyPM5x3OQfTgLNbU1+KvmJkYOCyXXgvxfwf0HEjTLmgEAZTfLUH2vGru/3I1Z02YBAC6UFmH6wumQNEqexbD14pkQ9JONybhacRUAkByfjDUfrcGtmluYv3weNny3AQDA5/EhlTVh3cfrYWdrh9hFb0PSKEE/R1dQTygE+gYi9fM0+HoOwZzP5qCxqQGTR0UhNfMrlJaVovhKMVZvWQ1KRaGpuQl8Uz6HPVTfrYZAIIBQIAQALFy3EOlZ6eCZ8bDsg+VIjk8GAFTcLMfMRW9DJpc9i6Hr4KkISlEUXnt/KnILciGyEiFn60HMmjYbC1a+j4XrFmLksFDkHM/B0cI89OjRA0qlEtm/ZeF+Yx2ksmaMnTUGSpUSQoEQ1XerAAD/WbsDk8InoaGpEZPCozDrtXeQtisNm3ZswtL3PkfslJnw7u8Nc3MLlJaVAgAkjRKkZqYiImQ8+Hw+Pv3yU9TcuY0nT9pIX8cMH4ucrQchshKhvLICMxfNfC489anEpvnL5yG3IBcW5hbYsXYnAoYEIC0zFZm/ZOL0jwWwtrTGqm9XQdy7DyaFR+GVN4Lw0iB/LIhNhN+L/kj8dyJGBoRAZCVCSMBICAVC1DfUo76hHk3Sh1BQjyHk90AvUW/Y29rD3taebFD5Z/Ox/Ovl8OrvhfJb5QCA/d/sh6RRgpikaMRNm4XyqnLsXLsTRwvzkLwxGRd+LkbZrTLELZkJ6SMpRgWF4z9rdzwbSmrQbYJu+G4DEdhTElMQO2UmAFq9HDdrLBLjaKLFfz4XR7bnwtTUFCNnhOC3HUfg5uxG3iNplODsxbM4/ns+LpeVQvLwPp60PdH5PVMzU4h728HX2wejXhmN8FfCUX23GqcvnEIPQQ9MGTMVYhsxps6fCvs+doieEI3MA98jPSUd4bFheG3ca0iMSwIAnLl4BvGfzYVCqcC8GfOxeO7i7pBAL8y689DRwjxCzCljphBiAoCLowviY+KRlpkGc3MLpCSmwEHsAJlcBoFAQJaZpFGCrF/34IdDP3L0epGVCPa2drC27IWePXuitbUVzbIm1DfcR52kFnWSWsJiYibOQNy0OIhtxACAQycO4q/bN/Dtim/xV/UNAEBqZirMTHmYN2M++Y3hLw9H9MRoZOzPwNY9W+DV3xOTwqO6QwoddHmG1tTWICphEqSPpPAb6I/s1Gwd9Y6iKEQlRMLBzgk71+7kPGtva4+te7Yg85dMooP7DfTH2OFjEOgbBI9+HjDvaa7zu/JWOW7evomiy+dx9MwxXLpeAoD+AHFT4zBvxnzck9zDzeqbGB08GoXFBVj+9TI0NDVi45KNGDtinE4fo5Oicel6CSzNLXFw2yHOyuk2uipnRSVEqp2DndSDxr+ovlVzy+B950rOqZ2DndSHT/7KaRv5ZghHLjxXcq5b8t61G9fUby96m7xrVGwY510nfj+udg52Ur+96G2D76iprVH7RvqonYOd1JFzI9XyVvlTy6FdIujG7V+QAbAJZehv0fpF6o/XfaRWtanU3+zerB4Q7kEGf+L342pVm0q9L29fhx+ms78Tvx9Xj4oNUzsHO6kHhHsQYf/i1YudfnRVm0qdV5hHxrRx+xdPTVCjl3zxlWLELZrZZUbeLGvGJxuTkVuQC9vefTDn9Xcwa9psooqu27YO6xdvwBvj3+A8V1FZgbLKMtx/UA8AEPYQwqGPI3y8fQjPZEBRFDL278T2vdvR0NSAiJAIJMd/gl7WvYwyCaZlpiI1MxVCgRDpq9IxQqPedgvGUj5ybiRZpsY+I2+VE9Uvcm4kRxXdf/RnMjOY2cqwBYat6PsbEO6hnvbeNPX+oz/rXcJMP0fFhnVpCc/4MIaoxozq250/owT7wuICXLpeAqFAiJTEFKM+FEVRiF0UiwulRQgNCkN2ajZRRUvLSpG8IVnnmW1Z6Zi+4A38ca3E4HsVSgUulBYhcVUiZn8yGzW1NeSag9gB2anZCA0KQ3llBWIXxRotvK9YkAKhQIg6SS22/rjVqGf0oVOCqtpUWJu+BgAQN22WXlukPnyw6gNcKC2Cq3M/pKekE0mgprYGcz6bQyz3AFB2q4ws/67g1PmTmPjuBBw6cZC08fl8pKekIzQoDBdKi5C0OlHvs4yWxcDN2Q3xMfEAaJtBd7Uo02XLlq3o6IZ9R/bip99+goPYEekr02FqakqubctKxx/XLuLlwS9znlm5OQX7836Gg9gRP365B71FvQHQszZuyUyiZjI4+8dZnP3jbLcGQKko5BXmwdrSGn4D/ehBmZoiyC8Iv53+DZeuX4JMLkMIiy/erP4Lk+ZFQsATcPruP9Afh08ext36O+jT2xY+3r5d7k+HM5SiKHy9azMAICEmniNvFl8pxrpt6/D9gV2cZ3KO5yBjfwaEAiG2pmzlOM2SVicSI8qzxsrNKdh7ZC/5v9hGjK0pWyEUCLFz3w7kHM8h11wc+6GXVW+kZaZx7LN8Ph8LZ9Pa1Obd33RrlnZI0OzfslAnqYVQIMS4ERGknaIoLE9dCoAmNIOqu1VY+tXnAIB1i9dxXA9pmanILcjtcge7ghVpyzlL2cfbB+sW02xk6Vefo0qzMvh8Pt6a9CYUSgWWpy3nvGNSeBQ8PbzQ8PABMvbvRFdhkKAURSE9axsAYPKYKRxRJWP/TpRXVuClQf4ctfOjNR+hRd6CWdNmcVS5wuICpGamGtUhHo8Hv4H+mDJmCkYEjCDmOGOgUCqQ/MViqNpUpG1SeBRmTZuFFnkLPlrzEWmfN2M+XJ3ccKG0iMODAWB+zDwAwPZ9O7o8Sw3KoYxsJrIS4Wz2OaIOVlRWIDJ+IsyF5jiacYwQ+sM1C3Hg2AFEhERgS4p2l2yWNSPotUDOJmQIESERWL94A0d2VLWpsD/vZ6z/br3RARExkTOw5qM1nLb4pfE4duYo3hj/OtYv/oKMZcq8yTA1M8WxjHwihVAUhVejX0XDwwddNp7onaEUReGHQz8CAOKmxnF06/X/WQ+VSoWEmARCTNpzeQAiKxFWLOCKVUu/+swoYnq5eyL1szQdQZxnxkP0xBhkp/4EV+d+Rg0q59gB4hFgsCppFURWIuw9sg/FV4oBAJ7unoieGI0WeQs2795M7mVYAgBkHd7TpVmql6A5x3PQ8PABhAIhYiJnkPbiK8U4df4kHMSOmDVtNmnPPpwFAFgydwmHNRwtzMOvJw8b1ZF5b87v0Ifu6e6JPZuy4erUuQFDoVRg75GfOG1iGzE+eode8su+XkbaE2bMg4W5BXKOHeDItDGRMyAUCCF9JOVsaJ1BL0GzD2cDAMaFjOMQKF3jjl0Q+wEZ/M3qv5BXkAe/gf6InhhD7pXJZUj5ZqVRnRAKhAgJGNnpfQ5iB+xcvxMiK1Gn956/VKTT9lbU2/Ab6I+Km+VkloptxHg7KhYKpYITkCG2ESNqNL0P7PzF+M1Jh6ClZaXENDZzShyn/dT5k3C2d8bUMdNI+6aMTfRmkMDVfLb+uBV1klqjOmHe0xzWltZG3evm7Ia0z9M6ve/6zT/1LlWmn5n7M0hbfEw8RFYiHMw/yGEV0RPoCVJxs1xHETAEHYIe1ExvL3dPjtiT/Ru9rN+KeovMzorKCuQW5GJEwAgEDAkg9zbLmvHDwd1GdQAA8MIL5J/FV4oxbs44zF8+T4cPMhgREMJhRfogk8tw4coFnfaAIQEIDQpDbkEukUGtLa0xdew0KJQK7M7R9tvH2wd+A/0BAD+1YyGGwCEoRVH49RTN89p3uOjyeYisRJxlvS2bZgERLBkVoL9+V7yKcnkLKIoCRVFI+ncSKm6WI7cgF++teM/gM0vmLunUklRy7Q+97YmxiZz+A8DMKTMhFAixL3cvZ2ZP1iz73IIjRm1OHILmnclFw8MHsDS3RNSoyaQ9/2w+qu/eRtzUOLI0S8tKcfjUYbg6uXFYgKpNhZ9YGosxUCgVKLtVhrJbZRw2cel6CfGzt4e1pTWCXw7u8L36+ChAz7yXBvnj8KnDZCm7OLpg8pgpaGhqIKsRAKaMmQqRlQjSR1IcKTzS6Vg4BP31+CEAwMhhIRyelvVbFoQCId4YP520fX8gEyqVCrFTYzm7M8+Mh+nj30BoUBhCg8KMFnWOnjmqt71V0WrwmXHt3BrtcavmpsFZNSE0EiqVCt8fyCRtb0e9DYAOAWJgaW6J0EA6oOLQiUMd/h7AIqhMLkORhudMGDmR3FAnqUNRyXmMDBxJBN9mWTPyz+XD0twSU8dM1XlpYlwSdq7dSf+ty9S5rg9b92xB3JKZOu02IhuDzzCuZ0NobmmGVKZfGZg6ZioszC2Qfy6frAJvD29aCqgq5y57zWotKjlvcMUwIAStrKlEi7wFFuYWeOWlV8kN+eeOQaFUcGbDweM5aJG3YELohE535x78Hh1eZ6O9JjTMJ7BD2dTa0hpe/b0NXlepVAY3NmtLa0wMnYgWeQvZiAGaZ0ofSXGq6CRp83vRHyIrERRKBQqKT3c4BkLQiip6xxs6JIDD7HPyaT3X081Lp22KntnZHfB4PJ02Vyc3bFiyodNnA30DO7z+SP7I4DWm/8x4AGDciAgIBUIcZOn3luaWCPAZBgA4feF0h79HCFp0+TwAkHBBgDYGX/vrKlyd3IhhuepuFS5dL4Grcz8dUanqblW3TF4bkzdi18bd8BvoD49+Hpg3Yz5y0nOMipf36t+xwbu1VW7wWsCQALg698Ol6yXEEiW2EWOIlw/OXjzLGUt4UDgAoOjyBY7xpT1MAHpnLrpM88/hQ0eQi7+XnINKpULYK2Gk7Zhm85g8agoAWtT69MtPEfRaIMLeCsWr0a8SVdRY9HN0xfCXh+OXLb8g//vjWDx3sdGCfj9H1w6vK6jHHV5nxnGMtSmOHxlB7ymaSQbQK4HH42mCLfSzEUBD0MqaStRJauHq3I/j7D92Lh8AMHb4WNJ24ATNb8aNiABFUUhYnoCsX/cQA0jDwwf4ZOMnHGNvZ+ghMJ7PtofYRqyXZTDobMUwdt7fTv9G2ny8aEt9bqF2t3dxdEH/vu4AoONxYMMEAE5fOAUACB2mnYnNsmYUlZyHg9iRLO2KygpU3CyH30B/eLp7YsXmFTh1/qSe19LG3ucZh8nAwtwCZiaGI4p6CAQdPu/p7onBnoNxteIq0ZzcXdxhYW6BvMI8zgcJDaSX/aXrlwy+zwQALmgMBb4DtT6UokvnoVAqEOg7jLQxhA8JGAFJowQ5xw6Qa/NmzEfezqOYMoZeQgqlAr9f+r3DwTwLCHgCmJkZJqhQ0LPTdzD8kemvpbklXvQYBOkjKcpulZH7fLyGAABKK64YfJcJABIO6OvtRy4UX/0vACDQN4i0MYQP8n8Fpy+cJst89uvvYPHcxfB090Q/R60gf/tudaeDAfBUqS9KlRJqGI7VsLbqnBcH+b8CgI7KI21+tPTA5qNDvHzA4/FQfqvc4MZkUiepQ52kFra9+3B21Ut/0tOaEUsoisKlP0sgshLB18uXWKQA2mAC0AFdPxz8gbQbyxtNTUw7v8kA/v77b73hjwysLTonqK+XL0RWIlz6s4QscYbIpeVaK5OD2AF2NnYdbkwmTNhfX/u+pFEml+Gv2zfgIHYkRK66WwXpIyk83bzA5/NJuKCXuyfZyO7W30VDUwN5j9+L/p0O5mnxsPmhQY+AUCDkhI0bAp/Ph6ebF6SPpER88u7vDaFAiMvtzHYDB7wIADrZLAxMGB4hstYabRmtyau/VphnEhKYpdAobaR/2GMguaeXdS+iCnq5e3Lk1I5gYtL9yPQ7LCt7ewgEAogsOzdGA4C/5uMz47Q0t4RL3346s3GgRjO7fvNPve8xYTQke1t70lhafhkA4OM5hLQxhGeCCaCJ4rG31WZ6iG3EiI+Jx0uD/JH6+ddGDQR4uiXP3jTaw83Z3Wj+zGy+f/51jbT5acQnZjUCgJc7PckYurWHSdnN65obtRrH5TKaoP6DXiJtVXeqIRQI8aJmyvcQ6O9oYlwSfv7mF6NDdng8Hicapas4VXTa4DXfLqQkemmWeMmfWpGIMS4zSg8A/EszrrKb5XrfY3Lvfi15IYOym9fB4/Hg6aYlSrOsCXZ9xLDpZQsAcLBzAgA8NsKj2RE6kiE7g6RRgivlhl0TQ7pAULGNGHZ9xLhXf49YlJjxl1dpieckdoLISoT7DfV6jegmTCOz5CmKQn3DfVhbioiDjmnz6OtBHmTYQUc8zFgI+B0L34aQV5jboYva292wJUof3Pr2h0KpQLVG3HN1doVQIERVjVYz4vP5EFn2gkKpQFNzk847TABa22AIWt9QD+kjKfo5anf9Rmkj5Ao5BrBmLMMOqmtvd6nTzxKniwsMXnMQOxrNdhh4aSxqt2urAdAmPpteNmiQPkALy8jCSA71DfU67zABAFtRH8K8mZtcWAL6nfo7UKlUcHV2JW3DhgyDbS9b3Ku/99yy0jqCpFGCopLzBq93hX8ycNFMoqo72hnpZOeMFnkLHmqkGoDOCgSAWj1eXRMAHFmNya1kazzMg/a2dtqX8vkYHTyG+IP+aaRmpna43Dtzj+iDo9gRAHCfZYPo50QTmT0bLTWRNEy4OhsmAGDfR0soRuayYxGPUSH7aoT8Zlkzsg9nIV9jjbr0p+GI485gambaZTm0tKwUP+ftM3jdy90TESHju9wXZnyNrNnoKKY3X/ZstLS0AgBI2tVNATSJX2wZ9H7Dfc2LHLVtjRIIBUL0tu6NisoKJCxNQPU97bJ4mhn6Al6AgGf8piRplNARdir9urRQIERK0iqdQgfGoLd1bwgFQjQ/0vqNmInFno2M7P2g8b7OO8wAcIy59zRfwpqlYdQ31MPc3AIWPc2R9n0qIaarkxuksiacOH8CzbJmo43CbHRFBn3ypA0LVi7g1BZpj+SEZL0aWp2kDrtzdkMqkyLAJwATRk7QIXpPYU+Y9zQHpdKa7JiJxZ6N1swMbWxAe5gBXB7KfB12m7RZCguhBUxNzVB1h85ldxA74tB3h9DQ1IBJ8ZHILTjCCYJ4Hli9ZTVRDfWhfZokg5raGkQnRROff9ave3DszFGkfpam4wK3MDeH4rF2R2cmViPLRsFEI7IJz8AEAHqwXLHNsiYIBULObFM8lhMCu2ms1uOGj4WluSXcnN0wPiQC3/+SaXCgzwLbstKRwYpHao9hPoFY9/F6vddWbF6hE2eVW5CrNwi4l5UNHrPcJozF7BFLkrGyoGeoTI8D0AQArDU3AMBjJaWzUTS3yIiosPS9ZUiKS8LC2R+S6y8NGoryygoUdiAXPg06yxAZ5hOIXV/s0qu3y+Qyg+LV7oO7dPzsfB4fSkrLnxnitbZqAy4Yo/Vjpa6/ygQATDTGCVWbCkqVEmamZmSjULWpoGpTEVHBQeyAxLgkjqt5rGa2pmZ2HhXXHmZmPLxg8oLeaxRFYfYnszskZmTYRIPEBOgZZtdHG5Lp6tyP6Ogt8hYUlxZz7rfsaU7GDNB8lcfjoZXFBgSa33pMKXV+z4R9g/pvNRSPWzmDVP+tRlubCkKh4QgNa0trTAidgEvXS5B/Nt/gfV1B2c0yRCVEGvRZAbTb5etl33RoUeKZ8ZC+8juEBoVh1rRZOLozH8s/0CYqVN65xb2fz0dbmwrqv7VeADMTM6hY/LJHD5oWbXqs9notEzwzns4OaNaJGDJlzFRkH87GtuytGB08usN79f0eG0cL8/Dx+o/RIm/Re7+FuQUWzVmkdwPSB093T06auVKlnVnCHtyJYsjL8LgTdzQDo0w9T54YdjEwCBgSAE8PL/xxrQRnLp7B8JeHG9WB9sRc9e0q7Nynv2yFyEqEhJgEknzbXfxHk90iFAgx+tUxOtfZ4+2q0mEUQY2VFcMCwlBxsxxHTv9mNEHZ2JaVrpeYQoEQ0ROj8e70uTqli9qj+Eox0dz8XvTnyKQyuQypmak4fv4EADrkXd/7nsY+awYAynbBAKo2FZ48aYOpqZbe+na09mCs+QXFhVC1qYzSVpjNj8nMa4/oidFYEJvYKSFramuQ9O8kjvMQoNXQIV5DoGprw5mLZ0k5DtvefbBojm66TPtx/v333wC4QW+PH9M2BH1s0Ix+iJ7iL5i8ADMzHtraVHjy5G+YmmrbVEbELA361yAAQJ2kFpU1lUabz5gSb2wIBUIkJyQbxSebZc2YuWgmRx1mUF5ZoaNZiaxE2L56u96P9JhSdih5ANoJ2EOPHdcMAJpbaAGVZ8aDhdACjVKtVsBsULJ2QVdMcVUXx75EQ7IR2cC2ly0amhpQUVVuFEGVKiV+/PVHUlERAKdskTFYt20tqu9VQSgQIj4mHiOHhaLo8nmkZaZx6pXGTJwBV2dXjB0+1qCa3NraytmUlZQSCqUCwh7aXC2FkpZJ9W1gZgDXjdFDwEdbWxsUSgVh/NYWlhw1q6a2BtPem0pcxpKHD7AgdgH4fD5sbGiCsm2KHaFOUouVm7nJYhuXbCTElDRK0NTcBDdnN70bUZ2kDgc14YgrElNIZQgfbx+49+2PxFULoFAq4OnmZVRGHKWiIOBrlzLDAhjFBtDGsVqaW6E9TABwTPnCHuZQKBVQsoRW857mnHs2bt/A8b+fZjnKROa07nu/m3FNESERpIJN1d0qjJwRgnGzxyI8NozkFrFx5uIZKJQKuDq56ZTZGB08muTAXygt0vt8ezQ1N0HAEqWYcfcWaW0bCg0PZROZgQkAjvrF+OfZBLTp1QdSWRMoioJMLsPpC52rmN113sVHJ5B/7z6wiyzZu/V3Ef/5XJ0Ag3KN6dDbwwv6MPv1d+CgsRild1JHlKIoSGVN6MnXxkM1a0LKRVYsA5KMZpGOdro82ATgWqPtNI655hYtkZ3EjlAqaV5Se79Wx+UxdrhWlmuW0R/C2AADNoQCIbxZ3tdhmqhhV+d+JE3wp9+yOc/IFbTwb4gnWppbkhj5U+dPctIP20Mqk0KpVHJmXkMTbWy2Y2UU1jfQRvhe1r113kET9IHWUEqcdawyk300hU3rH9RzxAoej4e1H69FfAw9qySNEty+R3eYbfHvCthazNgR4/DT13tx6ocCxGlKVrYPjbER9aHbr19CaVkpCosLdGJCRwaOJP/OLaBTY3KO52DXge859zY1N0GhVHCW94OHEp3xSDUrWty7j07/zZgXMWDMdOzwEwc7ja+loR6urIDcIL8gjg00c38mWaLdiWtSKBWorKnkZPAxmxPbTcMG4zgsr6zA5Hl0ktYwn0Bkp2lnsnd/b1iYW6BF3oLswz/hsfIxMd39nPczsr7KhnlPc9zXrFT28mYMy2wPBmN5suuj9XQwMAGABukD8qVcnegOMq4Q9stqJbWwt7WHrebLXL9ZRgi/68D3JPnUtncf+HoZX6+DnWF80EDmL1MkwNP9X5x2fUkLF0qLOEvb0twSA/rRz1Xfq+LYQa9WXMW3P3xLxgcA9ixCMcFjdiw3EWN5YhOZgQlAm7EYPso8yPa397XvCx6Ph5raO+Dz+XhVE+rX8PABxswajdA3QzmlJt6a9KbRurbISoT0VekkyOyHQz9wKixQFIWVm1NI6aH2aZAuji4IDQrjtAkFQh0ZsaNskZzjOVC1qVBTewcA4Omq/Wi1D+gSIba9tPlSshaab7N9cQxMmFRphqD2fezpaAmWWcu2ty3MheYkJGXejPmEAC3yFo6G4unhxamEaAzcnN2QGEfnX6pUKlKTacN3GxCVEEks9X4D/fVW/VqZuJLs5ABPJ0uwAAATEElEQVTNM9tXH2PnCdBj0vK/hqYHaHjYQMbHxCRQFIX7EtqfZqXZ9CiKQqO0ARbmFnpDJU0YXzsjflhbWsPO1h73H0jIbs4z48He1o6EpHi6e2LNorWcQQBAaFAYMtZkdMsSFB+TgNmvv0M+1KnzJ7F1zxaiNjrbO2Ptx2v1Puts74zs1GzMmjYL82bMx/rFuvlN7Mxiv4H+OJd9jhT1MjMxg6pNhaqaKliYW8DZwRkAcE9yD9JHUvTv259oTvckdGCHbS8bvcm7Zt4eA3X0XW8PL1Tfq0LZrTKyKTjYOeHU+ZOok9TBQeyAyaMmY/yI8ThSeAT3H9Rj5LDQLoe+tMfS95bijYg3kPZ9Kjl0RSgQYtSr4Vi1cHWHXlUXRxcsYxmO9SE5IRnTF7yBS9dLsPzrZUT+7udE++Or71VhsOdgQqirmlj6gR5aUe6Ghk6D/zVY72+YMRFmbFnU080TuQW5KGcRlOEX125cI0YFPp9PZDxD6KopzNPdE1tStkIml6GhqQHmQnOd5dtdBAwJQPTEaGQfziZVKwC6PAejMDDhmgBQfotuY0cmlleWa+4bpPc3TBhBWtqszbNkzHDsAIYhnvQX6Sil5FmC8ag+K2IySFmwEoH+2kSM6InRmBQeRcbl46UV2Rieym5jMkC8DeSYmjHUv1N/h9gwB7j+CzweD5ev6waflnQx7MYYa/8/CT6fj10bdiG34AhEliKyyTHjYsb55EkbrlZchchKxEmGYzJmBrj+C/pgIrYRw9XJDQ0PHxCZ0kHsACexM27fqyF8xs3ZDba9+6CiqrxL0XaPWgwnr/6vwDPjYVJ4FCGmvFWOiqpy2PbuQ4hXU3cHDQ8fcMLKa2prUCephYPYEba9bfW+2wTQGhZKWNZubw8vKJQKXNFMcT6fD1/PITrJUAwkjRK9mXP39cRQPi30pRvWSerw6ZefIjoxGgtWvm+UZYnBnzf/hPSRFL6eQwjx/nuFztPye1Gbu0XC5/t7GfRGmABaHsH2UTOC8HlWkMDwADqx9rSeuPYDx35BwtIEnfZnzXM3fLcBI98aibKb2o/65EkbZn06C1m/7sGF0iL8evIw4hbNNNqlzYyHGR+gTfgKGDyUtF0opWPth3Vg+DYBQM7UYBOPaTtVdILTJhQIkVuQq5NJ5iB2wKXrJUhjqXWSRgmpUPYscObiGWzdswV1klocO6vNHr52409UtEsiUCgVSFy1oFOiqtpUyC3IhVAgJGOmKApnLp7VKcZw6gIdIzCQJQm0hwlAiyquTm6ovldFxAcXRxd4uXuivLKC6MUuji7w6u+N6ntVuP7Xdc6Lhg4OgFAgRGpmKjnmZ8HKBTpnzz0N2Mn/TKYboOuKcBA7EqF9zdY1HWYkX//rOqrvVcGrvzcnya3h4QNOMYaa2hripmEHI7cHcTr7vUgbM9jRbUz2LZM0C2htn+2LrjiIHeDhSic1rNu2DuNmj+0wUq47YOIxQ4PCOP4mT3dPRIRodfx1H69F7JSZiBodhep7VZx8zfZgxsG26TLp2+xiDAwNHMSOcLLTNYowIARlkmRPnNcucUb/ZVeJiQgZDx6Pp7cWaPBLXffFdwXO9vQMmjxK91SEtKVfI21pGn76ei/ZvRlDCjvPqD1yC38Dj8fjRDyf1tQVYR8vxCRIBPoO47jX24MQlNGY/lv6XyIq+Xj7wEHsiCvlpSQ+0sXRBYMGDEb1vSqdnbS9AeJZg7F96vMGMKIQe+YSy5ke9zJAxwJU372NQQMGk+VOURSO/34Cgz21bTK5DBc1u/7Y4I7HSAjq0c9Db+WXccPHQqFU4JYm0BYA3hj/OgDolMJgGyCeFQqLC7AtKx0bvtuA//z0HQAgz0CNp/Zgu3H0gek/Mx4AuHDlAhoePsCEkRNI2+9/nINMLoOFuQUC/YJ03sMGIah5T3MEaW7OK8wjN4zT8Ca2qBQRMh6W5pacmkcM4qPndviDxqLqbhVee38qZi6eiXXb1mHrni24efsmADoCuX1VWn1g+qyvRCa79hR7uR849gsAcNp+O02Xrxs6JKDTsHdOJFSUpszvmYtniJAeMCQAHv08OKXIrS2tMTEsEi3yFk6VQ4D2A7FnqchKhHkz5iM5PhkvDTJu9tbU1uDND98kRmWhQAi/gf4Y5hNIiJO8IZkYhvWhtKyU9I3tU2KQfTgLLfIWvDbuNUIkSaME+efy4eXuSZZ7s6yZeHn18W4dtD8ZYejUoWrnYCfOAXq7c3apnYOd1LtzdnFONRgQ7qH2Huulc3DelfIr6gHhHmrfSb46Z3GwD0RhDmlpfyLCByvfJ9cj50bqvOPI6SOkn6Niw9Q79m1XXym/or5Vc0t98epF9eotq8m5I/OWxes9EWFUbJh6QLgH5/QH5qyT1VtWk7Yd+7arnYOd1L6TfI06uYEzQ9nmuJx8bT2RCaETIbISYY/mvE2AFpMiwydCJpfp+IG8PbyRviod21dv16m9FDOh88QGRsUTCoTIWJ+h847RwaORszUHzvbOKK+swPK05Rg/JwLjZo3F5HlR2LpnCxRKBbzcPbFq4Wqd9xdfKUZ5ZQWiRkdx6i7/dGQveDweXmfxVOaM0cjQiUYZznWCH6M007q8soLs4pbmlvB70R9XK65ydvbZr80Bj8fjiFUMRgSE6D3x1ZgaIK+8FEyCxQA6APfQiYOcTAyxjRi7Nu5GREgEsfKzM+teGuSP7LS9enneph2bIBQIETd1Fmk7UngEdZJaBL88nBhISstKieE9qhO7LwMdgcrT3RMvDfLHH9dKkLk/g4gh44aPw6nzJ5GelU7aPN09MTF0Ig4cO4DC4gKjTnlpn3X35MkTUG0qztdf+t5SzJwyEzwzHkbNHEW0LZGVCEvmLiGuazdnN2xJ2Yqa2hoUXS4imR5+A/0Q5P+KXgNGYXEBLpQWYcqYKRwPw7Y9dGVz5shKAKRyo99Af+OPA9bHB5iTZNg8Rt4qVwe+NkztHOzEObz0Vs0t9YBwD/Wo2DB16+PWDvlLQ1MD4X3sv2s3rum9/93P5ug9sYbN37vy1/q4lZy9xD7M6sjpI4RfM2337t8jfPjHQz8+3Wk144ZHwEHsyCmhy+fz8e70dwEAabu02R4uji6IGh2F8soKwm8MfDh8sjFZb11mtmrLhqFjLtIy0zosl2YIPxz8AeWVFfAbyI1s/jLzSwBckY8J2rDt3adTNw8begnK5/MRPTEaAF3HnTEoR0+IgYPYEafOn+TwUqb481cZX+kdKEVRmPPpOwaPrmBvgOxn2kcTs3ll/rljnQ6OjZraGny1cxMAcLJADp04SKqlMVF/MrkMWYfpydGVGAOgg6MrEqIT6FzOR1Ks2UrvlHw+H+sX09lqSf9OInKpj7cPUhJTIH0kxYwPo3WsO6eKTqKwuNBgJ8orK3RO2Obz+fBl+XLWL96A8z8XEetPVxJ2KYrCzMX0abMpiSmEH0oaJfh80+cQCoQcF3VuQS6kj6RwEDt2OcbAIEH5fD7iY+glwC5HPvzl4QgNCkOdpJYT0hI7ZSaG+QSi+u5tLGcV3geA0MAwONs7d9iR9ifHAMDKhf/GiIARiImcgTfGv0FXWBDRrofOKs2ysfzrZai+exvDfAI5Iebrtq2FTC7DZNYGpWpTIeNnOnGi/Qk9xqDDnJGpY6bB1clNZ4ktfW8phAIhMvdncIiwYckGiKxEyD6czanOyOfzsfpDXXmQDYVSgYRlczluFAexA77fsIuc61EnqSMuFWOrlu09shfZh7MhshJxCryyj9tYMncJaT9w7ADKKyvgIHYkrKwr6JCgfD4fibPoEJnNu7/hOOziY+KhUCrwycZPyP0uji5Y9zGdybEibTmHz44ICEGS5uRXQ6i+exvTE183WLXr613amPmOjLwMiq8UY4Um5mrdx+s4CsKG7+h+Lpm7hMiqTNoNACTFJXUrAqbTrKbJoyaT84W2aRKmADq+ycvdE5eul3Bm49gR4zBvxnwolAq8t3w+hziJcUmd8qTqu7cxZd5kpGWmoqa2Bqo2Fe7W38XKzSmc4AR2TSl9qJPUIf5z7XG97INSD504iD+ulWCYTyAnHJM5HUJfeLmxMOoYyuIrxZi+4A0IBULs//YXeGtCU0rLShGTFA2RdS/k7sjlaCULVr6PX08ehoPYEad/OM352tuy0jkZGoYgFAhhbm4BubyFc6+zvTNO7DppcAaxDxiMGhWFVNZRF8zJuQBwMP0QmbXMUUAKpQJJcUnkHOWuwqi8u4AhARjmQ5+J9Nmmz4iFx8fbB4lxiaiT1GLhmoWcZzYmbyKbV+yiWM4mEh+TgKzUbE41M31QKBVoePhAh/AfzfnYIDGbZc2c0xo3aM5OAkBOcpA+kmLJ3CUcFrA8bTlJfujqzs5Gp4f8MRjgOgAHjx/Enfo7kCtayaF5Lw9+GTeqKpB/Nh/3G+oREhACUxNTmJqaImJEBOStLTh86jBOXzgFFwcX9NME9Nr3sccbEdPRp7ctGqWNRlXDFQqE+HjOx6S8Znvkn83HR2sXorS8FBEhEfhm2beE8C2tcixIeR+/X/odoUFhWDRnMYm72vDdBuQcPwChQIhvU741qpi2QXRFdftm92ai/u3L28dR04KnB6udg53UH65J0nlu0fpF5LmlX32u9yDScyXn1IvWL1IHTw8mKh/7LyohkqPysv8eNj9UL/3qc3LvovWLONflrXJiNox4ZxzHDMc+sLW7Ki37r8uHTTMnyQ4a/6L6RvUN0n7txjX1oPEvEqK1f27Hvu2EUMHTgzs8W/lWzS31uZJz6n15+9SHT/5qUNdXtanUh0/+Sj7mgHAP9Y5923X0d8YmMHTqUI7981bNLdLnrpyo+0wJWlNbQzoxKjZMLX0k5cwyhmj6iHrx6kVy1C5jjGAf49uVv3Ml58jHZd7VfgbLW+WEmL6RPpwPI2+Vq8Pjwo06ibwrf10+Xx6gTWAzF9MaR/tD/c5cPIP4z2hxJTJsIjYmb+JsIKo2FX44+AO2/LiFmOW83D0xbkQEgvxfgaebJyx6muu4aptlzaioqsD5kt+RV5hL7JS2vftg/pvz8VbUWxxzHUVRePfzOSgsLqSN45uyiHQCAJ9++Skx5qSvTNc5f7676BZBAe2pigCQHJ9McpUAWsyK/3wupI+k8Bvoj+zUbJ1dmalO9v2BXRwLlFAghJ2tPXpZ94KJCfD333Taz/2Ges5uL7ISIW5qHOKmzdIxIjfLmrFwzUJyfl7GugyO7TP/bD7eS5kPlUr1VCKSPnSboID26EmhQIhtq7/jFB1gVyAb7DkYXyzZqDdknKIo5J3JxekLp3HpegnuP5DolU+FAiHs+ojhN9AfI4eNRGhgmN4Y9+IrxViyfgmq71XBb6A/vl3xLSeNm32se2TYRHy97JvuDl8vnoqg7GWlLyWbPVOY1Ot5Mzo+HVHSKEGdpA7NMikUjxUQ9hDC2lIEB7FDh9HMMrkMW3/cisz9GVAoFXpLDxVfKcacT96BTC7rsDTR0+CpCMqA0YoA6D1YNOd4DlK+XkGSEMaFjEN8dMJTJzkAtLa2LTud2FodxI5Y9/FaHXcMm0UZYkPPAs+EoDK5DO9++i4JDpsyZgrWfbye02FJowSpmanIOXYACqUCPB4PwS8PR8yEGIQEhHRpcBRFoaC4ADv27SC/KRQIETdtFua9OY/DCiiKQvLGJTigORXCb6A/MtZndKtOnzF4JgQFQA5aYeos+Q30x5effsmJTwdo3rotOx15BXmcagsBPsPgP9AP7n37w9neGeY9zcEz40HVpkJTcxPqH9ShvLIcpRVXcOnPElYRAEtMDItEQkyCjobTvg5JaFAY56z754FnRlCAFonWbl1DMt9EViJ8kvCpXstNnaQOh04cRE7+Ab3VFnk8HsxMzND2d5ve0pauzv0QPSEG0RNj9M42tqQB0KdApiSmdKsMZlfwTAnKYO+RvVj17UpSyGr26+9gQewCvQN/8qQNN6r+wn+vFuNy2WVU372NpuYmtLTK0PakDWamZrDoaQk7Wzu4u7hjiOdgclqOPrTfnIQCIZZ9sOy5V45k8FwICtBL+5ONn5Dl5iB2xILYDzB1zDSjlhzbL2Xs/TnHc5CamUrk2o7EteeF50ZQgB5kxv6dnHpMrk5uiJ44HVPGTH0mSV2SRgkOHPsF2Yd/4sSBxkTOwIoPVjxXfqkPz5WgDCoqK3Dw+EFkHd5DeJpQIIRXf2/4evtg5LCR8OrvbRSBJY0SlN8qQ9HlCyi+UoTrf5WRzc3S3BJvRb2NqFFR/+isZOMfISgDSaMEWb/uQU7+QZ2oYkYTcuvbH3Y2YvSy0tbzaHr0EPcbJai6c0uvJuVs74zXxr2GmMgZzzyVsav4RwnKgKIoFF0+j9zCXBz//US3MkVEViKEBoZi8qjJCPQN+seXtiH8TwjKBkVRKLtVhtLyyyivrEDVvSpIpQ/R3CIjuafWFpawtuwFdxd3+lRxL1+4u7h3etj0/wL/c4L+/4bunwz1f9CL/yPoM8b/EfQZ4/8BzvZ3v9/pS/MAAAAASUVORK5CYII=";
module.exports = (ctx) => {
	return {
		generateTastingReport: async (reportId) => {
			try {
				const reportModel = require("../models/tastingReport")(ctx);
				const reportResult = await reportModel.printingDetails(reportId);
				if (!reportResult.status) {
					return reportResult;
				}
				const report = reportResult.doc;
				if (!report.seller._id) {
					report.isConsolidated = true;
				}
				let hasLotNo = false;
				if (report.invoices[0].lotNum) {
					hasLotNo = true;
				}
				let tableHeaders = [{text: "INVOICE", style: "th"}, {text: "GRADE", style: "th"}];
				let columnWidths = ["auto", "auto"];
				let summaryRow = [{text: "", style: "tf"}, {text: "", style: "tf"}];
				if (hasLotNo) {
					tableHeaders = [{text: "LOT NO", style: "th"}, {text: "INVOICE", style: "th"}, {text: "GRADE", style: "th"}];
					columnWidths = [35, "auto", "auto"];
					summaryRow = [{text: "", style: "tf"}, {text: "", style: "tf"}, {text: "", style: "tf"}];
				}
				if (report.hasPriceIdea) {
					tableHeaders.push({text: "PRICE IDEA", style: "th"});
					columnWidths.push(50);
					summaryRow.push({text: "", style: "tf"});
				}
				tableHeaders.push({text: "PKG DT", style: "th"});
				columnWidths.push(50);
				summaryRow.push({text: "", style: "tf"});
				const moment = require("moment");
				const tableBody = [];
				const marks = [];
				tableBody.push(tableHeaders);
				for (let loop=0, length = report.invoices.length; loop<length; loop++) {
					const _invoice = report.invoices[loop];
					let lineTotal= 0;
					if (marks.indexOf(_invoice.mark)<0) {
						marks.push(_invoice.mark);
					}
					const row = [];
					if (hasLotNo) {
						row.push(_invoice.lotNum?_invoice.lotNum:"");
					}
					// row.push(`${_invoice.invPrefix}${_invoice.invNumber}`);
					row.push(`${_invoice.invNo}`);
					row.push(_invoice.grade);
					let insertedRow = false;
					if ((!_invoice.packingInvoiceId) && _invoice.manuallyAdded) {
						insertedRow = true;
					}
					if (insertedRow) {
						row.length = 0;
						if (hasLotNo) {
							row.push({text: _invoice.lotNum?_invoice.lotNum:"", bold: true});
						}
						row.push({text: `${_invoice.mark}/\n${_invoice.invNo} *`, bold: true});
						// row.push({text: `${_invoice.mark}/\n${_invoice.invPrefix}${_invoice.invNumber} *`, bold: true});
						row.push({text: `${_invoice.grade}`, bold: true});
						// insertedRow = true;
					}
					if (report.hasPriceIdea) {
						if (insertedRow) {
							row.push({text: ""+(_invoice.priceIdea?_invoice.priceIdea:0), bold: true});
						} else {
							row.push(_invoice.priceIdea?_invoice.priceIdea:0);
						}
					}
					if (_invoice.mfgDate) {
						row.push(moment(_invoice.mfgDate).format("DD/MM"));
					} else {
						if (insertedRow) {
							// row.push({text: "--", bold: true});
							row.push("--");
						} else {
							row.push("--");
						}
					}
					for (let inner=0, innerLength = _invoice.values.length; inner<innerLength; inner++) {
						if (loop==0) {
							let effectiveName = _invoice.values[inner].param;
							if (effectiveName=="INFUSION") {
								effectiveName = "INF";
							} else if (effectiveName=="LIQUOR") {
								effectiveName = "LIQ";
							}
							tableHeaders.push({text: effectiveName, style: "th"});
							columnWidths.push(25);
						}
						if (inner==4) {
							continue;
						}
						if (_invoice.values[inner].val && (!isNaN(_invoice.values[inner].val))) {
							if (!isNaN(_invoice.values[inner].val)) {
								lineTotal += Number(_invoice.values[inner].val);
							}
							if (insertedRow) {
								// row.push({text: ""+_invoice.values[inner].val, bold: true});
								row.push(_invoice.values[inner].val);
							} else {
								row.push(_invoice.values[inner].val);
							}
						} else {
							if (insertedRow) {
								// row.push({text: "--", bold: true});
								row.push("--");
							} else {
								row.push("--");
							}
						}
					}
					if (loop==0) {
						tableHeaders.push({text: "Σ", style: "th"});
						tableHeaders.push({text: "REMARKS", style: "th"});
						columnWidths.push(30);
						columnWidths.push("*");
					}
					if (lineTotal != 0) {
						if (!insertedRow) {
							row.push(lineTotal);
						} else {
							row.push(lineTotal);
							// row.push({text: ""+lineTotal, bold: true});
						}
					} else {
						if (!insertedRow) {
							row.push("--");
						} else {
							row.push("--");
							// row.push({text: "--", bold: true});
						}
					}
					if (_invoice.remarks) {
						if (!insertedRow) {
							row.push(_invoice.remarks);
						} else {
							row.push({text: _invoice.remarks, bold: true});
						}
					} else {
						if (!insertedRow) {
							row.push("");
						} else {
							// row.push({text: "--", bold: true});
							row.push("");
						}
					}
					tableBody.push(row);
				}
				let summarytotal = 0;
				const summaryRows = [];
				for (let inner=0, innerLength = report.summary.values.length; inner<innerLength; inner++) {
					if (inner==4) {
						continue;
					}
					if (report.summary.values[inner].val && (!isNaN(report.summary.values[inner].val))) {
						summarytotal += report.summary.values[inner].val;
						summaryRow.push({text: ""+report.summary.values[inner].val, style: "tf"});
					} else {
						summaryRow.push({text: "", style: "tf"});
					}
					if (report.summary.values[inner].remarks) {
						let _remarksVal = "";
						if (typeof report.summary.values[inner].remarks === "string" || report.summary.values[inner].remarks instanceof String) {
							_remarksVal = report.summary.values[inner].remarks;
						} else if (Array.isArray(report.summary.values[inner].remarks)) {
							_remarksVal = report.summary.values[inner].remarks[0];
						}
						if (_remarksVal) {
							let _name = null;
							if (["LA", "LF"].indexOf(report.summary.values[inner].param)>=0) {
								_name = "Leaf";
							} else if (["INF", "IN"].indexOf(report.summary.values[inner].param)>=0) {
								_name = "Infusion";
							} else if (["LIQ", "LQ"].indexOf(report.summary.values[inner].param)>=0) {
								_name = "Liquor";
							} else {
								_name = report.summary.values[inner].param.toTitleCase();
							}
							summaryRows.push({columns: [
								{text: _name, bold: true, width: "25%", alignment: "left", margin: [0, 0, 0, 35]},
								{text: _remarksVal, alignment: "left", margin: [0, 0, 0, 35]},
							]});
						}
					}
				}
				if (summarytotal>0) {
					summaryRow.push({text: ""+summarytotal, style: "tf"});
					summaryRow.push({text: "", style: "tf"});
					tableBody.push(summaryRow);
				}
				let reportMarkLine = "";
				let reportSellerLine = "";
				if (!report.isConsolidated) {
					reportMarkLine = `Mark : ${report.invoices[0].mark}`;
					reportSellerLine = `Seller : ${report.seller.name}`;
				}
				const content = [
					{columns: [
						{image: logoImage, width: 42},
						[
							{text: report.taster.name, fontSize: 14, bold: true, margin: [10, 0, 0, 0]},
							{text: report.taster.address, fontSize: 12, bold: true, margin: [10, 0, 5, 0]}],
					], margin: [0, 0, 0, 10]},
					{columns: [
						{text: reportSellerLine, bold: true, alignment: "left"},
						{text: "", bold: true, alignment: "right"},
						// {text: `Doc # : ${report.docNum}`, bold: true, alignment: "right"},
					]},
					{columns: [
						{text: reportMarkLine, bold: true, alignment: "left", margin: [0, 0, 0, 35]},
						{text: `Date : ${moment(report.date.getTime()).format("Do MMM  YYYY")}`, bold: true, alignment: "right", margin: [0, 0, 0, 35]},
					]},
					{
						style: "table",
						table: {
							headerRows: 1,
							widths: columnWidths,
							body: tableBody,
						},
						layout: "headerLineOnlyLight",
					}];
				let line1Drawn = false;
				let line2Drawn = false;
				if (summaryRows.length>0) {
					content.push({table: {headerRows: 1, widths: ["100%"], body: [[""], [""]]}, layout: "headerLineOnlyLight"});
					line1Drawn = true;
					for (let loop=0, length = summaryRows.length; loop<length; loop++) {
						content.push(summaryRows[loop]);
					}
				}
				if (report.summary.analysis) {
					if (!line1Drawn) {
						content.push({table: {headerRows: 1, widths: ["100%"], body: [[""], [""]]}, layout: "headerLineOnlyLight"});
					}
					content.push({columns: [
						{text: "Analysis :", bold: true, width: "25%", alignment: "left", margin: [0, 0, 0, 35]},
						{text: report.summary.analysis, alignment: "left", margin: [0, 0, 0, 35]},
					]});
					content.push({table: {headerRows: 1, widths: ["100%"], body: [[""], [""]]}, layout: "headerLineOnlyLight"});
					line2Drawn = true;
				}
				if (!line2Drawn) {
					content.push({table: {headerRows: 1, widths: ["100%"], body: [[""], [""]]}, layout: "headerLineOnlyLight"});
				}
				if (report.preparedBy) {
					content.push({text: `Prepared By - ${report.preparedBy}`, alignment: "right", margin: [0, 30, 0, 0], decoration: "underline"});
				}
				const docDefinition = {
					// pageOrientation: "landscape",
					pageSize: "A4",
					// pageMargins: [30, 140, 40, 30],
					pageMargins: [30, 30, 30, 30],
					footer: function(currentPage, pageCount) {
						return {columns: [
							{text: `Page ${currentPage} of ${pageCount}`, style: "leftAlign"},
							{text: "Powered by - TEAlink", style: "rightAlign", link: "https://illimitable.in/tealink.html"},
						]};
					},
					/* header: function(currentPage, pageCount, pageSize) {
						return [
							{text: report.taster.name, style: "header"},
							{text: report.taster.address, style: "headerLine2"},
							{columns: [
								{text: `Mark : ${report.invoices[0].mark}`, bold: true, style: "leftAlign"},
								{text: `Doc # : ${report.docNum}`, bold: true, style: "rightAlign"},
							]},
							{columns: [
								{text: `Seller : ${report.seller.name}`, bold: true, style: "leftAlign"},
								{text: `Date : ${moment(report.date.getTime()).format("Do MMM  YYYY")}`, bold: true, style: "rightAlign"},
							]},
						];
					}, */
					info: {
						// title: `${report.docNum}`,
						author: "TEAConnect by Illimitable",
						subject: `Tea tasting report for ${report.seller.name}`,
						creator: "TEAConnect by Illimitable",
						producer: "TEAConnect by Illimitable",
					},
					content: content,
					defaultStyle: {
						fontSize: 9,
					},
					styles: {
						header: {
							fontSize: 18,
							bold: true,
							margin: [0, 20, 0, 0],
							alignment: "center",
						},
						leftAlign: {alignment: "left", margin: [30, 0, 0, 0]},
						rightAlign: {alignment: "right", margin: [0, 0, 30, 0]},
						headerLine2: {
							margin: [0, 10, 0, 20],
							alignment: "center",
						},
						table: {
							margin: [0, 5, 0, 15],
						},
						th: {
							bold: true,
							fontSize: 9,
							color: "black",
						},
						tf: {
							// fontSize: 13,
							color: "black",
							fillColor: "#CCCCCC",
						},
					},
				};
				const fonts = {
					Roboto: {
						normal: "assets/fonts/Roboto-Regular.ttf",
						bold: "assets/fonts/verdanab.ttf",
						italics: "assets/fonts/Roboto-Italic.ttf",
						bolditalics: "assets/fonts/Roboto-MediumItalic.ttf",
					},
				};
				var myTableLayouts = {
					headerLineOnlyLight: {
						hLineWidth(i, node) {
							if (i === 0 || i === node.table.body.length) {
								return 0;
							}
							return (i === node.table.headerRows) ? 1 : 0;
						},
						vLineWidth(i) {
							return 0;
						},
						paddingLeft(i) {
							return i === 0 ? 0 : 8;
						},
						paddingRight(i, node) {
							return (i === node.table.widths.length - 1) ? 0 : 8;
						},
					},
				};
				const PdfPrinter = require("pdfmake/src/printer");
				const printer = new PdfPrinter(fonts);
				const fs = require("fs");
				const path = require("path");
				var pdfDoc = printer.createPdfKitDocument(docDefinition, {tableLayouts: myTableLayouts});
				let targetDir = icplApp.appPath + path.sep + "pdfs" + path.sep;
				if (!fs.existsSync(targetDir)) {
					fs.mkdirSync(targetDir);
				}
				targetDir = targetDir + report.seller._id + path.sep;
				if (!fs.existsSync(targetDir)) {
					fs.mkdirSync(targetDir);
				}
				targetDir = targetDir + "tasting-reports" + path.sep;
				if (!fs.existsSync(targetDir)) {
					fs.mkdirSync(targetDir);
				}
				const pdfPath = `pdfs/${report.seller._id}/tasting-reports/${report._id.toHexString()}.pdf`;
				pdfDoc.pipe(fs.createWriteStream(pdfPath));
				pdfDoc.end();
				reportModel.updatePdfPath(reportId, pdfPath);
				// eslint-disable-next-line no-constant-condition
				if (false && report.seller.emailId && (!icplApp.isClientMode)) {
					setTimeout(new function() {
						const service = require("../services/httpService");
						service.postMultipart("https://mail.tealink.in", {
							token: "8c0e8a18-e1ad-4902-aceb-c5d9865b36af",
							taster: report.seller.name,
							// docNumber: report.docNum,
							date: moment(report.date.getTime()).format("Do MMM YYYY"),
							sellerMailId: report.seller.emailId,
						}, [pdfPath], ["report"]);
					}, 1000);
				}
				return {status: true, msg: "OK", path: pdfPath};
			} catch (err) {
				return {status: false, msg: err.msg?err.msg:defaultErrorMsg};
			}
		},
	};
};
