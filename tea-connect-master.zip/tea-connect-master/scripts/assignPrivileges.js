global.masterPrivileges = {
	"user_management": {
		"display": "Users",
		"page": "userManagement",
		"path": "/user-management.html",
		"access": [
			"view",
			"create",
			"update",
		],
		"childNodes": null,
	},
	"master_management": {
		"display": "Masters",
		"access": [
			"view",
		],
		"childNodes": {
			"seller_management": {
				"display": "Seller Management",
				"page": "sellerManagement",
				"path": "/masters/seller-management.html",
				"access": [
					"view",
					"create",
					"update",
				],
				"childNodes": null,
			},
			"location_management": {
				"display": "Location Management",
				"page": "locationManagement",
				"path": "/masters/location-management.html",
				"access": [
					"view",
					"create",
					"update",
				],
				"childNodes": null,
			},
			"auction_center_management": {
				"display": "Auction Center Management",
				"page": "auctionCenterManagement",
				"path": "/masters/auction-center-management.html",
				"access": [
					"view",
					"create",
					"update",
				],
				"childNodes": null,
			},
			"category_management": {
				"display": "Category Management",
				"page": "categoryManagement",
				"path": "/masters/category-management.html",
				"access": [
					"view",
					"create",
					"update",
				],
				"childNodes": null,
			},
			"mark_management": {
				"display": "Mark Management",
				"page": "markManagement",
				"path": "/masters/mark-management.html",
				"access": [
					"view",
					"create",
					"update",
				],
				"childNodes": null,
			},
			"grade_management": {
				"display": "Grade Management",
				"page": "gradeManagement",
				"path": "/masters/grade-management.html",
				"access": [
					"view",
					"create",
					"update",
				],
				"childNodes": null,
			},
			"tasting_parameter_management": {
				"display": "Tasting Parameter",
				"page": "tastingParameter",
				"path": "/masters/tasting-parameter-management.html",
				"access": [
					"view",
					"create",
					"update",
				],
				"childNodes": null,
			},
			"group_management": {
				"display": "Group management",
				"page": "groupManagement",
				"path": "/masters/group-management.html",
				"access": [
					"view",
					"create",
					"update",
				],
				"childNodes": null,
			},
		},
	},
	"mapping_management": {
		"display": "Mapping",
		"access": [
			"view",
		],
		"childNodes": {
			"group_seller_mapping": {
				"display": "Group Seller",
				"page": "groupSellerMapping",
				"path": "/mapping/group-seller.html",
				"access": [
					"view",
					"create",
					"update",
				],
				"childNodes": null,
			},
			"seller_mark_mapping": {
				"display": "Seller Mark",
				"page": "sellerMarkMapping",
				"path": "/mapping/seller-mark.html",
				"access": [
					"view",
					"create",
					"update",
				],
				"childNodes": null,
			},
			"mark_entity_mapping": {
				"display": "Mark Entity",
				"page": "markEntityMapping",
				"path": "/mapping/mark-entity.html",
				"access": [
					"view",
					"create",
					"update",
				],
				"childNodes": null,
			},
		},
	},
	"invoice_management": {
		"display": "Invoices",
		"access": [
			"view",
		],
		"childNodes": {
			"muster_tasting_invoices": {
				"display": "Muster",
				"page": "musterTastingInvoices",
				"path": "/invoices/muster.html",
				"access": [
					"view",
					"create",
					"update",
				],
				"childNodes": null,
			},
			"auction_tasting_invoices": {
				"display": "Auction",
				"page": "auctionTastingInvoices",
				"path": "/invoices/auction.html",
				"access": [
					"view",
					"create",
					"update",
				],
				"childNodes": null,
			},
			"finance_tasting_invoices": {
				"display": "Finance",
				"page": "financeTastingInvoices",
				"path": "/invoices/finance.html",
				"access": [
					"view",
					"create",
					"update",
				],
				"childNodes": null,
			},
			"private_sale_tasting_invoices": {
				"display": "Private Sale",
				"page": "privateSaleTastingInvoices",
				"path": "/invoices/private-sale.html",
				"access": [
					"view",
					"create",
					"update",
				],
				"childNodes": null,
			},
		},
	},
	"tea_tasting": {
		"display": "Tasting",
		"page": "teaTasting",
		"path": "/tea-tasting.html",
		"access": [
			"create",
			"update",
		],
		"childNodes": null,
	},
	"tasting_reports": {
		"display": "Reports",
		"access": [
			"view",
		],
		"childNodes": {
			"muster_tasting_reports": {
				"display": "Muster",
				"page": "musterTastingReports",
				"path": "/reports/muster.html",
				"access": [
					"view",
				],
				"childNodes": null,
			},
			"auction_tasting_reports": {
				"display": "Auction",
				"page": "auctionTastingReports",
				"path": "/reports/auction.html",
				"access": [
					"view",
				],
				"childNodes": null,
			},
			"finance_tasting_reports": {
				"display": "Finance",
				"page": "financeTastingReports",
				"path": "/reports/finance.html",
				"access": [
					"view",
				],
				"childNodes": null,
			},
			"private_sale_tasting_reports": {
				"display": "Private Sale",
				"page": "privateSaleTastingReports",
				"path": "/reports/private-sale.html",
				"access": [
					"view",
				],
				"childNodes": null,
			},
		},
	},
};
global.userRoleMap = {};
global.userRoleMap.Admin = {
	"user_management": global.masterPrivileges.user_management,
	"master_management": {
		"display": "Masters",
		"access": [
			"view",
		],
		"childNodes": {
			"location_management": {
				"display": "Location Management",
				"page": "locationManagement",
				"path": "/masters/location-management.html",
				"access": [
					"view",
					"create",
					"update",
				],
				"childNodes": null,
			},
			"auction_center_management": {
				"display": "Auction Center Management",
				"page": "auctionCenterManagement",
				"path": "/masters/auction-center-management.html",
				"access": [
					"view",
					"create",
					"update",
				],
				"childNodes": null,
			},
		},
	},
};
global.userRoleMap.Support = {
	"master_management": {
		"display": "Masters",
		"access": [
			"view",
		],
		"childNodes": {
			"seller_management": {
				"display": "Seller Management",
				"page": "sellerManagement",
				"path": "/masters/seller-management.html",
				"access": [
					"view",
					"create",
					"update",
				],
				"childNodes": null,
			},
			"category_management": {
				"display": "Category Management",
				"page": "categoryManagement",
				"path": "/masters/category-management.html",
				"access": [
					"view",
					"create",
					"update",
				],
				"childNodes": null,
			},
			"mark_management": {
				"display": "Mark Management",
				"page": "markManagement",
				"path": "/masters/mark-management.html",
				"access": [
					"view",
					"create",
					"update",
				],
				"childNodes": null,
			},
			"grade_management": {
				"display": "Grade Management",
				"page": "gradeManagement",
				"path": "/masters/grade-management.html",
				"access": [
					"view",
					"create",
					"update",
				],
				"childNodes": null,
			},
			"tasting_parameter_management": {
				"display": "Tasting Parameter",
				"page": "tastingParameter",
				"path": "/masters/tasting-parameter-management.html",
				"access": [
					"view",
					"create",
					"update",
				],
				"childNodes": null,
			},
			"group_management": {
				"display": "Group management",
				"page": "groupManagement",
				"path": "/masters/group-management.html",
				"access": [
					"view",
					"create",
					"update",
				],
				"childNodes": null,
			},
		},
	},
	"invoice_management": global.masterPrivileges.invoice_management,
	"mapping_management": global.masterPrivileges.mapping_management,
	"tea_tasting": global.masterPrivileges.tea_tasting,
	"tasting_reports": global.masterPrivileges.tasting_reports,
};
global.userRoleMap.Taster = {
	"master_management": {
		"display": "Masters",
		"access": [
			"view",
		],
		"childNodes": {
			"tasting_parameter_management": {
				"display": "Tasting Parameter",
				"page": "tastingParameter",
				"path": "/masters/tasting-parameter-management.html",
				"access": [
					"view",
					"create",
					"update",
				],
				"childNodes": null,
			},
		},
	},
	"tea_tasting": global.masterPrivileges.tea_tasting,
	"tasting_reports": global.masterPrivileges.tasting_reports,
};

const adminId = "5f37df7a4ab7c06856a378d1";
const MongoClient = require("mongodb").MongoClient;

async function processData() {
	const url = "mongodb://localhost:27017";
	const dbName = "teaconnect";
	const now = new Date();
	MongoClient.connect(url, {useUnifiedTopology: true}, async function(err, client) {
		const db = client.db(dbName);
		const users = await db.collection("user").find({}, {projection: {userType: 1}}).toArray();
		const bulk = db.collection("user").initializeUnorderedBulkOp();
		let doUpdate = false;
		for (let loop=0, length = users.length; loop<length; loop++) {
			const type = users[loop].userType;
			if (["Admin", "Support", "Taster"].indexOf(type)>=0) {
				const id = users[loop]._id.toHexString();
				if (id==adminId) {
					console.log("Admin found");
				} else {
					doUpdate = true;
					bulk.find({_id: users[loop]._id}).updateOne({$set: {privileges: global.userRoleMap[type], updatedAt: now}});
				}
			}
		}
		let writeErrors = [];
		try {
			if (doUpdate) {
				const result = await bulk.execute();
				writeErrors = result.getWriteErrors();
			}
		} catch (err) {
			writeErrors = err.result.getWriteErrors();
		}
		console.log(writeErrors);
		client.close();
	});
}

processData();

