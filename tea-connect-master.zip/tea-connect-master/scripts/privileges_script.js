/* eslint-disable no-console */
/* eslint-disable no-unused-vars */
const fs = require("fs");
const path = require("path");
const MongoClient = require("mongodb").MongoClient;
const ObjectID = require("mongodb").ObjectID;
const companyId="5eb2d65f5bbfeb46054a93b0";
const adminId = "5f37df7a4ab7c06856a378d1";

const privilegeToDelete = [
	"vehicle_master",
	"usual_transporter_master",
];

async function processData() {
	const url = "mongodb://localhost:27017";
	const dbName = "teaconnect";
	const now = new Date();
	MongoClient.connect(url, {useUnifiedTopology: true}, async function(err, client) {
		const db = client.db(dbName);
		const admin = await db.collection("user").findOne({_id: ObjectID(adminId)});
		const privileges = admin.privileges;
		let node = privileges.mapping_management;
		if (!node) {
			node = {display: "Mapping Management", access: ["view"], childNodes: {}};
			privileges.mapping_management = node;
		}
		node.childNodes["group_seller_mapping"] = {
			"display": "Group Seller Mapping",
			"page": "groupSellerMapping",
			"path": "/mapping/group-seller.html",
			"access": [
				"view",
				"create",
				"update",
			],
			"childNodes": null,
		};
		node.childNodes["seller_mark_mapping"] = {
			"display": "Seller Mark Mapping",
			"page": "sellerMarkMapping",
			"path": "/mapping/seller-mark.html",
			"access": [
				"view",
				"create",
				"update",
			],
			"childNodes": null,
		};
		await db.collection("user").findOneAndUpdate({_id: ObjectID(adminId)}, {$set: {privileges: privileges, updatedAt: now}});
		// console.log(Object.keys(transactionPrivileges.childNodes));
		// let privilegeNames = Object.keys(privileges);
		// const company = await db.collection("company").findOne({_id: companyId});
		// const userRoles = [{"name": "Admin", "privileges": {}}];
		// company.userRoles[0].privileges = privileges;
		// await db.collection("company").findOneAndUpdate({_id: companyId}, {$set: {masterPrivileges: privileges, userRoles: company.userRoles, updatedAt: now}});

		/* let policy = ['var tmp={\n'];
        for(let loop=0, length= privilegeNames.length; loop<length; loop++){
            if(privileges[privilegeNames[loop]].path){
                policy.push(`\t'${privileges[privilegeNames[loop]].path}':{\n\t\trequired: (session) => {\n\t\t\treturn cp(session, '${privilegeNames[loop]}', ["view"])\n\t\t},redirect: "/login.html"\n\t},\n`);
            }else if(privileges[privilegeNames[loop]].childNodes){
                let innerPrivileges = privileges[privilegeNames[loop]].childNodes;
                let innerPrivilegeNames = Object.keys(innerPrivileges);
                for(let inner=0, innerLength= innerPrivilegeNames.length; inner<innerLength; inner++){
                    if(innerPrivileges[innerPrivilegeNames[inner]].path){
                        policy.push(`\t'${innerPrivileges[innerPrivilegeNames[inner]].path}':{\n\t\trequired: (session) => {\n\t\t\treturn cp(session, '${innerPrivilegeNames[inner]}', ["view"])\n\t\t},redirect: "/login.html"\n\t},\n`);
                    }
                }
            }
        }
        policy.push('}')
        fs.writeFile('.gen/policy.js', policy.join(''), function (err) {
            if (err) {
                return console.log(err);
            }
        });*/
		client.close();
	});
}

processData();


