/* eslint-disable no-console */
/* eslint-disable no-unused-vars */
const fs = require("fs");
const path = require("path");
const MongoClient = require("mongodb").MongoClient;
const ObjectID = require("mongodb").ObjectID;
const companyId="5aa290cc2600a8730fdc5df5";
const adminId = "5aa290cc2600a8730fdc5df6";

const masterPrivileges = {
	"user_management": {
		"display": "User Management",
		"page": "userManagement",
		"path": "/user-management.html",
		"access": [
			"view",
			"create",
			"update",
		],
		"childNodes": null,
	},
	"company_management": {
		"display": "Company Management",
		"page": "companyManagement",
		"path": "/company-management.html",
		"access": [
			"view",
			"update",
		],
		"childNodes": null,
	},
	"master_management": {
		"display": "Master Management",
		"access": [
			"view",
		],
		"childNodes": {
			"accounting_year": {
				"display": "Accounting Year",
				"page": "accountingYear",
				"path": "/masters/accounting-year.html",
				"access": [
					"view",
					"create",
					"update",
				],
				"childNodes": null,
			},
			"account_group": {
				"display": "Account group",
				"page": "accountGroup",
				"path": "/masters/account-group.html",
				"access": [
					"view",
					"create",
					"update",
				],
				"childNodes": null,
			},
			"account": {
				"display": "Account",
				"page": "account",
				"path": "/masters/account.html",
				"access": [
					"view",
					"create",
					"update",
				],
				"childNodes": null,
			},
			"cost_center": {
				"display": "Cost Center",
				"page": "costCenter",
				"path": "/masters/cost-center.html",
				"access": [
					"view",
					"create",
					"update",
				],
				"childNodes": null,
			},
			"itds": {
				"display": "ITDS",
				"page": "itds",
				"path": "/masters/itds.html",
				"access": [
					"view",
					"create",
					"update",
				],
				"childNodes": null,
			},
			"store_group": {
				"display": "Store Group",
				"page": "storeGroup",
				"path": "/masters/store-group.html",
				"access": [
					"view",
					"create",
					"update",
				],
				"childNodes": null,
			},
			"item": {
				"display": "Item",
				"page": "item",
				"path": "/masters/item.html",
				"access": [
					"view",
					"create",
					"update",
				],
				"childNodes": null,
			},
			"voucher": {
				"display": "Voucher",
				"page": "voucher",
				"path": "/masters/voucher.html",
				"access": [
					"view",
					"create",
					"update",
				],
				"childNodes": null,
			},
			"factory_master": {
				"display": "Factory",
				"page": "factory",
				"path": "/masters/factory.html",
				"access": [
					"view",
					"create",
					"update",
				],
				"childNodes": null,
			},
			"doc_type_master": {
				"display": "Document Type",
				"page": "docType",
				"path": "/masters/doc-type.html",
				"access": [
					"view",
					"create",
					"update",
				],
				"childNodes": null,
			},
			"holiday_master": {
				"display": "Holiday",
				"page": "holiday",
				"path": "/masters/holiday.html",
				"access": [
					"view",
					"create",
					"update",
				],
				"childNodes": null,
			},
			"employee_type_master": {
				"display": "Employee Type",
				"page": "employeeType",
				"path": "/masters/employee-type.html",
				"access": [
					"view",
					"create",
					"update",
				],
				"childNodes": null,
			},
			"department_master": {
				"display": "Department",
				"page": "department",
				"path": "/masters/department.html",
				"access": [
					"view",
					"create",
					"update",
				],
				"childNodes": null,
			},
			"process_master": {
				"display": "Process",
				"page": "process",
				"path": "/masters/process.html",
				"access": [
					"view",
					"create",
					"update",
				],
				"childNodes": null,
			},
			"process_dept_master": {
				"display": "Process Department",
				"page": "processDepartment",
				"path": "/masters/process-department.html",
				"access": [
					"view",
					"create",
					"update",
				],
				"childNodes": null,
			},
			"workforce_master": {
				"display": "Workforce",
				"page": "workforce",
				"path": "/masters/workforce.html",
				"access": [
					"view",
					"create",
					"update",
				],
				"childNodes": null,
			},
			"mark_master": {
				"display": "Mark",
				"page": "mark",
				"path": "/masters/mark.html",
				"access": [
					"view",
					"create",
					"update",
				],
				"childNodes": null,
			},
			"season_master": {
				"display": "Season",
				"page": "season",
				"path": "/masters/season.html",
				"access": [
					"view",
					"create",
					"update",
				],
				"childNodes": null,
			},
			"sale_type_master": {
				"display": "Sale Type",
				"page": "saleType",
				"path": "/masters/sale-type.html",
				"access": [
					"view",
					"create",
					"update",
				],
				"childNodes": null,
			},
			"sampling_rule_master": {
				"display": "Sampling Rule",
				"page": "samplingRule",
				"path": "/masters/sampling-rule.html",
				"access": [
					"view",
					"create",
					"update",
				],
				"childNodes": null,
			},
			"category_master": {
				"display": "Category",
				"page": "category",
				"path": "/masters/category.html",
				"access": [
					"view",
					"create",
					"update",
				],
				"childNodes": null,
			},
			"packing_master": {
				"display": "Packing",
				"page": "packing",
				"path": "/masters/packing.html",
				"access": [
					"view",
					"create",
					"update",
				],
				"childNodes": null,
			},
			"grade_master": {
				"display": "Grade",
				"page": "grade",
				"path": "/masters/grade.html",
				"access": [
					"view",
					"create",
					"update",
				],
				"childNodes": null,
			},
			"energy_source_master": {
				"display": "Energy Source",
				"page": "energySource",
				"path": "/masters/energy-source.html",
				"access": [
					"view",
					"create",
					"update",
				],
				"childNodes": null,
			},
			"electricity_meter_master": {
				"display": "Eectricity Meter",
				"page": "electricityMeter",
				"path": "/masters/electricity-meter.html",
				"access": [
					"view",
					"create",
					"update",
				],
				"childNodes": null,
			},
			"genset_master": {
				"display": "Genset",
				"page": "genset",
				"path": "/masters/genset.html",
				"access": [
					"view",
					"create",
					"update",
				],
				"childNodes": null,
			},
			"heater_master": {
				"display": "Heater",
				"page": "heater",
				"path": "/masters/heater.html",
				"access": [
					"view",
					"create",
					"update",
				],
				"childNodes": null,
			},
			"process_machine_master": {
				"display": "Machine",
				"page": "processMachine",
				"path": "/masters/process-machine.html",
				"access": [
					"view",
					"create",
					"update",
				],
				"childNodes": null,
			},
			"process_param_freq_master": {
				"display": "Process Param Freq",
				"page": "processParamFreq",
				"path": "/masters/process-param-frequency.html",
				"access": [
					"view",
					"create",
					"update",
				],
				"childNodes": null,
			},
			"process_param_master": {
				"display": "Process Param",
				"page": "processParam",
				"path": "/masters/process-param.html",
				"access": [
					"view",
					"create",
					"update",
				],
				"childNodes": null,
			},
			"periodic_maint_param_master": {
				"display": "Periodic Maint Param",
				"page": "periodicMaintParam",
				"path": "/masters/periodic-maint-param.html",
				"access": [
					"view",
					"create",
					"update",
				],
				"childNodes": null,
			},
			"party_master": {
				"display": "Party",
				"page": "party",
				"path": "/masters/party.html",
				"access": [
					"view",
					"create",
					"update",
				],
				"childNodes": null,
			},
			"leaf_type_master": {
				"display": "Leaf Type",
				"page": "leafType",
				"path": "/masters/leaf-type.html",
				"access": [
					"view",
					"create",
					"update",
				],
				"childNodes": null,
			},
			"leaf_count_master": {
				"display": "Leaf Count",
				"page": "leafCount",
				"path": "/masters/leaf-count.html",
				"access": [
					"view",
					"create",
					"update",
				],
				"childNodes": null,
			},
			"gl_price_master": {
				"display": "GL Price",
				"page": "glPrice",
				"path": "/masters/gl-price.html",
				"access": [
					"view",
					"create",
					"update",
				],
				"childNodes": null,
			},
			"prod_type_master": {
				"display": "Production Type",
				"page": "productionType",
				"path": "/masters/production-type.html",
				"access": [
					"view",
					"create",
					"update",
				],
				"childNodes": null,
			},
			"auction_sampling_rule": {
				"display": "Auction Sampling Rule",
				"page": "auctionSamplingRule",
				"path": "/masters/auction-sampling-rule.html",
				"access": [
					"view",
					"create",
					"update",
				],
				"childNodes": null,
			},
			"sale_timings": {
				"display": "Sale Timings",
				"page": "saleTimings",
				"path": "/masters/sale-timings.html",
				"access": [
					"view",
					"create",
					"update",
				],
				"childNodes": null,
			},
		},
	},
	"transaction_management": {
		"display": "Transactions",
		"access": [
			"view",
		],
		"childNodes": {
			"fact_running": {
				"display": "Factory Running",
				"page": "factRunning",
				"path": "/transaction/factory-running.html",
				"access": [
					"view",
					"create",
					"update",
				],
				"childNodes": null,
			},
			"gl_receipt": {
				"display": "GL Receipt",
				"page": "glReceipt",
				"path": "/transaction/gl-receipt.html",
				"access": [
					"view",
					"create",
					"update",
				],
				"childNodes": null,
			},
			"fine_lf_cnt_receipt": {
				"display": "Fine Lf Count Receipt",
				"page": "fineLfCntReceipt",
				"path": "/transaction/fine-lf-count-receipt.html",
				"access": [
					"view",
					"create",
					"update",
				],
				"childNodes": null,
			},
			"weather": {
				"display": "Weather",
				"page": "weather",
				"path": "/transaction/weather.html",
				"access": [
					"view",
					"create",
					"update",
				],
				"childNodes": null,
			},
			"production": {
				"display": "Production",
				"page": "production",
				"path": "/transaction/production.html",
				"access": [
					"view",
					"create",
					"update",
				],
				"childNodes": null,
			},
			"mach_running": {
				"display": "Machine Running",
				"page": "machRunning",
				"path": "/transaction/machine-running.html",
				"access": [
					"view",
					"create",
					"update",
				],
				"childNodes": null,
			},
			"elec_meter_reading": {
				"display": "Electricity Meter Reading",
				"page": "elecMeterReading",
				"path": "/transaction/electricity-meter-reading.html",
				"access": [
					"view",
					"create",
					"update",
				],
				"childNodes": null,
			},
			"process_param_running": {
				"display": "Process Param Running",
				"page": "processParamRunning",
				"path": "/transaction/process-param-running.html",
				"access": [
					"view",
					"create",
					"update",
				],
				"childNodes": null,
			},
			"periodic_maint_done": {
				"display": "Periodic Maintenance Done",
				"page": "periodicMaintDone",
				"path": "/transaction/periodic-maintenance-done.html",
				"access": [
					"view",
					"create",
					"update",
				],
				"childNodes": null,
			},
			"packing_invoice": {
				"display": "Grade Packing",
				"page": "packingInvoice",
				"path": "/transaction/grade-packing.html",
				"access": [
					"view",
					"create",
					"update",
				],
				"childNodes": null,
			},
			"sampling": {
				"display": "Sampling",
				"page": "sampling",
				"path": "/transaction/sampling.html",
				"access": [
					"view",
					"create",
					"update",
				],
				"childNodes": null,
			},
			"dps_invoice": {
				"display": "DPS Invoice",
				"page": "dpsInvoice",
				"path": "/transaction/dps-invoice.html",
				"access": [
					"view",
					"create",
					"update",
				],
				"childNodes": null,
			},
			"tw_invoice": {
				"display": "Tea Waste Packing",
				"page": "twInvoice",
				"path": "/transaction/tw-packing.html",
				"access": [
					"view",
					"create",
					"update",
				],
				"childNodes": null,
			},
			"label_printing": {
				"display": "Label Printing",
				"page": "labelPrinting",
				"path": "/transaction/label-printing.html",
				"access": [
					"view",
					"create",
					"update",
				],
				"childNodes": null,
			},
			"tasting": {
				"display": "Tasting",
				"page": "tasting",
				"path": "/transaction/tasting.html",
				"access": [
					"view",
					"create",
					"update",
				],
				"childNodes": null,
			},
			"despatch": {
				"display": "Despatch",
				"page": "despatch",
				"path": "/transaction/despatch.html",
				"access": [
					"view",
					"create",
					"update",
				],
				"childNodes": null,
			},
			"split_invoice": {
				"display": "Split Invoice",
				"page": "splitInvoice",
				"path": "/transaction/split-invoice.html",
				"access": [
					"view",
					"create",
					"update",
				],
				"childNodes": null,
			},
			"heater_running": {
				"display": "Heater Running",
				"page": "heaterRunning",
				"path": "/transaction/heater-running.html",
				"access": [
					"view",
					"create",
					"update",
				],
				"childNodes": null,
			},
			"genset_running": {
				"display": "Genset Running",
				"page": "gensetRunning",
				"path": "/transaction/genset-running.html",
				"access": [
					"view",
					"create",
					"update",
				],
				"childNodes": null,
			},
			"employees_worked": {
				"display": "Employees Worked",
				"page": "employeesWorked",
				"path": "/transaction/employees-worked.html",
				"access": [
					"view",
					"create",
					"update",
				],
				"childNodes": null,
			},
			"warehouse_arrival": {
				"display": "Warehouse Arrival",
				"page": "warehouseArrival",
				"path": "/transaction/warehouse-arrival.html",
				"access": [
					"view",
					"create",
					"update",
				],
				"childNodes": null,
			},
			"printing_position": {
				"display": "Printing Position",
				"page": "printingPosition",
				"path": "/transaction/printing-position.html",
				"access": [
					"view",
					"create",
					"update",
				],
				"childNodes": null,
			},
			"sale_price": {
				"display": "Auction Sale Price",
				"page": "salePrice",
				"path": "/transaction/sale-price.html",
				"access": [
					"view",
					"create",
					"update",
				],
				"childNodes": null,
			},
			"pvt_sale": {
				"display": "Private Sale",
				"page": "privateSale",
				"path": "/transaction/private-sale.html",
				"access": [
					"view",
					"create",
					"update",
				],
				"childNodes": null,
			},
			"invoice_list": {
				"display": "Invoices",
				"page": "invoices",
				"path": "/transaction/invoice-list.html",
				"access": [
					"view",
					"create",
					"update",
				],
				"childNodes": null,
			},
			"purchase_order": {
				"display": "Purchase Order",
				"page": "purchaseOrder",
				"path": "/transaction/purchase-order.html",
				"access": [
					"view",
					"create",
					"update",
					"approve",
				],
				"childNodes": null,
			},
		},
	},
	"reports": {
		"display": "Reports",
		"access": [
			"view",
		],
		"childNodes": {
			"weekely_leaf_purchased": {
				"display": "Weekly Leaf Purchased",
				"page": "weeklyLeafPurchased",
				"path": "/reports/weekly-leaf-purchased.html",
				"access": [
					"view",
				],
				"childNodes": null,
			},
			"grade_percentage": {
				"display": "Grade Percentage",
				"page": "gradePercentage",
				"path": "/reports/grade-percentage.html",
				"access": [
					"view",
				],
				"childNodes": null,
			},
			"factory_daily_report": {
				"display": "Factory Daily Report",
				"page": "factoryDailyReport",
				"path": "/reports/factory-daily-report.html",
				"access": [
					"view",
				],
				"childNodes": null,
			},
			"rg1_report": {
				"display": "RG1 Report",
				"page": "rg1Report",
				"path": "/reports/rg1-report.html",
				"access": [
					"view",
				],
				"childNodes": null,
			},
			"grade_mean_price": {
				"display": "Sales Grade Average",
				"page": "gradeMeanPrice",
				"path": "/reports/grade-mean-price.html",
				"access": [
					"view",
					"create",
					"update",
				],
				"childNodes": null,
			},
			"markwise_sale_price": {
				"display": "Markwise Sale Price",
				"page": "markwiseSalePrice",
				"path": "/reports/markwise-sale-price.html",
				"access": [
					"view",
					"create",
					"update",
				],
				"childNodes": null,
			},
		},
	},
	"current_date": {
		"display": "Current Date",
		"page": "",
		"path": "",
		"access": [
			"update",
		],
		"childNodes": null,
	},
};

async function processData() {
	const url = "mongodb://localhost:27017";
	const dbName = "teaerp";
	const now = new Date();
	MongoClient.connect(url, async function(err, client) {
		const db = client.db(dbName);
		await db.collection("user").findOneAndUpdate({_id: adminId}, {$set: {privileges: masterPrivileges, updatedAt: now}});
		const company = await db.collection("company").findOne({_id: companyId});
		company.userRoles[0].privileges = masterPrivileges;
		await db.collection("company").findOneAndUpdate({_id: companyId}, {$set: {masterPrivileges: masterPrivileges, userRoles: company.userRoles, updatedAt: now}});
		client.close();
	});
}

processData();


