const bcrypt = require('bcrypt');
const saltRounds = 10;
const myPlaintextPassword = '123456';

async function test() {
let now = new Date().getTime();
 const hash = await bcrypt.hash(myPlaintextPassword, saltRounds);
 console.log(hash, (new Date().getTime() - now));
 now = new Date().getTime();
 const match = await bcrypt.compare(myPlaintextPassword+" ", hash);
 console.log(match, (new Date().getTime() - now));
 };

test();
