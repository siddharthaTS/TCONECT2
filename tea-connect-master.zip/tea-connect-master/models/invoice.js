module.exports = (ctx) => {
	return {
		getIds: async (docs, keys) => {
			try {
				const query = {};
				/* if (companyId) {
					query.companyId = ctx.ObjectID(companyId);
				} */
				query.key = {$in: keys};
				const invoices = await ctx.mongo.collection("invoices").find(query, {projection: {key: 1}}).toArray();
				const _map = {};
				for (let loop=0, length=invoices.length; loop<length; loop++) {
					_map[invoices[loop].key] = invoices[loop]._id;
				}
				let insertRequired = false;
				// const _ids = [];
				const bulk = ctx.mongo.collection("invoices").initializeUnorderedBulkOp();
				for (let loop=0, length=docs.length; loop<length; loop++) {
					const key = docs[loop].key;
					if (_map[key]) {
						docs[loop]._id = _map[key];
						insertRequired = true;
						// _ids.push(_map[key]);
						const updateObj = {
							season: docs[loop].season,
							gradeId: ctx.ObjectID(docs[loop].gradeId),
							noOfPkg: docs[loop].noOfPkg,
							// mfgDate: docs[loop].mfgDate,
						};
						if (docs[loop].mfgDate) {
							updateObj.mfgDate = docs[loop].mfgDate;
						}
						if (docs[loop].netPerPkg) {
							updateObj.netPerPkg = docs[loop].netPerPkg;
						}
						if (docs[loop].price) {
							updateObj.price = docs[loop].price;
							if (docs[loop].buyer) {
								updateObj.buyer = docs[loop].buyer;
							}
							if (docs[loop].avlKg) {
								updateObj.avlKg = docs[loop].avlKg;
							}
						}
						bulk.find({_id: docs[loop]._id}).updateOne({$set: updateObj});
					} else {
						insertRequired = true;
						docs[loop]._id = new ctx.ObjectID();
						// docs[loop].companyId = ctx.ObjectID(docs[loop].companyId);
						// docs[loop].markId = ctx.ObjectID(docs[loop].markId);
						// docs[loop].gradeId = ctx.ObjectID(docs[loop].gradeId);
						const insertObj = {
							_id: docs[loop]._id,
							// companyId: ctx.ObjectID(docs[loop].companyId),
							season: docs[loop].season,
							invNo: docs[loop].invNo,
							_invNo: docs[loop]._invNo,
							markId: ctx.ObjectID(docs[loop].markId),
							gradeId: ctx.ObjectID(docs[loop].gradeId),
							noOfPkg: docs[loop].noOfPkg,
							// mfgDate: docs[loop].mfgDate,
						};
						if (docs[loop].mfgDate) {
							insertObj.mfgDate = docs[loop].mfgDate;
						}
						if (docs[loop].netPerPkg) {
							insertObj.netPerPkg = docs[loop].netPerPkg;
						}
						insertObj.key = docs[loop].key;
						// _ids.push(docs[loop]._id);
						bulk.insert(insertObj);
					}
				}
				if (insertRequired) {
					await bulk.execute();
				}
				return {status: true, msg: "OK", docs: docs};
			} catch (err) {
				return {status: false, msg: "encountered an unexpected error."};
			}
		},
		serialize: (docs) => {
			try {
				for (let loop=0, length=docs.length; loop<length; loop++) {
					if (docs[loop]["mfgDate"]) {
						docs[loop]["mfgDate"] = docs[loop]["mfgDate"].getTime();
					}
					if (docs[loop]["createdAt"]) {
						docs[loop]["createdAt"] = docs[loop]["createdAt"].getTime();
					}
					if (docs[loop]["updatedAt"]) {
						docs[loop]["updatedAt"] = docs[loop]["updatedAt"].getTime();
					}
				}
				return {status: true, msg: "Ok", docs: docs};
			} catch (err) {
				return {status: false, msg: "encountered an unexpected error."};
			}
		},
		deserialize: (docs) => {
			try {
				for (let loop=0, length=docs.length; loop<length; loop++) {
					if (docs[loop]["mfgDate"]) {
						docs[loop]["mfgDate"] = new Date(docs[loop]["mfgDate"]);
					}
					if (docs[loop]["createdAt"]) {
						docs[loop]["createdAt"] = new Date(docs[loop]["createdAt"]);
					}
					if (docs[loop]["updatedAt"]) {
						docs[loop]["updatedAt"] = new Date(docs[loop]["updatedAt"]);
					}
				}
				return {status: true, msg: "Ok", docs: docs};
			} catch (err) {
				return {status: false, msg: "encountered an unexpected error."};
			}
		},
	};
};
