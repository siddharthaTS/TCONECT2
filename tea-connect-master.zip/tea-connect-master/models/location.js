module.exports = (ctx) => {
	return {
		attributes: {
			name: {
				type: "STRING",
				min: 4,
				max: 80,
				transform: "UPPERCASE",
			},
			code: {
				type: "STRING",
				min: 1,
				max: 10,
				transform: "UPPERCASE",
			},
		},
		metadata: {
			name: "location",
			plural: "locations",
			collection: "location",
		},
		create: async (input) => {
			try {
				if (!input._id) {
					input._id = new ctx.ObjectID();
				}
				await ctx.mongo.collection("location").insertOne(input);
				return {status: true, msg: "location created", doc: input};
			} catch (err) {
				let errMsg = "Encountered an unexpected error.";
				const indexes = ["name_1", "code_1"];
				const messages = ["Name already in use", "Code already in use."];
				if (err.errmsg) {
					for (let innerLoop = 0, innerLength = indexes.length; innerLoop < innerLength; innerLoop++) {
						if (err.errmsg.indexOf(indexes[innerLoop]) >= 0) {
							errMsg = messages[innerLoop];
							break;
						}
					}
				}
				return {status: false, msg: errMsg};
			}
		},
		update: async (id, values, projection) => {
			try {
				if (!projection) {
					projection={
						name: 1,
						code: 1,
						isActive: 1,
					};
				}
				const updateObj = {$set: values};
				const result = await ctx.mongo.collection("location").findOneAndUpdate({
					_id: ctx.ObjectID(id),
				}, updateObj, {
					returnOriginal: false, projection: projection,
				});
				return {status: true, msg: "location updated", doc: result.value};
			} catch (err) {
				let errMsg = "Encountered an unexpected error.";
				const indexes = ["name_1", "code_1"];
				const messages = ["Name already in use", "Code already in use."];
				if (err.errmsg) {
					for (let innerLoop = 0, innerLength = indexes.length; innerLoop < innerLength; innerLoop++) {
						if (err.errmsg.indexOf(indexes[innerLoop]) >= 0) {
							errMsg = messages[innerLoop];
							break;
						}
					}
				}
				return {status: false, msg: errMsg};
			}
		},
		bulkCreate: async (docs) => {
			try {
				const bulk = ctx.mongo.collection("location").initializeUnorderedBulkOp();
				const indexes = [];
				const messages = [];
				const outcome = [];
				let writeErrors = [];
				for (var loop = 0; loop < docs.length; loop++) {
					outcome.push("Record inserted successfully.");
					if (docs[loop].companyId) {
						docs[loop].companyId = ctx.ObjectID(docs[loop].companyId);
					}
					if (docs[loop].createdBy) {
						docs[loop].createdBy = ctx.ObjectID(docs[loop].createdBy);
					}
					if (docs[loop].updatedBy) {
						docs[loop].updatedBy = ctx.ObjectID(docs[loop].updatedBy);
					}
					bulk.insert(docs[loop]);
				}
				try {
					const result = await bulk.execute();
					writeErrors = result.getWriteErrors();
				} catch (err) {
					writeErrors = err.result.getWriteErrors();
				}
				if (writeErrors.length == 0) {
					return {status: true, msg: "OK", result: {outcome: outcome, successCount: outcome.length}};
				}
				const innerLength = indexes.length;
				for (let loop = 0, length = writeErrors.length; loop < length; loop++) {
					let matchFound = false;
					for (let innerLoop = 0; innerLoop < innerLength; innerLoop++) {
						if (writeErrors[loop].errmsg.indexOf(indexes[innerLoop]) >= 0) {
							outcome[writeErrors[loop].index] = messages[innerLoop];
							matchFound = true;
							break;
						}
					}
					if (!matchFound) {
						outcome[writeErrors[loop].index] = "Record not inserted.";
					}
				}
				return {status: true, msg: "OK", result: {outcome: outcome, successCount: (outcome.length - writeErrors.length)}};
			} catch (err) {
				return {status: false, msg: "encountered an unexpected error."};
			}
		},
		list: async (query, projection) => {
			try {
				if (!projection) {
					projection={
						name: 1,
						code: 1,
						isActive: 1,
					};
				}
				const docs = await ctx.mongo.collection("location").find(query, {projection: projection}).toArray();
				return {status: true, msg: "Ok", docs: docs};
			} catch (err) {
				return {status: false, msg: "encountered an unexpected error."};
			}
		},
		listWithCategory: async () => {
			try {
				const docs = await ctx.mongo.collection("location").aggregate([
					{$project: {name: 1, code: 1}},
					{$group: {_id: null, locations: {$push: "$$ROOT"}}},
					{$lookup: {from: "category", pipeline: [{$project: {name: 1, code: 1}}], as: "categories"}},
				]).toArray();
				if (docs.length!=1) {
					return {status: true, msg: "Ok", doc: {categories: [], locations: []}};
				} else {
					return {status: true, msg: "Ok", doc: docs[0]};
				}
			} catch (err) {
				return {status: false, msg: "encountered an unexpected error."};
			}
		},
		details: async (query, projection) => {
			try {
				if (!projection) {
					projection={
						name: 1,
						code: 1,
						isActive: 1,
					};
				}
				const doc = await ctx.mongo.collection("location").findOne(query, {projection: projection});
				return {status: true, msg: "Ok", doc: doc};
			} catch (err) {
				return {status: false, msg: "encountered an unexpected error."};
			}
		},
		serialize: (docs) => {
			try {
				for (let loop=0, length=docs.length; loop<length; loop++) {
					if (docs[loop]["createdAt"]) {
						docs[loop]["createdAt"] = docs[loop]["createdAt"].getTime();
					}
					if (docs[loop]["updatedAt"]) {
						docs[loop]["updatedAt"] = docs[loop]["updatedAt"].getTime();
					}
				}
				return {status: true, msg: "Ok", docs: docs};
			} catch (err) {
				return {status: false, msg: "encountered an unexpected error."};
			}
		},
		deserialize: (docs) => {
			try {
				for (let loop=0, length=docs.length; loop<length; loop++) {
					if (docs[loop]["createdAt"]) {
						docs[loop]["createdAt"] = new Date(docs[loop]["createdAt"]);
					}
					if (docs[loop]["updatedAt"]) {
						docs[loop]["updatedAt"] = new Date(docs[loop]["updatedAt"]);
					}
				}
				return {status: true, msg: "Ok", docs: docs};
			} catch (err) {
				return {status: false, msg: "encountered an unexpected error."};
			}
		},
	};
};
