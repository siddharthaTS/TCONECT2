module.exports = (ctx) => {
	return {
		update: async (input) => {
			const now = new Date();
			let updatedStatus = "TASTED";
			try {
				if (!input._id) {
					input._id = new ctx.ObjectID();
				} else {
					input._id = ctx.ObjectID(input._id);
				}
				if (input.companyId) {
					input.companyId = ctx.ObjectID(input.companyId);
				}
				if (input.tastingCompany) {
					input.tastingCompany = ctx.ObjectID(input.tastingCompany);
				}
				if (input.createdBy) {
					input.createdBy = ctx.ObjectID(input.createdBy);
				}
				if (input.updatedBy) {
					input.updatedBy = ctx.ObjectID(input.updatedBy);
				}
				if (input.musterIds) {
					for (let loop = 0; loop < input.musterIds.length; loop++) {
						input.musterIds[loop] = ctx.ObjectID(input.musterIds[loop]);
					}
					const _muster = await ctx.mongo.collection("muster").aggregate([
						{$match: {_id: input.musterIds[0]}},
						{$project: {_id: "$markId"}},
						{$lookup: {from: "mark", let: {mark_id: "$_id"}, pipeline: [
							{$match: {$expr: {$eq: ["$_id", "$$mark_id"]}}},
							{$project: {category: 1}},
						], as: "category"}},
						{$addFields: {category: {$arrayElemAt: ["$category.category", 0]}}},
					]).toArray();
					if (_muster.length != 1) {
						throw {};
					}
					input.markId = _muster[0]._id;
					input.categoryId = _muster[0].category;
					ctx.mongo.collection("muster").updateMany({_id: {$in: input.musterIds}}, {$set: {status: "TASTED", tastedAt: now}});
				} else if (input.auctionId) {
					input.auctionId = ctx.ObjectID(input.auctionId);
					const _docs = await ctx.mongo.collection("auction").aggregate([
						{$match: {_id: input.auctionId}},
						{$project: {auctionCenter: 1, saleNum: 1, count: {$size: "$invoices"}}},
					]).toArray();
					if (_docs.length != 1) {
						throw {};
					}
					const prev = await ctx.mongo.collection("tastingreport").findOne({auctionId: input.auctionId}, {projection: {invoices: 1}});
					if (prev) {
						input._id = prev._id;
						const prevInvoices = prev.invoices;
						const prevMap = {};
						const updatedInvoices = [];
						for (let loop=0, length = prevInvoices.length; loop<length; loop++) {
							prevInvoices[loop].id = prevInvoices[loop].id.toHexString();
							prevMap[prevInvoices[loop].id] = loop;
							updatedInvoices.push(prevInvoices[loop]);
						}
						for (let loop = 0; loop < input.invoices.length; loop++) {
							const _pos = prevMap[input.invoices[loop].id];
							if (_pos != null) {
								updatedInvoices[_pos] = input.invoices[loop];
							} else {
								updatedInvoices.push(input.invoices[loop]);
							}
						}
						const _ = require("lodash");
						input.invoices = _.sortBy(updatedInvoices, ["lotNum"]);
					}
					if (_docs[0].count != input.invoices.length) {
						updatedStatus = "PENDING";
					}
					ctx.mongo.collection("auction").updateOne({_id: input.auctionId}, {$set: {status: updatedStatus, tastedAt: now}});
					input.saleNum = _docs[0].saleNum;
					input.auctionCenter = _docs[0].auctionCenter;
				}
				for (let loop = 0; loop < input.invoices.length; loop++) {
					if (input.invoices[loop].id) {
						input.invoices[loop].id = ctx.ObjectID(input.invoices[loop].id);
					}
				}
				input.updatedAt = now;
				const updateObj = {$set: input};
				const result = await ctx.mongo.collection("tastingreport").findOneAndUpdate({_id: input._id}, updateObj, {
					upsert: true,
					returnOriginal: false,
					projection: {
						date: 1,
						// docNum: 1,
						invoices: 1,
						summary: 1,
					},
				});
				return {status: true, msg: "Ok", doc: result.value};
			} catch (err) {
				return {status: false, msg: "encountered an unexpected error."};
			}
		},
		list: async (query, projection) => {
			if (query.companyId) {
				query.companyId = ctx.ObjectID(query.companyId);
			}
			if (query.locationId) {
				query.locationId = ctx.ObjectID(query.locationId);
			}
			try {
				if (!projection) {
					projection = {
						date: 1,
						docNum: 1,
						invoices: 1,
						summary: 1,
					};
				}
				const docs = await ctx.mongo.collection("tastingreport").find(query, {projection: projection}).sort({docNum: -1}).toArray();
				return {status: true, msg: "Ok", docs: docs};
			} catch (err) {
				return {status: false, msg: "encountered an unexpected error."};
			}
		},
		details: async (query, projection) => {
			if (query._id) {
				query._id = ctx.ObjectID(query._id);
			}
			try {
				if (!projection) {
					projection = {
						date: 1,
						type: 1,
						// docNum: 1,
						musterIds: 1,
						auctionId: 1,
						financeId: 1,
						privateSaleId: 1,
						invoices: 1,
						summary: 1,
						version: 1,
						companyId: 1,
						tastingCompany: 1,
						markId: 1,
						categoryId: 1,
						published: 1,
					};
				}
				const doc = await ctx.mongo.collection("tastingreport").findOne(query, {projection: projection});
				return {status: true, msg: "Ok", doc: doc};
			} catch (err) {
				return {status: false, msg: "encountered an unexpected error."};
			}
		},
		printingDetails: async (_id) => {
			try {
				_id = ctx.ObjectID(_id);
				const doc = await ctx.mongo.collection("tastingreport").findOne({_id: _id}, {projection: {companyId: 1, date: 1, docNum: 1, invoices: 1, summary: 1, tastingCompany: 1, location: 1, createdBy: 1, hasPriceIdea: 1, isConsolidated: 1, tastedBy: 1}});
				const sellerId = doc.companyId;
				const companyIds = [];
				if (sellerId) {
					companyIds.push(sellerId);
				}
				const tastingAgency = doc.tastingCompany;
				if (sellerId != tastingAgency) {
					companyIds.push(tastingAgency);
				}
				const docs = await ctx.mongo.collection("seller").find({_id: {$in: companyIds}}, {projection: {name: 1, emailId: 1, address: 1, locations: 1}}).toArray();
				for (let loop=0, length = docs.length; loop<length; loop++) {
					// console.log(docs[loop]._id.toHexString(), sellerId.toHexString())
					if (sellerId) {
						if (docs[loop]._id.toHexString() == sellerId.toHexString()) {
							doc.seller = {_id: docs[loop]._id, name: docs[loop].name, emailId: docs[loop].emailId, address: docs[loop].address?docs[loop].address: "--"};
						}
					}
					/* if (docs[loop]._id == tastingAgency) {
						doc.taster = {_id: docs[loop]._id, name: docs[loop].name, emailId: docs[loop].emailId, address: docs[loop].address?docs[loop].address: "--"};
						if (doc.location && docs[loop].locations) {
							for (let inner=0, innerLength = docs[loop].locations.length; inner<innerLength; inner++) {
								if (docs[loop].locations[inner].name == doc.location) {
									doc.taster.address = docs[loop].locations[inner].address;
								}
							}
						}
					} */
				}
				if ((!doc.seller) || (!doc.seller._id)) {
					doc.seller = {_id: "", name: "", emailId: "", address: ""};
				}
				doc.taster = {_id: ctx.ObjectID(global.hostCompanyId), name: global.hostCompanyName, emailId: global.hostCompanyEmail, address: global.hostCompanyAddress};
				if (doc.tastedBy) {
					const preparedBy = await ctx.mongo.collection("user").findOne({_id: doc.tastedBy[0]}, {projection: {userName: 1}});
					doc.preparedBy = preparedBy.userName;
				}
				return {status: true, msg: "Ok", doc: doc};
			} catch (err) {
				return {status: false, msg: "encountered an unexpected error."};
			}
		},
		serialize: (docs) => {
			try {
				for (let loop = 0, length = docs.length; loop < length; loop++) {
					if (docs[loop]["date"]) {
						docs[loop]["date"] = docs[loop]["date"].getTime();
					}
					if (docs[loop].createdAt) {
						docs[loop].createdAt = docs[loop].createdAt.getTime();
					}
					if (docs[loop]["updatedAt"]) {
						docs[loop]["updatedAt"] = docs[loop]["updatedAt"].getTime();
					}
				}
				return {status: true, msg: "Ok", docs: docs};
			} catch (err) {
				return {status: false, msg: "encountered an unexpected error."};
			}
		},
		deserialize: (docs) => {
			try {
				for (let loop=0, length=docs.length; loop<length; loop++) {
					if (docs[loop]["date"]) {
						docs[loop]["date"] = new Date(docs[loop]["date"]);
					}
					if (docs[loop].createdAt) {
						docs[loop].createdAt = new Date(docs[loop].createdAt);
					}
					if (docs[loop]["updatedAt"]) {
						docs[loop]["updatedAt"] = new Date(docs[loop]["updatedAt"]);
					}
				}
				return {status: true, msg: "Ok", docs: docs};
			} catch (err) {
				return {status: false, msg: "encountered an unexpected error."};
			}
		},
		tastingParams: async (companyId, invoices) => {
			try {
				const _ = require("lodash");
				const packingIds =[];
				const invoiceNumbers =[];
				const breakNumbers =[];
				const params =[];
				invoices.forEach((element) => {
					packingIds.push(element.packingInvoiceId);
					invoiceNumbers.push(element.invNumber);
					breakNumbers.push(element.breakNumber);
				});
				const docs = await ctx.mongo.collection("tasting").aggregate([
					{$match: {"companyId": companyId, "invoices.packingInvoiceId": {$in: packingIds}, "invoices.invNumber": {$in: invoiceNumbers}, "invoices.breakNumber": {$in: breakNumbers}}},
					{$project: {"date": 1, "invoices.packingInvoiceId": 1, "invoices.invNumber": 1, "invoices.breakNumber": 1, "invoices.la": 1, "invoices.inf": 1, "invoices.liq": 1, "invoices.remarks": 1}},
					{$unwind: "$invoices"},
					{$sort: {date: -1}},
					{$group: {_id: {packingInvoiceId: "$invoices.packingInvoiceId", invNumber: "$invoices.invNumber", breakNumber: "$invoices.breakNumber"}, la: {$first: "$invoices.la"}, inf: {$first: "$invoices.inf"}, liq: {$first: "$invoices.liq"}, remarks: {$first: "$invoices.remarks"}}},
				]).toArray();
				for (let loop=0, length=invoices.length; loop<length; loop++) {
					const temp = _.find(docs, {_id: {packingInvoiceId: invoices[loop].packingInvoiceId, invNumber: invoices[loop].invNumber, breakNumber: invoices[loop].breakNumber}});
					if (!temp) {
						return {status: false, msg: "Tasting records not found for each of the invoices."};
					}
					params.push({la: temp.la, inf: temp.inf, liq: temp.liq, remarks: temp.remarks});
				}
				return {status: true, msg: "Ok", docs: params};
			} catch (err) {
				return {status: false, msg: "encountered an unexpected error."};
			}
		},
		updatePdfPath: async (_id, path) => {
			try {
				_id = ctx.ObjectID(_id);
				const now = new Date();
				await ctx.mongo.collection("tastingreport").findOneAndUpdate({_id: _id}, {$set: {pdfPath: path, updatedAt: now}});
				return {status: true, msg: "Ok"};
			} catch (err) {
				return {status: false, msg: "encountered an unexpected error."};
			}
		},
		updateConsolidated: async (companyId, input) => {
			try {
				if (!input._id) {
					input._id = new ctx.ObjectID().toHexString();
				}
				const now = new Date();
				let samplingUpdateRequired = false;
				const bulk = ctx.mongo.collection("sampling").initializeUnorderedBulkOp();
				const samplingIds = [];
				for (var loop = 0; loop < input.invoices.length; loop++) {
					if (!input.invoices[loop].samplingId) {
						continue;
					}
					if (samplingIds.indexOf(input.invoices[loop].samplingId)<0) {
						samplingIds.push(input.invoices[loop].samplingId);
					}
					samplingUpdateRequired = true;
					bulk.find({
						_id: input.invoices[loop].samplingId,
						// invoices: {$elemMatch: {invNumber: input.invoices[loop].invNumber, breakNumber: input.invoices[loop].breakNumber, markId: input.invoices[loop].markId}},
					}).update({
						$set: {
							"invoices.$[].hasTastingReport": true,
							"invoices.$[].tastingReportId": input._id,
							"updatedAt": now,
							"hasTastingReport": true,
						},
					});
				}
				if (samplingUpdateRequired) {
					await bulk.execute();
				}
				if (!input.docNum) {
					const sequenceModel = require("../models/sequence")(ctx);
					const sequenceResult = await sequenceModel.getNewDocumentNo("TAR", companyId);
					if (!sequenceResult.status) {
						return sequenceResult;
					}
					input.docNum = sequenceResult.documentNo;
				}
				input.updatedAt = now;
				const result = await ctx.mongo.collection("tastingreport").findOneAndUpdate({_id: input._id}, {$set: input}, {
					upsert: true,
					returnOriginal: false,
					projection: {
						date: 1,
						docNum: 1,
						invoices: 1,
						summary: 1,
					},
				});
				return {status: true, msg: "Ok", doc: result.value};
			} catch (err) {
				return {status: false, msg: "encountered an unexpected error."};
			}
		},
		updatePublish: async (_id, userId) => {
			try {
				_id = ctx.ObjectID(_id);
				const report = await ctx.mongo.collection("tastingreport").findOne({_id: _id}, {projection: {published: 1, type: 1, auctionId: 1, musterIds: 1}});
				if (!report) {
					return {status: false, msg: "Invalid report."};
				}
				let published = report.published;
				if (!published) {
					published = true;
				} else {
					published = false;
				}
				const now = new Date();
				if (report.type=="MUSTER") {
					ctx.mongo.collection("muster").updateMany({_id: {$in: report.musterIds}}, {$set: {updatedAt: now, status: published?"PUBLISHED":"TASTED"}});
				} else if (report.type=="AUCTION") {
					ctx.mongo.collection("auction").updateOne({_id: report.auctionId}, {$set: {updatedAt: now, status: published?"PUBLISHED":"TASTED"}});
				}
				await ctx.mongo.collection("tastingreport").findOneAndUpdate({_id: _id}, {$set: {published: published, updatedAt: now}, $addToSet: {tastedBy: ctx.ObjectID(userId)}});
				const service = require("../services/pdfExportService")(ctx);
				service.generateTastingReport(_id);
				return {status: true, msg: "Ok", published: published};
			} catch (err) {
				return {status: false, msg: "encountered an unexpected error."};
			}
		},
		listMerged: async (ids) => {
			try {
				for (let loop=0, length = ids.length; loop<length; loop++) {
					ids[loop] = ctx.ObjectID(ids[loop]);
				}
				const docs = await ctx.mongo.collection("tastingreport").aggregate([
					{$match: {_id: {$in: ids}}},
					{$project: {"updatedBy": 1, "invoices.mfgDate": 1, "invoices.invNo": 1, "invoices.invPrefix": 1, "invoices.grade": 1, "invoices.mark": 1, "invoices.remarks": 1, "invoices.values": 1}},
					{$unwind: "$invoices"},
					{$group: {_id: {mark: "$invoices.mark", invNo: "$invoices.invNo", prefix: "$invoices.invPrefix", grade: "$invoices.grade"}, reports: {$push: {
						pkgDt: "$invoices.mfgDate", remarks: "$invoices.remarks", values: "$invoices.values", taster: "$updatedBy"}}}},
					{$sort: {"_id.mark": 1, "_id.invNo": 1}},
				]).toArray();
				return {status: true, msg: "Ok", docs: docs};
			} catch (err) {
				return {status: false, msg: "encountered an unexpected error."};
			}
		},
		listReportByInvoiceNumber: async (companyId, invNumbers) => {
			try {
				const docs = await ctx.mongo.collection("tastingreport").aggregate([
					{$match: {companyId: companyId}},
					{$unwind: "$invoices"},
					{$match: {"invoices.invNumber": {$in: invNumbers}}},
					{$project: {date: 1, markId: "$invoices.markId", gradeId: "$invoices.gradeId", invNumber: "$invoices.invNumber", remarks: "$invoices.remarks", values: "$invoices.values", priceIdea: "$invoices.priceIdea", tastingCompany: 1}},
					{$sort: {date: 1}},
					{$group: {_id: {invNumber: "$invNumber", markId: "$markId", gradeId: "$gradeId"}, reports: {$push: {date: "$date", company: "$tastingCompany", remarks: "$remarks", values: "$values", priceIdea: "$priceIdea"}}, count: {$sum: 1}}},
				]).toArray();
				return {status: true, msg: "Ok", docs: docs};
			} catch (err) {
				return {status: false, msg: "encountered an unexpected error."};
			}
		},
		spreadSheetDetails: async (_id) => {
			try {
				_id = ctx.ObjectID(_id);
				const doc = await ctx.mongo.collection("tastingreport").findOne({_id: _id}, {projection: {createdAt: 1, updatedBy: 1, tastedBy: 1, invoices: 1}});
				const docs = doc.invoices;
				const invoiceIds = [];
				const invoiceMap = {};
				let user = doc.updatedBy;
				if (doc.tastedBy) {
					user = doc.tastedBy[0];
				}
				for (let loop=0, length = docs.length; loop<length; loop++) {
					if (docs[loop].id) {
						invoiceIds.push(docs[loop].id);
						invoiceMap[docs[loop].id.toHexString()] = loop;
					}
				}
				let marks = [];
				let grades = [];
				let categories = [];
				let invoices = [];
				const meta = await ctx.mongo.collection("invoices").aggregate([
					{$match: {_id: {$in: invoiceIds}}},
					{$group: {_id: null, invoices: {$push: "$$ROOT"}}},
					{$lookup: {from: "mark", pipeline: [{$project: {name: 1, category: 1}}], as: "marks"}},
					{$lookup: {from: "grade", pipeline: [{$project: {code: 1}}], as: "grades"}},
					{$lookup: {from: "category", pipeline: [{$project: {name: 1}}], as: "categories"}},
					{$lookup: {from: "user", pipeline: [{$match: {_id: user}}, {$project: {code: 1}}], as: "users"}},
				]).toArray();
				if (meta.length==1) {
					marks = meta[0].marks;
					grades = meta[0].grades;
					categories = meta[0].categories;
					invoices = meta[0].invoices;
					user = meta[0].users[0].code;
					const markMap = {};
					const gradeMap = {};
					const caregoryMap = {};
					for (let loop=0, length = marks.length; loop<length; loop++) {
						markMap[marks[loop]._id.toHexString()] = loop;
					}
					for (let loop=0, length = grades.length; loop<length; loop++) {
						gradeMap[grades[loop]._id.toHexString()] = loop;
					}
					for (let loop=0, length = categories.length; loop<length; loop++) {
						caregoryMap[categories[loop]._id.toHexString()] = loop;
					}
					const offset = new Date().getTimezoneOffsetMills();
					doc.createdAt = new Date(doc.createdAt.getTime() - offset);
					for (let loop=0, length = invoices.length; loop<length; loop++) {
						const id = invoices[loop]._id.toHexString();
						const pos = invoiceMap[id];
						if (pos==null) {
							continue;
						}
						docs[pos].user = user;
						docs[pos].season = invoices[loop].season;
						docs[pos].tastingDate = doc.createdAt;
						docs[pos].mark = marks[markMap[invoices[loop].markId.toHexString()]].name;
						docs[pos].category = categories[caregoryMap[marks[markMap[invoices[loop].markId.toHexString()]].category.toHexString()]].name;
						docs[pos].grade = grades[gradeMap[invoices[loop].gradeId.toHexString()]].code;
						docs[pos].noOfPkg = invoices[loop].noOfPkg;
						if (invoices[loop].netPerPkg) {
							docs[pos].totalKgs = invoices[loop].noOfPkg * invoices[loop].netPerPkg;
						}
						if (docs[pos].mfgDate) {
							docs[pos].mfgDate = new Date(docs[pos].mfgDate - offset);
						}
					}
				}
				return {status: true, msg: "Ok", docs: docs};
			} catch (err) {
				return {status: false, msg: "encountered an unexpected error."};
			}
		},
	};
};
