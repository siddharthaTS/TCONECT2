module.exports = (ctx) => {
	return {
		update: async (input) => {
			try {
				if (!input._id) {
					input._id = new ctx.ObjectID();
				} else {
					input._id = ctx.ObjectID(input._id);
				}
				if (input.auctionCenter) {
					input.auctionCenter = ctx.ObjectID(input.auctionCenter);
				}
				if (input.createdBy) {
					input.createdBy = ctx.ObjectID(input.createdBy);
				}
				if (input.updatedBy) {
					input.updatedBy = ctx.ObjectID(input.updatedBy);
				}
				await ctx.mongo.collection("auction").findOneAndUpdate({_id: input._id}, {$set: input}, {upsert: true});
				delete input.companyId;
				// delete input.createdAt;
				delete input.updatedAt;
				delete input.createdBy;
				delete input.updatedBy;
				// delete input.invoices;
				return {status: true, msg: "Ok", doc: input};
			} catch (err) {
				const errMsg = "Encountered an unexpected error.";
				return {status: false, msg: errMsg};
			}
		},
		details: async (input) => {
			try {
				if (input._id) {
					input._id = ctx.ObjectID(input._id);
				}
				if (input.auctionCenter) {
					input.auctionCenter = ctx.ObjectID(input.auctionCenter);
				}
				const docs = await ctx.mongo.collection("auction").aggregate([
					{$match: input},
					{$project: {"auctionCenter": 1, "saleNum": 1, "season": 1, "invoices": 1, "status": 1}},
					{$unwind: "$invoices"},
					{$group: {_id: "$_id", auctionCenter: {$first: "$auctionCenter"}, saleNum: {$first: "$saleNum"}, season: {$first: "$season"}, status: {$first: "$status"}, ids: {$push: "$invoices.id"}, invoices: {$push: "$$ROOT.invoices"}}},
					{$lookup: {from: "invoices", let: {invoices: "$ids"}, pipeline: [{
						$match: {$expr: {$in: ["$_id", "$$invoices"]}}}, {
						$project: {markId: 1, gradeId: 1, noOfPkg: 1, season: 1, invNo: 1, netPerPkg: 1}}], as: "invoices2"}},
				]).toArray();
				const valueMap = {};
				if (input._id) {
					const report = await ctx.mongo.collection("tastingreport").findOne({auctionId: input._id}, {projection: {"invoices.id": 1, "invoices.priceIdea": 1}});
					if (report && report.invoices) {
						const invoices = report.invoices;
						for (let loop = 0, length = invoices.length; loop<length; loop++) {
							valueMap[invoices[loop].id.toHexString()] = invoices[loop].priceIdea;
						}
					}
				}
				if (docs.length != 1) {
					return {status: false, msg: "Record not found", doc: null};
				}
				const doc = docs[0];
				const invoiceMap = {};
				for (let loop=0, length = doc.invoices2.length; loop <length; loop++) {
					invoiceMap[doc.invoices2[loop]._id.toHexString()] = doc.invoices2[loop];
				}
				for (let loop=0, length = doc.invoices.length; loop <length; loop++) {
					const id = doc.invoices[loop].id.toHexString();
					const ref = invoiceMap[id];
					if (ref) {
						doc.invoices[loop].invNo = ref.invNo;
						doc.invoices[loop].season = ref.season;
						doc.invoices[loop].markId = ref.markId;
						doc.invoices[loop].gradeId = ref.gradeId;
						doc.invoices[loop].noOfPkg = ref.noOfPkg;
						if (ref.netPerPkg) {
							doc.invoices[loop].netPerPkg = ref.netPerPkg;
						}
					}
					const priceIdea = valueMap[id];
					if (priceIdea) {
						doc.invoices[loop].priceIdea = priceIdea;
					}
				}
				delete doc.ids;
				delete doc.invoices2;
				const _ = require("lodash");
				doc.invoices = _.sortBy(doc.invoices, ["lotNum"]);
				return {status: true, msg: "Ok", doc: doc};
			} catch (err) {
				const errMsg = "Encountered an unexpected error.";
				return {status: false, msg: errMsg};
			}
		},
		updateAssignment: async (musterId, tastingDate, assignedTo, userId) => {
			try {
				for (let loop=0, length = assignedTo.length; loop<length; loop++) {
					assignedTo[loop] = ctx.ObjectID(assignedTo[loop]);
				}
				const users = await ctx.mongo.collection("user").find({_id: {$in: assignedTo}}, {projection: {_id: 1}}).toArray();
				if (users.length != assignedTo.length) {
					return {status: false, msg: "Invalid assignee"};
				}
				await ctx.mongo.collection("auction").findOneAndUpdate({_id: ctx.ObjectID(musterId)}, {$set: {assignedTo: assignedTo, tastingDate: tastingDate, updatedAt: new Date(), updatedBy: ctx.ObjectID(userId)}});
				return {status: true, msg: "Ok"};
			} catch (err) {
				const errMsg = "Encountered an unexpected error.";
				return {status: false, msg: errMsg};
			}
		},
		listExtra: async (input) => {
			if (input.auctionCenter) {
				input.auctionCenter = ctx.ObjectID(input.auctionCenter);
			}
			try {
				const docs = await ctx.mongo.collection("mark").aggregate([
					{$project: {name: 1, code: 1, categoryId: 1}},
					{$group: {_id: null, marks: {$push: "$$ROOT"}}},
					{$lookup: {from: "grade", pipeline: [
						{$project: {code: 1, slno: 1}},
					], as: "grades"}},
					{$lookup: {from: "auctioncenter", pipeline: [
						{$project: {name: 1, code: 1}},
					], as: "locations"}},
					{$lookup: {from: "user", pipeline: [
						{$match: {companyId: ctx.ObjectID(global.hostCompanyId), userType: "Taster"}},
						{$project: {userName: 1, locationId: 1}},
					], as: "users"}},
					{$lookup: {from: "auction", pipeline: [
						{$match: input},
						{$project: {auctionCenter: 1, saleNum: 1, season: 1, assignedTo: 1, tastingDate: 1}},
						{$sort: {saleNum: 1}},
					], as: "auctions"}},
				]).toArray();
				if (docs.length==1) {
					return {status: true, msg: "OK", doc: {auctions: docs[0].auctions, grades: docs[0].grades, locations: docs[0].locations, marks: docs[0].marks, users: docs[0].users}};
				}
				return {status: true, msg: "Ok", doc: {auctions: [], grades: [], locations: [], marks: [], users: []}};
			} catch (err) {
				return {status: false, msg: "encountered an unexpected error."};
			}
		},
		list: async (input) => {
			if (input.auctionCenter) {
				input.auctionCenter = ctx.ObjectID(input.auctionCenter);
			}
			try {
				const docs = await ctx.mongo.collection("auction").aggregate([
					{$match: input},
					{$project: {auctionCenter: 1, saleNum: 1, season: 1, assignedTo: 1, tastingDate: 1}},
					{$sort: {saleNum: 1}},
				]).toArray();
				return {status: true, msg: "Ok", docs: docs};
			} catch (err) {
				return {status: false, msg: "encountered an unexpected error."};
			}
		},
		listPendingForUser: async (season, userId) => {
			userId = ctx.ObjectID(userId);
			try {
				// const usr = await ctx.mongo.collection("user").findOne({_id: userId});
				// let userLocation = "";
				/* if (usr.locationId) {
					userLocation = usr.locationId.toHexString();
				} */
				const docs = await ctx.mongo.collection("auction").aggregate([
					{$match: {season: season, status: "PENDING", $or: [{assignedTo: userId}, {assignedTo: {$exists: false}}]}},
					{$project: {saleNum: 1, auctionCenter: 1, season: 1, tastingDate: 1, count: {$size: "$invoices"}}},
					{$lookup: {from: "auctioncenter", let: {auction_center: "$auctionCenter"}, pipeline: [
						{$match: {$expr: {$eq: ["$_id", "$$auction_center"]}}},
						{$project: {name: 1}},
					], as: "location"}},
					{$addFields: {location: {$arrayElemAt: ["$location.name", 0]}}},
					{$sort: {saleNum: 1}},
				]).toArray();
				const records = [];
				for (let loop=0, length = docs.length; loop<length; loop++) {
					/* const location = docs[loop].auctionCenter.toHexString();
					if (userLocation && (userLocation != location)) {
						continue;
					} */
					if (docs[loop].tastingDate) {
						docs[loop].tastingDate = docs[loop].tastingDate.getTime();
					}
					records.push(docs[loop]);
				}
				return {status: true, msg: "Ok", docs: records};
			} catch (err) {
				return {status: false, msg: "encountered an unexpected error."};
			}
		},
		listWithDetails: async (id) => {
			try {
				id = ctx.ObjectID(id);
				const docs = await ctx.mongo.collection("auction").aggregate([
					{$match: {_id: id, status: "PENDING"}},
					{$project: {"invoices": 1}},
					{$unwind: "$invoices"},
					{$group: {_id: null, ids: {$push: "$invoices.id"}, invoices: {$push: "$$ROOT.invoices"}}},
					{$lookup: {from: "invoices", let: {invoices: "$ids"}, pipeline: [{
						$match: {$expr: {$in: ["$_id", "$$invoices"]}}}, {
						$project: {markId: 1, gradeId: 1, noOfPkg: 1, invNo: 1, netPerPkg: 1, mfgDate: 1, season: 1}}], as: "invoices2"}},
				]).toArray();
				if (docs.length != 1) {
					return {status: false, msg: "Record not found"};
				}
				const doc = docs[0];
				const invoiceMap = {};
				for (let loop=0, length = doc.invoices2.length; loop <length; loop++) {
					invoiceMap[doc.invoices2[loop]._id.toHexString()] = doc.invoices2[loop];
				}
				for (let loop=0, length = doc.invoices.length; loop <length; loop++) {
					const id = doc.invoices[loop].id.toHexString();
					const ref = invoiceMap[id];
					if (ref) {
						doc.invoices[loop].invNo = ref.invNo;
						doc.invoices[loop].mfgDate = ref.mfgDate;
						doc.invoices[loop].markId = ref.markId;
						doc.invoices[loop].gradeId = ref.gradeId;
						doc.invoices[loop].noOfPkg = ref.noOfPkg;
						if (ref.netPerPkg) {
							doc.invoices[loop].netPerPkg = ref.netPerPkg;
						}
					}
				}
				delete doc.ids;
				delete doc.invoices2;
				const _ = require("lodash");
				doc.invoices = _.sortBy(doc.invoices, ["lotNum"]);
				return {status: true, msg: "Ok", docs: doc.invoices};
			} catch (err) {
				const errMsg = "Encountered an unexpected error.";
				return {status: false, msg: errMsg};
			}
		},
		serialize: (docs) => {
			try {
				for (let loop=0, length=docs.length; loop<length; loop++) {
					if (docs[loop]["tastingDate"]) {
						docs[loop]["tastingDate"] = docs[loop]["tastingDate"].getTime();
					}
					if (docs[loop]["saleDate"]) {
						docs[loop]["saleDate"] = docs[loop]["saleDate"].getTime();
					}
					if (docs[loop]["createdAt"]) {
						docs[loop]["createdAt"] = docs[loop]["createdAt"].getTime();
					}
					if (docs[loop]["updatedAt"]) {
						docs[loop]["updatedAt"] = docs[loop]["updatedAt"].getTime();
					}
				}
				return {status: true, msg: "Ok", docs: docs};
			} catch (err) {
				return {status: false, msg: "encountered an unexpected error."};
			}
		},
		deserialize: (docs) => {
			try {
				for (let loop=0, length=docs.length; loop<length; loop++) {
					if (docs[loop]["tastingDate"]) {
						docs[loop]["tastingDate"] = new Date(docs[loop]["tastingDate"]);
					}
					if (docs[loop]["saleDate"]) {
						docs[loop]["saleDate"] = new Date(docs[loop]["saleDate"]);
					}
					if (docs[loop]["createdAt"]) {
						docs[loop]["createdAt"] = new Date(docs[loop]["createdAt"]);
					}
					if (docs[loop]["updatedAt"]) {
						docs[loop]["updatedAt"] = new Date(docs[loop]["updatedAt"]);
					}
				}
				return {status: true, msg: "Ok", docs: docs};
			} catch (err) {
				return {status: false, msg: "encountered an unexpected error."};
			}
		},
	};
};
