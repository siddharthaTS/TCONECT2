module.exports = (ctx) => {
	return {
		list: async (query, projection) => {
			try {
				const docs = await ctx.mongo.collection("user").find(query, {projection: projection}).toArray();
				return {status: true, msg: "OK", docs: docs};
			} catch (err) {
				return {status: false, msg: "encountered an unexpected error."};
			}
		},
		getCountForMailId: async (mailId) => {
			if (!mailId || mailId.trim().length < 1) {
				return {status: false, msg: "Mailid is required."};
			}
			try {
				const count = await ctx.mongo.collection("user").count({userEmail: mailId});
				return {status: true, msg: "Ok", count: count};
			} catch (err) {
				return {status: false, msg: "encountered an unexpected error."};
			}
		},
		getCountForLoginId: async (loginId) => {
			if (!loginId || loginId.trim().length < 1) {
				return {status: false, msg: "LoginId is required."};
			}
			try {
				const count = await ctx.mongo.collection("user").count({loginId: loginId});
				return {status: true, msg: "Ok", count: count};
			} catch (err) {
				return {status: false, msg: "encountered an unexpected error."};
			}
		},
		authenticate: async (loginId, password, timezoneOffset, optionalprojections, mode) => {
			if (!(loginId && password)) {
				return {status: false, msg: "Both Username and Password are mandatory."};
			}
			if (!mode) {
				mode = "PORTAL";
			}
			if (!timezoneOffset) {
				timezoneOffset = -19800000;
			}
			var requiredProjections = {
				"_id": 1,
				"companyId": 1,
				"userName": 1,
				"userEmail": 1,
				"userType": 1,
				"loginId": 1,
				"password": 1,
				"timezoneOffset": 1,
				"lastLoggedAt": 1,
				"lastLoggedUsing": 1,
				"privileges": 1,
				"factoryId": 1,
				"companyIsActive": "$companyDetails.isActive",
				"isActive": 1,
				"activeSubscription": {$arrayElemAt: ["$companyDetails.companySubscriptionLog", -1]},
			};
			if (optionalprojections) {
				var optionalKeys = Object.keys(optionalprojections);
				for (var loop = 0; loop < optionalKeys.length; loop++) {
					if (!requiredProjections[optionalKeys[loop]]) {
						requiredProjections[optionalKeys[loop]] = optionalprojections[optionalKeys[loop]];
					}
				}
			}
			try {
				let usr = await ctx.mongo.collection("user").aggregate(
					[{
						"$match": {
							"loginId": loginId,
						},
					},
					{
						$lookup: {
							from: "company",
							localField: "companyId",
							foreignField: "_id",
							as: "companyDetails",
						},
					},
					{
						$unwind: "$companyDetails",
					},
					{
						$project: requiredProjections,
					},
					]).toArray();
				if (usr.length > 0) {
					usr = usr[0];
					if (usr.activeSubscription.endDate < new Date()) {
						return {status: false, msg: "Subscription expired, please contact system admin."};
					}
					if (!usr.companyIsActive) {
						return {status: false, msg: "Company has been set inactive, Please contact system admin"};
					}
					if (!usr.isActive) {
						return {status: false, msg: "Your account has been set inactive, please contact system admin."};
					}
					const bcrypt = require("bcrypt");
					const isValidPassword = await bcrypt.compare(password, usr.password);
					if (!isValidPassword) {
						return {status: false, msg: "Invalid username/password."};
					}
					delete usr.password;
					delete usr.isActive;
					delete usr.companyIsActive;
					await ctx.mongo.collection("user").findOneAndUpdate(
						{
							_id: usr._id,
						},
						{
							$set: {
								lastLoggedAt: new Date(),
								lastLoggedUsing: mode,
								timezoneOffset: timezoneOffset,
							},
						});
					usr.timezoneOffset = timezoneOffset;
					return {status: true, msg: "Ok", doc: usr};
				} else {
					return {status: false, msg: "User does not exists."};
				}
			} catch (err) {
				return {status: false, msg: "encountered an unexpected error."};
			}
		},
		authenticateLite: async (loginId, password, mode) => {
			if (!mode) {
				mode = "API";
			}
			if (!(loginId && password)) {
				return {status: false, msg: "Both Username and Password are mandatory."};
			}
			loginId = loginId.toLowerCase();
			var requiredProjections = {
				"_id": 1,
				"companyId": 1,
				"userName": 1,
				"password": 1,
				"userEmail": 1,
				"userType": 1,
				"contactNumber": 1,
				"isReadonly": 1,
				"isActive": 1,
				"locationId": 1,
			};
			try {
				let usr = await ctx.mongo.collection("user").aggregate(
					[{
						"$match": {
							loginId: loginId,
						},
					},
					{
						$project: requiredProjections,
					},
					]).toArray();
				if (usr.length > 0) {
					usr = usr[0];
					if (!usr.isActive) {
						return {status: false, msg: "Your account has been set inactive, please contact system admin."};
					}
					const bcrypt = require("bcrypt");
					const isValidPassword = await bcrypt.compare(password, usr.password);
					if (!isValidPassword) {
						return {status: false, msg: "Invalid loginid/password."};
					}
					if (usr.loginExists) {
						// return {status: false, msg: "Invalid loginid/password."};
					}
					const updateobj = {lastLoggedUsing: mode, lastLoggedAt: new Date()};
					if (mode!="API") {
						updateobj.loginExists = true;
					}
					ctx.mongo.collection("user").findOneAndUpdate({_id: usr._id}, {$set: updateobj});
					delete usr.password;
					delete usr.isActive;
					// delete usr.companyId;
					return {status: true, msg: "Ok", doc: usr};
				} else {
					return {status: false, msg: "Invalid loginid/password."};
				}
			} catch (err) {
				return {status: false, msg: "encountered an unexpected error."};
			}
		},
		create: async (user) => {
			try {
				const _id = new ctx.ObjectID();
				user._id = _id;
				if (!user.parentUserId) {
					user.parentUserId = _id;
					user.createdBy = _id;
					user.updatedBy = _id;
				} else {
					user.parentUserId = ctx.ObjectID(user.parentUserId);
					if (user.locationId) {
						user.locationId = ctx.ObjectID(user.locationId);
					}
					user.createdBy = ctx.ObjectID(user.createdBy);
					user.updatedBy = ctx.ObjectID(user.updatedBy);
				}
				user.companyId = ctx.ObjectID(user.companyId);
				const bcrypt = require("bcrypt");
				const saltRounds = 10;
				user.password = await bcrypt.hash(user.password, saltRounds);
				await ctx.mongo.collection("user").insertOne(user);
				return {status: true, msg: "OK", doc: user};
			} catch (e) {
				return {status: false, msg: "Encountered an unexpected error."};
			}
		},
		updatePasswordUsingLoginid: async (loginId, password, updatingUserId, optionalMatch) => {
			if (!(loginId && password)) {
				return {status: false, msg: "Parameter(s) missing."};
			}
			if (loginId.trim().length < 1) {
				return {status: false, msg: "LoginId is mandatory."};
			}
			if (password.trim().length < 1) {
				return {status: false, msg: "Password is mandatory."};
			}
			loginId = loginId.toLowerCase();
			var criteria = {
				"loginId": loginId,
			};
			try {
				if (optionalMatch) {
					var keys = Object.keys(optionalMatch);
					for (var loop = 0; loop < keys.length; loop++) {
						if (!criteria[keys[loop]]) {
							criteria[keys[loop]] = optionalMatch[keys[loop]];
						}
					}
				}
				const doc = await ctx.mongo.collection("user").findOne(criteria, {projection: {_id: 1}});
				if (!doc) {
					return {status: false, msg: "User does not exists."};
				}
				const bcrypt = require("bcrypt");
				const saltRounds = 10;
				const encryptedPassword = await bcrypt.hash(password, saltRounds);
				await ctx.mongo.collection("user").findOneAndUpdate({_id: doc._id},
					{$set: {password: encryptedPassword, updatedAt: new Date(), updatedBy: ctx.ObjectID(updatingUserId)}});
				return {status: true, msg: "Ok"};
			} catch (e) {
				return {status: false, msg: "Encountered an unexpected error."};
			}
		},
		updatePassword: async (userId, password, updatingUserId, optionalMatch) => {
			if (!(userId && password)) {
				return {status: false, msg: "Parameter(s) missing."};
			}
			if (userId.trim().length < 1) {
				return {status: false, msg: "UserId is mandatory."};
			}
			if (password.trim().length < 1) {
				return {status: false, msg: "Password is mandatory."};
			}
			var criteria = {
				"_id": ctx.ObjectID(userId),
			};
			try {
				if (optionalMatch) {
					var keys = Object.keys(optionalMatch);
					for (var loop = 0; loop < keys.length; loop++) {
						if (!criteria[keys[loop]]) {
							criteria[keys[loop]] = optionalMatch[keys[loop]];
						}
					}
				}
				const bcrypt = require("bcrypt");
				const saltRounds = 10;
				const encryptedPassword = await bcrypt.hash(password, saltRounds);
				await ctx.mongo.collection("user").findOneAndUpdate(criteria,
					{$set: {password: encryptedPassword, updatedAt: new Date(), updatedBy: ctx.ObjectID(updatingUserId)}});
				return {status: true, msg: "Ok"};
			} catch (e) {
				return {status: false, msg: "Encountered an unexpected error."};
			}
		},
		getAllUsers: async (currentUserId, projection) => {
			currentUserId = ctx.ObjectID(currentUserId);
			if (!projection) {
				projection = {
					userName: 1,
					code: 1,
					userEmail: 1,
					parentUserId: 1,
					isActive: 1,
					contactNumber: 1,
					userType: 1,
					loginId: 1,
					privileges: 1,
					locationId: 1,
					pushToken: 1,
				};
			}
			const _ = require("lodash");
			try {
				let ids = [currentUserId];

				var getChildren = async function(parents) {
					parents = _.uniq(parents);
					const docs = await ctx.mongo.collection("user").find({parentUserId: {$in: parents}}, {projection: {_id: 1}}).toArray();
					ids = ids.concat(parents);
					var results = _.map(docs, "_id");
					if (results.length > 0) {
						ids = ids.concat(results);
						const __tmp = _.difference(results, parents);
						for (let loop=0, length = __tmp.length; loop<length; loop++) {
							__tmp[loop] = ctx.ObjectID(__tmp[loop]);
						}
						await getChildren(__tmp);
					} else {
						ids = _.uniq(ids);
						for (let loop=0, length = ids.length; loop<length; loop++) {
							ids[loop] = ctx.ObjectID(ids[loop]);
						}
					}
				};

				await getChildren(ids);
				const docs = await ctx.mongo.collection("user").find({_id: {$in: ids}}, {projection: projection}).toArray();
				return {status: true, msg: "Ok", docs: docs};
			} catch (err) {
				return {status: false, msg: "Encountered an unexpected error."};
			}
		},
		getAllCompanyUsers: async (companyId, projection) => {
			companyId = ctx.ObjectID(companyId);
			var query = {companyId: companyId};
			if (!projection) {
				projection = {
					userName: 1,
					code: 1,
					userEmail: 1,
					parentUserId: 1,
					isActive: 1,
					contactNumber: 1,
					userType: 1,
					loginId: 1,
					privileges: 1,
					locationId: 1,
				};
			}
			try {
				const docs = await ctx.mongo.collection("user").find(query, {projection: projection}).toArray();
				return {status: true, msg: "OK", docs: docs};
			} catch (err) {
				return {status: false, msg: "Encountered an unexpected error."};
			}
		},
		updateAdmin: async (companyId, update) => {
			try {
				const docs = await ctx.mongo.collection("user").find({"companyId": companyId}, {
					project: {
						"_id": 1,
					},
				}).sort({createdAt: 1}).limit(1).toArray();
				if (update.$set) {
					if (update.$set.updatedBy) {
						update.$set.updatedBy = ctx.ObjectID(update.$set.updatedBy);
					}
					if (update.$set.parentUserId) {
						update.$set.parentUserId = ctx.ObjectID(update.$set.parentUserId);
					}
				}
				const result = await ctx.mongo.collection("user").findOneAndUpdate({_id: ctx.ObjectID(docs[0]._id)}, update,
					{
						projection: {
							companyId: 1,
							userName: 1,
							userEmail: 1,
							isActive: 1,
							contactNumber: 1,
							userType: 1,
							privileges: 1,
							loginId: 1,
							parentUserId: 1,
							locationId: 1,
							// pushToken: 1,
						},
						returnOriginal: false,
					});
				return {status: true, msg: "Admin successfully updated.", doc: result.value};
			} catch (e) {
				return {status: false, msg: "Encountered an unexpected error."};
			}
		},
		update: async (userID, update) => {
			try {
				if (update.$set) {
					if (update.$set.updatedBy) {
						update.$set.updatedBy = ctx.ObjectID(update.$set.updatedBy);
					}
					if (update.$set.parentUserId) {
						update.$set.parentUserId = ctx.ObjectID(update.$set.parentUserId);
					}
					if (update.$set.locationId) {
						update.$set.locationId = ctx.ObjectID(update.$set.locationId);
					}
				}
				const result = await ctx.mongo.collection("user").findOneAndUpdate({_id: ctx.ObjectID(userID)}, update,
					{
						projection: {
							companyId: 1,
							userName: 1,
							code: 1,
							userEmail: 1,
							isActive: 1,
							contactNumber: 1,
							userType: 1,
							privileges: 1,
							loginId: 1,
							parentUserId: 1,
							locationId: 1,
							// pushToken: 1,
						},
						returnOriginal: false,
					});
				if (result.lastErrorObject.n >= 0) {
					return {status: true, msg: "User successfully updated.", doc: result.value};
				} else {
					return {status: true, msg: "User does not exists"};
				}
			} catch (err) {
				let errMsg = "Encountered an unexpected error.";
				const indexes = ["userEmail_1", "loginId_1"];
				const messages = ["Name already in use", "LoginId already in use."];
				if (err.errmsg) {
					for (let innerLoop = 0, innerLength = indexes.length; innerLoop < innerLength; innerLoop++) {
						if (err.errmsg.indexOf(indexes[innerLoop]) >= 0) {
							errMsg = messages[innerLoop];
							break;
						}
					}
				}
				return {status: false, msg: errMsg};
			}
		},
		updateMany: async (query, update) => {
			if (!query || !update) {
				return {status: false, msg: "Parameter(s) missing."};
			}
			try {
				if (update.$set) {
					if (update.$set.updatedBy) {
						update.$set.updatedBy = ctx.ObjectID(update.$set.updatedBy);
					}
					if (update.$set.parentUserId) {
						update.$set.parentUserId = ctx.ObjectID(update.$set.parentUserId);
					}
				}
				await ctx.mongo.collection("user").updateMany(query, update);
				return {status: true, msg: "Successfully updated."};
			} catch (e) {
				return {status: false, msg: "Encountered an unexpected error."};
			}
		},
		details: async (criteria, project, sort) => {
			if (criteria._id && (typeof criteria._id === "string" || criteria._id instanceof String)) {
				criteria._id = ctx.ObjectID(criteria._id);
			}
			if (!sort) {
				sort = {createdAt: 1};
			}
			if (!criteria) {
				criteria = {};
			}
			if (!project) {
				project = {
					"userName": 1,
					"code": 1,
					"userEmail": 1,
					"contactNumber": 1,
					"userType": 1,
					"books": 1,
					"loginId": 1,
					"parentUserId": 1,
					"pushToken": 1,
					"locationId": 1,
				};
			}
			try {
				const docs = await ctx.mongo.collection("user").find(criteria, {projection: project}).sort(sort).limit(1).toArray();
				if (docs.length != 1) {
					return {status: false, msg: "No User found for your search citeria."};
				}
				return {status: true, msg: "OK", doc: docs[0]};
			} catch (e) {
				return {status: false, msg: "Encountered an unexpected error."};
			}
		},
		createBulk: async (users) => {
			try {
				const bulk = ctx.mongo.collection("user").initializeUnorderedBulkOp();
				var indexes = [" userEmail_1 ", " loginId_1 ", "code_1"];
				var messages = ["Email Id already exists.", "Login Id already exists.", "Code already in use."];
				var incorrectPasswords = [];
				var outcome = [];
				let writeErrors = [];
				for (var loop = 0; loop < users.length; loop++) {
					try {
						users[loop]._id = ctx.ObjectID(users[loop]._id);
						if (users[loop].companyId) {
							users[loop].companyId = ctx.ObjectID(users[loop].companyId);
						}
						if (users[loop].parentUserId) {
							users[loop].parentUserId = ctx.ObjectID(users[loop].parentUserId);
						}
						if (users[loop].createdBy) {
							users[loop].createdBy = ctx.ObjectID(users[loop].createdBy);
						}
						if (users[loop].updatedBy) {
							users[loop].updatedBy = ctx.ObjectID(users[loop].updatedBy);
						}
						if (users[loop].locationId) {
							users[loop].locationId = ctx.ObjectID(users[loop].locationId);
						}
						users[loop].timezoneOffset = -19800000;
						outcome.push("Record inserted successfully.");
						bulk.insert(users[loop]);
					} catch (e) {
						outcome.push("Invalid password.");
					}
				}
				try {
					const result = await bulk.execute();
					writeErrors = result.getWriteErrors();
				} catch (err) {
					writeErrors = err.result.getWriteErrors();
				}
				if (writeErrors.length == 0) {
					return {
						status: true,
						msg: "OK",
						result: {"outcome": outcome, "successCount": (outcome.length - incorrectPasswords.length)},
					};
				}
				const innerLength = indexes.length;
				for (let loop = 0, length = writeErrors.length; loop < length; loop++) {
					let matchFound = false;
					for (let innerLoop = 0; innerLoop < innerLength; innerLoop++) {
						if (writeErrors[loop].errmsg.indexOf(indexes[innerLoop]) >= 0) {
							outcome[writeErrors[loop].index] = messages[innerLoop];
							matchFound = true;
							break;
						}
					}
					if (!matchFound) {
						outcome[writeErrors[loop].index] = "Record not inserted.";
					}
				}
				return {
					status: true,
					msg: "OK",
					result: {
						"outcome": outcome,
						"successCount": (outcome.length - writeErrors.length - incorrectPasswords.length),
					},
				};
			} catch (e) {
				return {status: false, msg: "Encountered an unexpected error."};
			}
		},
		updatePasswordApp: async (userId, oldPassword, newPassword) => {
			try {
				userId = ctx.ObjectID(userId);
				let user = null;
				user = await ctx.mongo.collection("user").findOne({_id: userId});
				if (!user) {
					return {status: false, msg: "Invalid User."};
				}
				const bcrypt = require("bcrypt");
				const isValidPassword = await bcrypt.compare(oldPassword, user.password);
				if (!isValidPassword) {
					return {status: false, msg: "Invalid old password."};
				}
				const saltRounds = 10;
				const encryptedPassword = await bcrypt.hash(newPassword, saltRounds);
				await ctx.mongo.collection("user").findOneAndUpdate({_id: userId}, {$set: {password: encryptedPassword, updatedAt: new Date()}});
				return {status: true, msg: "Ok"};
			} catch (e) {
				return {status: false, msg: "Encountered an unexpected error."};
			}
		},
		updateProfileApp: async (userId, user, userType) => {
			try {
				userId = ctx.ObjectID(userId);
				let result = null;
				result = await ctx.mongo.collection("user").findOneAndUpdate({_id: userId}, {$set: {
					userName: user.userName,
					userEmail: user.userEmail,
					contactNumber: user.contactNumber,
					updatedAt: new Date(),
				}}, {
					projection: {
						userName: 1,
						code: 1,
						userEmail: 1,
						contactNumber: 1,
						_id: 0,
					},
					returnOriginal: false,
				});
				await ctx.mongo.collection("user").findOne({_id: userId}, {projection: {companyId: 1, _id: 0}});
				return {status: true, msg: "Ok", doc: result.value};
			} catch (e) {
				return {status: false, msg: "Encountered an unexpected error."};
			}
		},
		pingLogin: async (userId, userType) => {
			try {
				userId = ctx.ObjectID(userId);
				await ctx.mongo.collection("user").findOneAndUpdate({_id: userId}, {$set: {
					loginExists: true,
					updatedAt: new Date(),
				}});
				return {status: true, msg: "Ok"};
			} catch (e) {
				return {status: false, msg: "Encountered an unexpected error."};
			}
		},
		logoutAppUser: async (userId) => {
			try {
				userId = ctx.ObjectID(userId);
				await ctx.mongo.collection("user").findOneAndUpdate({_id: userId}, {$unset: {loginExists: 1}, $set: {updatedAt: new Date()}});
				return {status: true, msg: "Ok"};
			} catch (e) {
				return {status: false, msg: "Encountered an unexpected error."};
			}
		},
		updateAppUser: async (user) => {
			try {
				user._id = ctx.ObjectID(user._id);
				let result = null;
				const update = {isReadonly: user.isReadonly, updatedAt: new Date()};
				result = await ctx.mongo.collection("user").findOneAndUpdate({_id: user._id}, {$set: update}, {
					projection: {
						isReadonly: 1,
						_id: 0,
					},
					returnOriginal: false,
				});
				return {status: true, msg: "Ok", doc: result.value};
			} catch (e) {
				return {status: false, msg: "Encountered an unexpected error."};
			}
		},
		info: async (_id, projection) => {
			_id = ctx.ObjectID(_id);
			if (!projection) {
				projection = {isAuctionUser: 1, isReadonly: 1};
			}
			try {
				const doc = await ctx.mongo.collection("user").findOne({_id: _id}, {projection: projection});
				return {status: true, msg: "OK", doc: doc};
			} catch (e) {
				return {status: false, msg: "Encountered an unexpected error."};
			}
		},
		generateUserOTP: async (loginId) => {
			if (!(loginId)) {
				return {status: false, msg: "Username is mandatory."};
			}
			loginId = loginId.toLowerCase();
			var requiredProjections = {
				"_id": 1,
				"contactNumber": 1,
				"otpCount": 1,
				"companyIsActive": "$companyDetails.isActive",
				"isActive": 1,
				"activeSubscription": {$arrayElemAt: ["$companyDetails.companySubscriptionLog", -1]},
			};
			try {
				let usr = await ctx.mongo.collection("user").aggregate(
					[{
						"$match": {
							loginId: loginId, isAuctionUser: true,
						},
					},
					{
						$lookup: {
							from: "company",
							localField: "companyId",
							foreignField: "_id",
							as: "companyDetails",
						},
					},
					{
						$unwind: "$companyDetails",
					},
					{
						$project: requiredProjections,
					},
					]).toArray();
				if (usr.length > 0) {
					usr = usr[0];
					if (usr.activeSubscription.endDate < new Date()) {
						return {status: false, msg: "Subscription expired, please contact system admin."};
					}
					if (!usr.companyIsActive) {
						return {status: false, msg: "Company has been set inactive, Please contact system admin"};
					}
					if (!usr.isActive) {
						return {status: false, msg: "Your account has been set inactive, please contact system admin."};
					}
					if (usr.otpCount && (usr.otpCount>2)) {
						return {status: false, msg: "Your account has been set inactive, please contact system admin."};
					}
					const randtoken = require("rand-token").generator({chars: "0-9"});
					const OTP = randtoken.generate(4);
					await ctx.mongo.collection("user").findOneAndUpdate({_id: usr._id}, {$set: {otp: OTP, updatedAt: new Date()}, $inc: {"otpCount": 1}});
					const service = require("../services/httpService");
					service.getRequest("https://api.msg91.com/api/v5/otp", {
						authkey: "327008A3FdrqCEbq5ea12d53P1",
						template_id: "5ea14df2d6fc050aad0f480c",
						mobile: `+91${usr.contactNumber.substring(usr.contactNumber.length -10)}`,
						otp: OTP,
					});
					const mobile = "XXXXXX" + usr.contactNumber.substring(usr.contactNumber.length -4);
					return {status: true, msg: "Ok", doc: usr, mobile: mobile};
				} else {
					return {status: false, msg: "Invalid loginid/password."};
				}
			} catch (err) {
				return {status: false, msg: "encountered an unexpected error."};
			}
		},
		resetUserPassword: async (loginId, otp, password) => {
			if (!(loginId && password && otp)) {
				return {status: false, msg: "Both Username and Password are mandatory."};
			}
			loginId = loginId.toLowerCase();
			var requiredProjections = {
				"_id": 1,
				"otp": 1,
				"updatedAt": 1,
				"companyIsActive": "$companyDetails.isActive",
				"isActive": 1,
				"activeSubscription": {$arrayElemAt: ["$companyDetails.companySubscriptionLog", -1]},
			};
			try {
				let usr = await ctx.mongo.collection("user").aggregate(
					[{
						"$match": {
							loginId: loginId, isAuctionUser: true,
						},
					},
					{
						$lookup: {
							from: "company",
							localField: "companyId",
							foreignField: "_id",
							as: "companyDetails",
						},
					},
					{
						$unwind: "$companyDetails",
					},
					{
						$project: requiredProjections,
					},
					]).toArray();
				if (usr.length > 0) {
					usr = usr[0];
					if (usr.activeSubscription.endDate < new Date()) {
						return {status: false, msg: "Subscription expired, please contact system admin."};
					}
					if (!usr.companyIsActive) {
						return {status: false, msg: "Company has been set inactive, Please contact system admin"};
					}
					if (!usr.isActive) {
						return {status: false, msg: "Your account has been set inactive, please contact system admin."};
					}
					if (usr.otp != otp) {
						return {status: false, msg: "OTP does not match."};
					}
					const timeDelay = new Date().getTime() - usr.updatedAt.getTime();
					if (timeDelay> (15 * 60 * 1000)) {
						return {status: false, msg: "OTP expired."};
					}
					const bcrypt = require("bcrypt");
					const saltRounds = 10;
					const encryptedPassword = await bcrypt.hash(password, saltRounds);
					await ctx.mongo.collection("user").findOneAndUpdate({_id: usr._id}, {$set: {password: encryptedPassword, updatedAt: new Date()}, $unset: {otpCount: 1, otp: 1}});
					return {status: true, msg: "Ok"};
				} else {
					return {status: false, msg: "Invalid loginid/password."};
				}
			} catch (err) {
				return {status: false, msg: "encountered an unexpected error."};
			}
		},
		updateLastOnline: async (userID) => {
			try {
				userID = ctx.ObjectID(userID);
				const now = new Date();
				const result = await ctx.mongo.collection("user").findOneAndUpdate({_id: userID}, {$set: {lastOnline: now, updatedAt: now}},
					{projection: {isAuctionUser: 1, isReadonly: 1, _id: 0}, returnOriginal: false});
				if (result.lastErrorObject.n >= 0) {
					return {status: true, msg: "OK.", doc: result.value};
				} else {
					return {status: true, msg: "User does not exists"};
				}
			} catch (e) {
				return {status: false, msg: "Encountered an unexpected error."};
			}
		},
		getAllCompanyUsersExtra: async (companyId, projection) => {
			companyId = ctx.ObjectID(companyId);
			const query = {companyId: companyId};
			if (!projection) {
				projection = {
					userName: 1,
					code: 1,
					userEmail: 1,
					parentUserId: 1,
					isActive: 1,
					contactNumber: 1,
					userType: 1,
					loginId: 1,
					privileges: 1,
					locationId: 1,
				};
			}
			try {
				const docs = await ctx.mongo.collection("user").aggregate([
					{$match: query},
					{$project: projection},
					{$group: {_id: null, users: {$push: "$$ROOT"}}},
					{$lookup: {from: "location", pipeline: [
						{$project: {name: 1, code: 1}},
					], as: "locations"}},
				]).toArray();
				if (docs.length==1) {
					return {status: true, msg: "OK", doc: {users: docs[0].users, locations: docs[0].locations}};
				}
				return {status: true, msg: "Ok", doc: {users: [], locations: []}};
			} catch (err) {
				return {status: false, msg: "Encountered an unexpected error."};
			}
		},
		listTastersWithLocations: async () => {
			try {
				const docs = await ctx.mongo.collection("user").aggregate([
					{$match: {userType: "Taster"}},
					{$project: {userName: 1, code: 1}},
					{$group: {_id: null, users: {$push: "$$ROOT"}}},
					{$lookup: {from: "location", pipeline: [
						{$project: {name: 1}},
					], as: "locations"}},
				]).toArray();
				if (docs.length != 1) {
					return {status: true, msg: "OK", doc: {users: [], locations: []}};
				}
				return {status: true, msg: "OK", doc: {users: docs[0].users, locations: docs[0].locations}};
			} catch (err) {
				return {status: false, msg: "encountered an unexpected error."};
			}
		},
		listUsersWithLocations: async () => {
			try {
				const docs = await ctx.mongo.collection("user").aggregate([
					{$match: {companyId: ctx.ObjectID(global.hostCompanyId)}},
					{$project: {userName: 1, code: 1}},
					{$group: {_id: null, users: {$push: "$$ROOT"}}},
					{$lookup: {from: "location", pipeline: [
						{$project: {name: 1}},
					], as: "locations"}},
				]).toArray();
				if (docs.length != 1) {
					return {status: true, msg: "OK", doc: {users: [], locations: []}};
				}
				return {status: true, msg: "OK", doc: {users: docs[0].users, locations: docs[0].locations}};
			} catch (err) {
				return {status: false, msg: "encountered an unexpected error."};
			}
		},
		listUsersWithCenters: async () => {
			try {
				const docs = await ctx.mongo.collection("user").aggregate([
					{$match: {companyId: ctx.ObjectID(global.hostCompanyId)}},
					{$project: {userName: 1, code: 1}},
					{$group: {_id: null, users: {$push: "$$ROOT"}}},
					{$lookup: {from: "auctioncenter", pipeline: [
						{$project: {name: 1, code: 1}},
					], as: "centers"}},
				]).toArray();
				if (docs.length != 1) {
					return {status: true, msg: "OK", doc: {users: [], centers: []}};
				}
				return {status: true, msg: "OK", doc: {users: docs[0].users, centers: docs[0].centers}};
			} catch (err) {
				return {status: false, msg: "encountered an unexpected error."};
			}
		},
		assignedPendingRecords: async (userId, season) => {
			userId = ctx.ObjectID(userId);
			const dt = new Date();
			if (!season) {
				season = dt.getFullYear();
				const month = dt.getMonth();
				if (month<3) {
					season --;
				}
			}
			try {
				const docs = await ctx.mongo.collection("auctioncenter").aggregate([
					{$project: {name: 1, code: 1}},
					{$group: {_id: null, locations: {$push: "$$ROOT"}}},
					{$lookup: {from: "muster", pipeline: [
						// {$match: {$expr: {$and: [{$eq: ["$season", season]}, {$eq: ["$status", "PENDING"]}, {$in: [userId, {$ifNull: ["$assignedTo", [userId]]}]}]}}},
						{$match: {$expr: {$and: [{$eq: ["$season", season]}, {$eq: ["$status", "PENDING"]}]}}},
						{$project: {markId: 1, createdAt: 1, tastingDate: 1, count: {$size: "$invoices"}, assignedTo: 1}},
						{$sort: {createdAt: 1}},
					], as: "musters"}},
					{$lookup: {from: "auction", pipeline: [
						// {$match: {season: season, status: "PENDING", $or: [{assignedTo: userId}, {assignedTo: {$exists: false}}]}},
						{$match: {season: season, status: "PENDING"}},
						{$project: {saleNum: 1, auctionCenter: 1, season: 1, tastingDate: 1, count: {$size: "$invoices"}, assignedTo: 1}},
					], as: "auctions"}},
				]).toArray();
				if (docs.length != 1) {
					return {status: true, msg: "OK", doc: {locations: [], musters: [], auctions: [], sellers: [], marks: []}};
				}
				const locations = docs[0].locations;
				const musters = docs[0].musters;
				const auctions = docs[0].auctions;
				// const clientIds = [];
				// const markIds = [];
				let meta = await ctx.mongo.collection("user").aggregate([
					{$match: {userType: "Taster"}},
					{$project: {userName: 1, code: 1}},
					{$group: {_id: null, tasters: {$push: "$$ROOT"}}},
					{$lookup: {from: "sellermarkmapping", pipeline: [
						{$match: {dateFrom: {$lte: dt}, dateTo: {$gte: dt}}},
						{$project: {seller: 1, mark: 1, _id: 0}},
					], as: "mappings"}},
				]).toArray();
				if (meta.length !=1) {
					meta = {tasters: [], mappings: []};
				} else {
					meta = meta[0];
				}
				const tasters = meta.tasters;
				const mappings = meta.mappings;
				const userMap = {};
				for (let loop=0, length = tasters.length; loop<length; loop++) {
					userMap[tasters[loop]._id.toHexString()] = tasters[loop].code;
				}
				const markSellerMap = {};
				for (let loop=0, length = mappings.length; loop<length; loop++) {
					markSellerMap[mappings[loop].mark.toHexString()] = mappings[loop].seller.toHexString();
				}
				for (let loop=0, length = musters.length; loop<length; loop++) {
					if (musters[loop].createdAt) {
						musters[loop].createdAt = musters[loop].createdAt.getTime();
					}
					if (musters[loop].tastingDate) {
						musters[loop].tastingDate = musters[loop].tastingDate.getTime();
					}
					const markId = musters[loop].markId.toHexString();
					musters[loop].companyId = markSellerMap[markId];
					/* if (markIds.indexOf(markId)<0) {
						markIds.push(markIds);
					} */
					if (musters[loop].assignedTo) {
						const _assignedTo = [];
						for (let tLoop=0, tLen = musters[loop].assignedTo.length; tLoop<tLen; tLoop++) {
							const taster = musters[loop].assignedTo[tLoop].toHexString();
							_assignedTo.push(userMap[taster]);
						}
						musters[loop].assignedTo = _assignedTo.join(", ");
					} else {
						musters[loop].assignedTo = "--";
					}
				}
				for (let loop=0, length = auctions.length; loop<length; loop++) {
					if (auctions[loop].tastingDate) {
						auctions[loop].tastingDate = auctions[loop].tastingDate.getTime();
					}
					if (auctions[loop].assignedTo) {
						const _assignedTo = [];
						for (let tLoop=0, tLen = auctions[loop].assignedTo.length; tLoop<tLen; tLoop++) {
							const taster = auctions[loop].assignedTo[tLoop].toHexString();
							_assignedTo.push(userMap[taster]);
						}
						auctions[loop].assignedTo = _assignedTo.join(", ");
					} else {
						auctions[loop].assignedTo = "--";
					}
				}
				/* const docs2 = await ctx.mongo.collection("client").aggregate([
					{$match: {_id: {$in: clientIds}}},
					{$project: {name: 1, gstin: 1, emailId: 1, isActive: 1}},
					{$lookup: {from: "mark", let: {company_id: "$_id"}, pipeline: [
						{$match: {$expr: {$eq: ["$companyId", "$$company_id"]}}},
						{$project: {name: 1, categoryId: 1, locationId: 1}},
					], as: "marks"}},
				]).toArray(); */
				const meta2 = await ctx.mongo.collection("seller").aggregate([
					{$project: {name: 1, gstin: 1, emailId: 1, isActive: 1}},
					{$group: {_id: null, sellers: {$push: "$$ROOT"}}},
					{$lookup: {from: "mark", pipeline: [
						{$project: {name: 1, category: 1, locationId: 1}},
					], as: "marks"}},
				]).toArray();
				let marks = [];
				let sellers = [];
				if (meta2.length==1) {
					marks = meta2[0].marks;
					sellers = meta2[0].sellers;
				}
				/* for (let loop=0, length = docs2.length; loop<length; loop++) {
					const client = docs2[loop];
					for (let inner=0, innerLen = client.marks.length; inner<innerLen; inner++) {
						marks.push(client.marks[inner]);
					}
					delete client.marks;
					clients.push(client);
				} */
				return {status: true, msg: "OK", doc: {locations: locations, musters: musters, auctions: auctions, sellers: sellers, marks: marks}};
			} catch (err) {
				return {status: false, msg: "encountered an unexpected error."};
			}
		},
		serialize: (docs) => {
			try {
				for (let loop = 0, length = docs.length; loop < length; loop++) {
					if (docs[loop]["createdAt"]) {
						docs[loop]["createdAt"] = docs[loop]["createdAt"].getTime();
					}
					if (docs[loop]["updatedAt"]) {
						docs[loop]["updatedAt"] = docs[loop]["updatedAt"].getTime();
					}
					if (docs[loop]["lastLoggedAt"]) {
						docs[loop]["lastLoggedAt"] = docs[loop]["lastLoggedAt"].getTime();
					}
					if (docs[loop]["lastOnline"]) {
						docs[loop]["lastOnline"] = docs[loop]["lastOnline"].getTime();
					}
				}
				return {status: true, msg: "Ok", docs: docs};
			} catch (err) {
				return {status: false, msg: "encountered an unexpected error."};
			}
		},
		deserialize: (docs) => {
			try {
				for (let loop=0, length=docs.length; loop<length; loop++) {
					docs[loop]._id = ctx.ObjectID(docs[loop]._id);
					if (docs[loop]["createdAt"]) {
						docs[loop]["createdAt"] = new Date(docs[loop]["createdAt"]);
					}
					if (docs[loop]["updatedAt"]) {
						docs[loop]["updatedAt"] = new Date(docs[loop]["updatedAt"]);
					}
					if (docs[loop]["lastLoggedAt"]) {
						docs[loop]["lastLoggedAt"] = new Date(docs[loop]["lastLoggedAt"]);
					}
					if (docs[loop]["lastOnline"]) {
						docs[loop]["lastOnline"] = new Date(docs[loop]["lastOnline"]);
					}
				}
				return {status: true, msg: "Ok", docs: docs};
			} catch (err) {
				return {status: false, msg: "encountered an unexpected error."};
			}
		},
	};
};
