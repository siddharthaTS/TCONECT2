module.exports = (ctx) => {
	return {
		attributes: {
			name: {
				type: "STRING",
				min: 4,
				max: 80,
				transform: "TITLECASE",
				label: "Seller Name",
			},
			code: {
				type: "STRING",
				min: 1,
				max: 10,
				transform: "UPPERCASE",
				label: "Seller Code",
			},
			mobile: {
				type: "MOBILE",
				min: 5,
				max: 15,
			},
			email: {
				type: "EMAIL",
				min: 5,
				max: 40,
				transform: "LOWERCASE",
			},
			contactPerson: {
				label: "Contact Person",
				type: "STRING",
				min: 2,
				max: 40,
				transform: "TITLECASE",
			},
			city: {
				type: "STRING",
				min: 2,
				max: 15,
				transform: "TITLECASE",
			},
			state: {
				type: "STRING",
				min: 2,
				max: 15,
				transform: "TITLECASE",
			},
			pincode: {
				type: "NUMBER",
				min: 100000,
				max: 999999,
			},
			address: {
				type: "STRING",
				min: 1,
				max: 120,
				transform: "TITLECASE",
			},
			gstin: {
				label: "GSTIN",
				type: "STRING",
				min: 15,
				max: 15,
				transform: "UPPERCASE",
			},
			cin: {
				label: "CIN No",
				type: "STRING",
				min: 10,
				max: 25,
				transform: "UPPERCASE",
			},
			fssaiNo: {
				label: "FSSAI No",
				type: "STRING",
				min: 14,
				max: 14,
				transform: "UPPERCASE",
				nullable: true,
			},
		},
		metadata: {
			name: "seller",
			plural: "sellers",
			collection: "seller",
		},
		create: async (input) => {
			try {
				if (!input._id) {
					input._id = new ctx.ObjectID();
				}
				await ctx.mongo.collection("seller").insertOne(input);
				return {status: true, msg: "seller created", doc: input};
			} catch (err) {
				return {status: false, msg: "encountered an unexpected error."};
			}
		},
		update: async (id, values, projection) => {
			try {
				if (!projection) {
					projection={
						name: 1,
						code: 1,
						mobile: 1,
						email: 1,
						contactPerson: 1,
						city: 1,
						state: 1,
						pincode: 1,
						address: 1,
						gstin: 1,
						cin: 1,
						fssaiNo: 1,
						isActive: 1,
					};
				}
				const unset = {};
				if ((values.isActive==null) || (values.isActive==undefined)) {
					if ((values.fssaiNo == null ) || (values.fssaiNo == undefined ) || (values.fssaiNo == "" )) {
						unset["fssaiNo"] = 1;
						delete values.fssaiNo;
					}
				}
				const updateObj = {$set: values};
				if (Object.keys(unset).length>0) {
					updateObj["$unset"] = unset;
				}
				const result = await ctx.mongo.collection("seller").findOneAndUpdate({
					_id: ctx.ObjectID(id),
				}, updateObj, {
					returnOriginal: false, projection: projection,
				});
				return {status: true, msg: "seller updated", doc: result.value};
			} catch (err) {
				return {status: false, msg: "encountered an unexpected error."};
			}
		},
		bulkCreate: async (docs) => {
			try {
				const bulk = ctx.mongo.collection("seller").initializeUnorderedBulkOp();
				const indexes = [];
				const messages = [];
				const outcome = [];
				let writeErrors = [];
				for (var loop = 0; loop < docs.length; loop++) {
					outcome.push("Record inserted successfully.");
					if (docs[loop].companyId) {
						docs[loop].companyId = ctx.ObjectID(docs[loop].companyId);
					}
					if (docs[loop].createdBy) {
						docs[loop].createdBy = ctx.ObjectID(docs[loop].createdBy);
					}
					if (docs[loop].updatedBy) {
						docs[loop].updatedBy = ctx.ObjectID(docs[loop].updatedBy);
					}
					bulk.insert(docs[loop]);
				}
				try {
					const result = await bulk.execute();
					writeErrors = result.getWriteErrors();
				} catch (err) {
					writeErrors = err.result.getWriteErrors();
				}
				if (writeErrors.length == 0) {
					return {status: true, msg: "OK", result: {outcome: outcome, successCount: outcome.length}};
				}
				const innerLength = indexes.length;
				for (let loop = 0, length = writeErrors.length; loop < length; loop++) {
					let matchFound = false;
					for (let innerLoop = 0; innerLoop < innerLength; innerLoop++) {
						if (writeErrors[loop].errmsg.indexOf(indexes[innerLoop]) >= 0) {
							outcome[writeErrors[loop].index] = messages[innerLoop];
							matchFound = true;
							break;
						}
					}
					if (!matchFound) {
						outcome[writeErrors[loop].index] = "Record not inserted.";
					}
				}
				return {status: true, msg: "OK", result: {outcome: outcome, successCount: (outcome.length - writeErrors.length)}};
			} catch (err) {
				return {status: false, msg: "encountered an unexpected error."};
			}
		},
		list: async (query, projection) => {
			try {
				if (!projection) {
					projection={
						name: 1,
						code: 1,
						mobile: 1,
						email: 1,
						contactPerson: 1,
						city: 1,
						state: 1,
						pincode: 1,
						address: 1,
						gstin: 1,
						cin: 1,
						fssaiNo: 1,
						isActive: 1,
					};
				}
				const docs = await ctx.mongo.collection("seller").find(query, {projection: projection}).toArray();
				return {status: true, msg: "Ok", docs: docs};
			} catch (err) {
				return {status: false, msg: "encountered an unexpected error."};
			}
		},
		details: async (query, projection) => {
			try {
				if (!projection) {
					projection={
						name: 1,
						code: 1,
						mobile: 1,
						email: 1,
						contactPerson: 1,
						city: 1,
						state: 1,
						pincode: 1,
						address: 1,
						gstin: 1,
						cin: 1,
						fssaiNo: 1,
						isActive: 1,
					};
				}
				const doc = await ctx.mongo.collection("seller").findOne(query, {projection: projection});
				return {status: true, msg: "Ok", doc: doc};
			} catch (err) {
				return {status: false, msg: "encountered an unexpected error."};
			}
		},
		listWithMarks: async () => {
			try {
				const docs = await ctx.mongo.collection("seller").aggregate([
					{$project: {name: 1, code: 1}},
					{$group: {_id: null, sellers: {$push: "$$ROOT"}}},
					{$lookup: {from: "mark", pipeline: [{$project: {name: 1, code: 1}}], as: "marks"}},
				]).toArray();
				if (docs.length!=1) {
					return {status: true, msg: "Ok", doc: {marks: [], sellers: []}};
				} else {
					return {status: true, msg: "Ok", doc: docs[0]};
				}
			} catch (err) {
				return {status: false, msg: "encountered an unexpected error."};
			}
		},
		_pendingMuster: async () => {
			try {
				const docs = await ctx.mongo.collection("seller").aggregate([
					{$project: {name: 1}},
					{$lookup: {from: "mark", let: {company_id: "$_id"}, pipeline: [
						{$match: {$expr: {$eq: ["$companyId", "$$company_id"]}}},
						{$project: {name: 1, code: 1, categoryId: 1, locationId: 1}},
					], as: "marks"}},
					{$lookup: {from: "muster", let: {company_id: "$_id"}, pipeline: [
						{$match: {$expr: {$and: [{$eq: ["$companyId", "$$company_id"]}, {$eq: ["$status", "PENDING"]}]}}},
						{$project: {assignedTo: 1, tastingDate: 1, createdAt: 1}},
						{$sort: {createdAt: 1}},
					], as: "samples"}},
					{$group: {_id: null, sellers: {$push: "$$ROOT"}}},
					{$lookup: {from: "grade", pipeline: [
						{$project: {code: 1, slno: 1}},
					], as: "grades"}},
					{$lookup: {from: "category", pipeline: [
						{$project: {code: 1}},
					], as: "categories"}},
					{$lookup: {from: "user", pipeline: [
						{$match: {companyId: ctx.ObjectID(global.hostCompanyId), userType: "Taster"}},
						{$project: {userName: 1, locationId: 1}},
					], as: "users"}},
				]).toArray();
				if (docs.length==1) {
					return {status: true, msg: "OK", doc: {sellers: docs[0].sellers, grades: docs[0].grades, categories: docs[0].categories, users: docs[0].users}};
				}
				return {status: true, msg: "Ok", doc: {sellers: [], grades: [], categories: [], users: []}};
			} catch (err) {
				return {status: false, msg: "encountered an unexpected error."};
			}
		},
		pendingMuster: async () => {
			try {
				const dt = new Date();
				const docs = await ctx.mongo.collection("sellermarkmapping").aggregate([
					{$match: {$and: [{dateFrom: {$lte: dt}}, {dateTo: {$gte: dt}}]}},
					{$sort: {dateFrom: 1}},
					{$group: {_id: "$mark", seller: {$first: "$seller"}}},
					{$group: {_id: "$seller", markIds: {$push: "$_id"}}},
					{$lookup: {from: "seller", let: {company_id: "$_id"}, pipeline: [
						{$match: {$expr: {$eq: ["$_id", "$$company_id"]}}},
						{$project: {name: 1, _id: 0}},
					], as: "seller"}},
					{$lookup: {from: "mark", let: {mark_ids: "$markIds"}, pipeline: [
						{$match: {$expr: {$in: ["$_id", "$$mark_ids"]}}},
						{$project: {name: 1, code: 1, category: 1, locationId: 1}},
					], as: "marks"}},
					{$lookup: {from: "muster", let: {mark_ids: "$markIds"}, pipeline: [
						{$match: {$expr: {$and: [{$in: ["$markId", "$$mark_ids"]}, {$eq: ["$status", "PENDING"]}]}}},
						{$project: {assignedTo: 1, tastingDate: 1, createdAt: 1}},
						{$sort: {createdAt: 1}},
					], as: "samples"}},
					{$group: {_id: null, sellers: {$push: "$$ROOT"}}},
					{$lookup: {from: "grade", pipeline: [
						{$project: {code: 1, slno: 1}},
					], as: "grades"}},
					{$lookup: {from: "category", pipeline: [
						{$project: {code: 1}},
					], as: "categories"}},
					{$lookup: {from: "user", pipeline: [
						{$match: {companyId: ctx.ObjectID(global.hostCompanyId), userType: "Taster"}},
						{$project: {userName: 1, locationId: 1}},
					], as: "users"}},
				]).toArray();
				if (docs.length==1) {
					return {status: true, msg: "OK", doc: {sellers: docs[0].sellers, grades: docs[0].grades, categories: docs[0].categories, users: docs[0].users}};
				}
				return {status: true, msg: "Ok", doc: {sellers: [], grades: [], categories: [], users: []}};
			} catch (err) {
				return {status: false, msg: "encountered an unexpected error."};
			}
		},
		infoWithMetadata: async (sellerId) => {
			try {
				const dt = new Date();
				const docs = await ctx.mongo.collection("seller").aggregate([
					{$match: {_id: ctx.ObjectID(sellerId)}},
					{$project: {_id: 1}},
					{$lookup: {from: "sellermarkmapping", let: {company_id: "$_id"}, pipeline: [
						{$match: {$expr: {$and: [{$lte: ["$dateFrom", dt]}, {$gte: ["$dateTo", dt]}, {$eq: ["$seller", "$$company_id"]}]}}},
						{$project: {_id: "$mark"}},
					], as: "marks"}},
					{$group: {_id: null, sellers: {$push: "$$ROOT"}}},
					{$lookup: {from: "grade", pipeline: [
						{$project: {code: 1, slno: 1}},
					], as: "grades"}},
					/* {$lookup: {from: "category", pipeline: [
						{$project: {code: 1}},
					], as: "categories"}}, */
				]).toArray();
				if (docs.length==1) {
					return {status: true, msg: "OK", doc: {sellers: docs[0].sellers, grades: docs[0].grades, categories: docs[0].categories}};
				}
				return {status: true, msg: "Ok", doc: {sellers: [], grades: []}};
			} catch (err) {
				return {status: false, msg: "encountered an unexpected error."};
			}
		},
		_listWithPendingMuster: async (userId) => {
			try {
				userId = ctx.ObjectID(userId);
				// const usr = await ctx.mongo.collection("user").findOne({_id: userId});
				/* let userLocation = "";
				if (usr.locationId) {
					userLocation = usr.locationId.toHexString();
				} */
				let docs = await ctx.mongo.collection("seller").aggregate([
					{$project: {name: 1, gstin: 1, emailId: 1, isActive: 1}},
					{$lookup: {from: "muster", let: {company_id: "$_id"}, pipeline: [
						{$match: {$expr: {$and: [{$eq: ["$companyId", "$$company_id"]}, {$eq: ["$status", "PENDING"]}, {$in: [userId, {$ifNull: ["$assignedTo", [userId]]}]}]}}},
						{$project: {markId: 1, createdAt: 1, tastingDate: 1, count: {$size: "$invoices"}}},
						{$sort: {createdAt: 1}},
					], as: "samples"}},
					{$lookup: {from: "mark", let: {company_id: "$_id"}, pipeline: [
						{$match: {$expr: {$eq: ["$companyId", "$$company_id"]}}},
						{$project: {name: 1, categoryId: 1, locationId: 1}},
					], as: "marks"}},
				]).toArray();
				const moment = require("moment");
				for (let loop=0, length = docs.length; loop<length; loop++) {
					const markMap = {};
					const _marks = [];
					for (let inner=0, innerLength = docs[loop].marks.length; inner<innerLength; inner++) {
						markMap[docs[loop].marks[inner]._id.toHexString()] = inner;
						_marks.push(docs[loop].marks[inner].name);
					}
					const _samples = [];
					// const _sampleIds = [];
					for (let inner=0, innerLength = docs[loop].samples.length; inner<innerLength; inner++) {
						const mark = docs[loop].marks[markMap[docs[loop].samples[inner].markId.toHexString()]];
						/* const location = mark.locationId.toHexString();
						if (userLocation && (userLocation != location)) {
							continue;
						} */
						docs[loop].samples[inner].categoryId = mark.categoryId;
						docs[loop].samples[inner].mark = mark.name;
						docs[loop].samples[inner].locationId = mark.locationId;
						docs[loop].samples[inner].createdAt = docs[loop].samples[inner].createdAt.getTime();
						if (docs[loop].samples[inner].tastingDate) {
							docs[loop].samples[inner].tastingDate = moment(docs[loop].samples[inner].tastingDate).format("ddd, MMM Do YYYY");
						} else {
							docs[loop].samples[inner].tastingDate = "Unassigned Tasting Date";
						}
						_samples.push(docs[loop].samples[inner]);
						// _sampleIds.push(docs[loop].samples[inner]._id);
					}
					docs[loop].marks = _marks;
					if (_samples.length==1) {
						_samples[0].selected = true;
					}
					docs[loop].samples = _samples;
					// docs[loop].sampleIds = _sampleIds;
					docs[loop].count = _samples.length;
				}
				const _ = require("lodash");
				docs = _.orderBy(docs, ["count", "name"], ["desc", "asc"]);
				return {status: true, msg: "Ok", docs: docs};
			} catch (err) {
				return {status: false, msg: "encountered an unexpected error."};
			}
		},
		listWithPendingMuster: async (userId) => {
			try {
				const dt = new Date();
				let docs = await ctx.mongo.collection("sellermarkmapping").aggregate([
					{$match: {$and: [{dateFrom: {$lte: dt}}, {dateTo: {$gte: dt}}]}},
					{$sort: {dateFrom: 1}},
					{$group: {_id: "$mark", seller: {$first: "$seller"}}},
					{$group: {_id: "$seller", markIds: {$push: "$_id"}}},
					{$lookup: {from: "seller", let: {company_id: "$_id"}, pipeline: [
						{$match: {$expr: {$eq: ["$_id", "$$company_id"]}}},
						{$project: {name: 1, gstin: 1, emailId: 1, isActive: 1}},
					], as: "seller"}},
					{$unwind: "$seller"},
					{$group: {_id: "$seller._id", name: {$first: "$seller.name"}, gstin: {$first: "$seller.gstin"}, emailId: {$first: "$seller.emailId"}, isActive: {$first: "$seller.isActive"}, markIds: {$first: "$markIds"}}},
					{$lookup: {from: "mark", let: {mark_ids: "$markIds"}, pipeline: [
						{$match: {$expr: {$in: ["$_id", "$$mark_ids"]}}},
						{$project: {name: 1, code: 1, category: 1, locationId: 1}},
					], as: "marks"}},
					{$lookup: {from: "muster", let: {mark_ids: "$markIds"}, pipeline: [
						{$match: {$expr: {$and: [{$in: ["$markId", "$$mark_ids"]}, {$eq: ["$status", "PENDING"]}]}}},
						{$project: {markId: 1, createdAt: 1, tastingDate: 1, count: {$size: "$invoices"}}},
						{$sort: {createdAt: 1}},
					], as: "samples"}},
				]).toArray();
				const moment = require("moment");
				for (let loop=0, length = docs.length; loop<length; loop++) {
					const markMap = {};
					const _marks = [];
					for (let inner=0, innerLength = docs[loop].marks.length; inner<innerLength; inner++) {
						markMap[docs[loop].marks[inner]._id.toHexString()] = inner;
						_marks.push(docs[loop].marks[inner].name);
					}
					const _samples = [];
					// const _sampleIds = [];
					for (let inner=0, innerLength = docs[loop].samples.length; inner<innerLength; inner++) {
						const mark = docs[loop].marks[markMap[docs[loop].samples[inner].markId.toHexString()]];
						/* const location = mark.locationId.toHexString();
						if (userLocation && (userLocation != location)) {
							continue;
						} */
						docs[loop].samples[inner].categoryId = mark.category;
						docs[loop].samples[inner].mark = mark.name;
						docs[loop].samples[inner].locationId = mark.locationId;
						docs[loop].samples[inner].createdAt = docs[loop].samples[inner].createdAt.getTime();
						if (docs[loop].samples[inner].tastingDate) {
							docs[loop].samples[inner].tastingDate = moment(docs[loop].samples[inner].tastingDate).format("ddd, MMM Do YYYY");
						} else {
							docs[loop].samples[inner].tastingDate = "Unassigned Tasting Date";
						}
						_samples.push(docs[loop].samples[inner]);
						// _sampleIds.push(docs[loop].samples[inner]._id);
					}
					docs[loop].marks = _marks;
					if (_samples.length==1) {
						_samples[0].selected = true;
					}
					docs[loop].samples = _samples;
					// docs[loop].sampleIds = _sampleIds;
					docs[loop].count = _samples.length;
					delete docs[loop].markIds;
				}
				const _ = require("lodash");
				docs = _.orderBy(docs, ["count", "name"], ["desc", "asc"]);
				return {status: true, msg: "Ok", docs: docs};
			} catch (err) {
				return {status: false, msg: "encountered an unexpected error."};
			}
		},
		_listWithMarks: async () => {
			try {
				const docs = await ctx.mongo.collection("seller").aggregate([
					{$project: {name: 1, gstin: 1, emailId: 1, isActive: 1}},
					{$lookup: {from: "mark", let: {company_id: "$_id"}, pipeline: [
						{$match: {$expr: {$eq: ["$companyId", "$$company_id"]}}},
						{$project: {name: 1, categoryId: 1, locationId: 1}},
					], as: "marks"}},
				]).toArray();
				return {status: true, msg: "Ok", docs: docs};
			} catch (err) {
				return {status: false, msg: "encountered an unexpected error."};
			}
		},
		listAssignedMarks: async (dt) => {
			if (!dt) {
				dt = new Date();
			}
			try {
				const docs = await ctx.mongo.collection("sellermarkmapping").aggregate([
					{$match: {$and: [{dateFrom: {$lte: dt}}, {dateTo: {$gte: dt}}]}},
					{$sort: {dateFrom: 1}},
					{$group: {_id: "$mark", seller: {$first: "$seller"}}},
					{$group: {_id: "$seller", marks: {$push: "$_id"}}},
				]).toArray();
				return {status: true, msg: "Ok", docs: docs};
			} catch (err) {
				return {status: false, msg: "encountered an unexpected error."};
			}
		},
		serialize: (docs) => {
			try {
				for (let loop=0, length=docs.length; loop<length; loop++) {
					if (docs[loop]["createdAt"]) {
						docs[loop]["createdAt"] = docs[loop]["createdAt"].getTime();
					}
					if (docs[loop]["updatedAt"]) {
						docs[loop]["updatedAt"] = docs[loop]["updatedAt"].getTime();
					}
				}
				return {status: true, msg: "Ok", docs: docs};
			} catch (err) {
				return {status: false, msg: "encountered an unexpected error."};
			}
		},
		deserialize: (docs) => {
			try {
				for (let loop=0, length=docs.length; loop<length; loop++) {
					if (docs[loop]["createdAt"]) {
						docs[loop]["createdAt"] = new Date(docs[loop]["createdAt"]);
					}
					if (docs[loop]["updatedAt"]) {
						docs[loop]["updatedAt"] = new Date(docs[loop]["updatedAt"]);
					}
				}
				return {status: true, msg: "Ok", docs: docs};
			} catch (err) {
				return {status: false, msg: "encountered an unexpected error."};
			}
		},
	};
};
