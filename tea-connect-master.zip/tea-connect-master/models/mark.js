module.exports = (ctx) => {
	return {
		attributes: {
			name: {
				type: "STRING",
				min: 2,
				max: 80,
				transform: "TITLECASE",
				label: "Garden Name",
			},
			code: {
				type: "STRING",
				min: 1,
				max: 10,
				transform: "UPPERCASE",
				label: "Garden Code",
			},
			type: {
				type: "STRING",
				min: 1,
				max: 1,
				transform: "UPPERCASE",
			},
			locationId: {
				type: "OBJECTID",
				label: "Location",
			},
			region: {
				type: "STRING",
				min: 1,
				max: 20,
				transform: "TITLECASE",
				label: "Tea Region",
			},
			address: {
				type: "STRING",
				min: 1,
				max: 100,
				transform: "TITLECASE",
			},
			latitude: {
				type: "NUMBER",
				nullable: true,
			},
			longitude: {
				type: "NUMBER",
				nullable: true,
			},
			category: {
				type: "OBJECTID",
				label: "Tea Category",
			},
			annualProduction: {
				type: "NUMBER",
				nullable: true,
				label: "Annual Production",
			},
			ctmNo: {
				type: "STRING",
				nullable: true,
				label: "CTM No",
			},
			haccp: {
				type: "BOOLEAN",
				label: "HACCP",
			},
			haccpDate: {
				type: "DATE",
				label: "HACCP Date",
				nullable: true,
			},
			trustea: {
				type: "BOOLEAN",
				label: "Trustea",
			},
			trusteaValidUpto: {
				type: "DATE",
				label: "Trustea Valid Upto",
				nullable: true,
			},
			rainforest: {
				type: "BOOLEAN",
				label: "Rainforest",
			},
			raValidUpto: {
				type: "DATE",
				label: "RA Valid Upto",
				nullable: true,
			},
			gardenISO: {
				type: "STRING",
				nullable: true,
				label: "Garden ISO",
			},
			gardenISOValidUpto: {
				type: "DATE",
				label: "Garden ISO Valid Upto",
				nullable: true,
			},
			fssalNo: {
				label: "FSSAI No",
			},
			fssaiValidDate: {
				type: "DATE",
				label: "Fssai Valid Date",
			},
			organic: {
				type: "BOOLEAN",
			},
			teaBoardRegNo: {
				type: "STRING",
				label: "Tea Board Registration No",
			},
			gardenAdvance: {
				type: "BOOLEAN",
				label: "Garden Advance",
			},
		},
		metadata: {
			name: "mark",
			plural: "marks",
			collection: "mark",
		},
		create: async (input) => {
			try {
				if (!input._id) {
					input._id = new ctx.ObjectID();
				}
				if (input.companyId) {
					input.companyId = ctx.ObjectID(input.companyId);
				}
				if (input.createdBy) {
					input.createdBy = ctx.ObjectID(input.createdBy);
				}
				if (input.updatedBy) {
					input.updatedBy = ctx.ObjectID(input.updatedBy);
				}
				if (input.locationId) {
					input.locationId = ctx.ObjectID(input.locationId);
				}
				if (input.category) {
					input.category = ctx.ObjectID(input.category);
				}
				await ctx.mongo.collection("mark").insertOne(input);
				return {status: true, msg: "mark created", doc: input};
			} catch (err) {
				return {status: false, msg: "encountered an unexpected error."};
			}
		},
		update: async (id, values, projection) => {
			try {
				if (!projection) {
					projection={
						name: 1,
						code: 1,
						type: 1,
						locationId: 1,
						region: 1,
						address: 1,
						latitude: 1,
						longitude: 1,
						category: 1,
						annualProduction: 1,
						ctmNo: 1,
						haccp: 1,
						haccpDate: 1,
						trustea: 1,
						trusteaValidUpto: 1,
						rainforest: 1,
						raValidUpto: 1,
						gardenISO: 1,
						gardenISOValidUpto: 1,
						fssalNo: 1,
						fssaiValidDate: 1,
						organic: 1,
						teaBoardRegNo: 1,
						gardenAdvance: 1,
						isActive: 1,
					};
				}
				if (values.companyId) {
					values.companyId = ctx.ObjectID(values.companyId);
				}
				if (values.createdBy) {
					values.createdBy = ctx.ObjectID(values.createdBy);
				}
				if (values.updatedBy) {
					values.updatedBy = ctx.ObjectID(values.updatedBy);
				}
				if (values.locationId) {
					values.locationId = ctx.ObjectID(values.locationId);
				}
				if (values.category) {
					values.category = ctx.ObjectID(values.category);
				}
				const unset = {};
				if ((values.isActive==null) || (values.isActive==undefined)) {
					if ((values.latitude == null ) || (values.latitude == undefined ) || (values.latitude == "" )) {
						unset["latitude"] = 1;
						delete values.latitude;
					}
					if ((values.longitude == null ) || (values.longitude == undefined ) || (values.longitude == "" )) {
						unset["longitude"] = 1;
						delete values.longitude;
					}
					if ((values.annualProduction == null ) || (values.annualProduction == undefined ) || (values.annualProduction == "" )) {
						unset["annualProduction"] = 1;
						delete values.annualProduction;
					}
					if ((values.ctmNo == null ) || (values.ctmNo == undefined ) || (values.ctmNo == "" )) {
						unset["ctmNo"] = 1;
						delete values.ctmNo;
					}
					if ((values.haccpDate == null ) || (values.haccpDate == undefined ) || (values.haccpDate == "" )) {
						unset["haccpDate"] = 1;
						delete values.haccpDate;
					}
					if ((values.trusteaValidUpto == null ) || (values.trusteaValidUpto == undefined ) || (values.trusteaValidUpto == "" )) {
						unset["trusteaValidUpto"] = 1;
						delete values.trusteaValidUpto;
					}
					if ((values.raValidUpto == null ) || (values.raValidUpto == undefined ) || (values.raValidUpto == "" )) {
						unset["raValidUpto"] = 1;
						delete values.raValidUpto;
					}
					if ((values.gardenISO == null ) || (values.gardenISO == undefined ) || (values.gardenISO == "" )) {
						unset["gardenISO"] = 1;
						delete values.gardenISO;
					}
					if ((values.gardenISOValidUpto == null ) || (values.gardenISOValidUpto == undefined ) || (values.gardenISOValidUpto == "" )) {
						unset["gardenISOValidUpto"] = 1;
						delete values.gardenISOValidUpto;
					}
				}
				const updateObj = {$set: values};
				if (Object.keys(unset).length>0) {
					updateObj["$unset"] = unset;
				}
				const result = await ctx.mongo.collection("mark").findOneAndUpdate({
					_id: ctx.ObjectID(id),
				}, updateObj, {
					returnOriginal: false, projection: projection,
				});
				return {status: true, msg: "mark updated", doc: result.value};
			} catch (err) {
				return {status: false, msg: "encountered an unexpected error."};
			}
		},
		bulkCreate: async (docs) => {
			try {
				const bulk = ctx.mongo.collection("mark").initializeUnorderedBulkOp();
				const indexes = [];
				const messages = [];
				const outcome = [];
				let writeErrors = [];
				for (var loop = 0; loop < docs.length; loop++) {
					outcome.push("Record inserted successfully.");
					if (docs[loop].companyId) {
						docs[loop].companyId = ctx.ObjectID(docs[loop].companyId);
					}
					if (docs[loop].createdBy) {
						docs[loop].createdBy = ctx.ObjectID(docs[loop].createdBy);
					}
					if (docs[loop].updatedBy) {
						docs[loop].updatedBy = ctx.ObjectID(docs[loop].updatedBy);
					}
					bulk.insert(docs[loop]);
				}
				try {
					const result = await bulk.execute();
					writeErrors = result.getWriteErrors();
				} catch (err) {
					writeErrors = err.result.getWriteErrors();
				}
				if (writeErrors.length == 0) {
					return {status: true, msg: "OK", result: {outcome: outcome, successCount: outcome.length}};
				}
				const innerLength = indexes.length;
				for (let loop = 0, length = writeErrors.length; loop < length; loop++) {
					let matchFound = false;
					for (let innerLoop = 0; innerLoop < innerLength; innerLoop++) {
						if (writeErrors[loop].errmsg.indexOf(indexes[innerLoop]) >= 0) {
							outcome[writeErrors[loop].index] = messages[innerLoop];
							matchFound = true;
							break;
						}
					}
					if (!matchFound) {
						outcome[writeErrors[loop].index] = "Record not inserted.";
					}
				}
				return {status: true, msg: "OK", result: {outcome: outcome, successCount: (outcome.length - writeErrors.length)}};
			} catch (err) {
				return {status: false, msg: "encountered an unexpected error."};
			}
		},
		list: async (query, projection) => {
			try {
				if (!projection) {
					projection={
						name: 1,
						code: 1,
						type: 1,
						locationId: 1,
						region: 1,
						address: 1,
						latitude: 1,
						longitude: 1,
						category: 1,
						annualProduction: 1,
						ctmNo: 1,
						haccp: 1,
						haccpDate: 1,
						trustea: 1,
						trusteaValidUpto: 1,
						rainforest: 1,
						raValidUpto: 1,
						gardenISO: 1,
						gardenISOValidUpto: 1,
						fssalNo: 1,
						fssaiValidDate: 1,
						organic: 1,
						teaBoardRegNo: 1,
						gardenAdvance: 1,
						isActive: 1,
					};
				}
				const docs = await ctx.mongo.collection("mark").find(query, {projection: projection}).toArray();
				return {status: true, msg: "Ok", docs: docs};
			} catch (err) {
				return {status: false, msg: "encountered an unexpected error."};
			}
		},
		listWithSellers: async () => {
			try {
				const docs = await ctx.mongo.collection("mark").aggregate([
					{$project: {name: 1, code: 1}},
					{$group: {_id: null, marks: {$push: "$$ROOT"}}},
					{$lookup: {from: "seller", pipeline: [
						{$project: {name: 1}},
					], as: "sellers"}},
				]).toArray();
				if (docs.length !=1) {
					return {status: true, msg: "Ok", doc: {marks: [], sellers: []}};
				}
				return {status: true, msg: "Ok", doc: docs[0]};
			} catch (err) {
				return {status: false, msg: "encountered an unexpected error."};
			}
		},
		details: async (query, projection) => {
			try {
				if (!projection) {
					projection={
						name: 1,
						code: 1,
						type: 1,
						locationId: 1,
						region: 1,
						address: 1,
						latitude: 1,
						longitude: 1,
						category: 1,
						annualProduction: 1,
						ctmNo: 1,
						haccp: 1,
						haccpDate: 1,
						trustea: 1,
						trusteaValidUpto: 1,
						rainforest: 1,
						raValidUpto: 1,
						gardenISO: 1,
						gardenISOValidUpto: 1,
						fssalNo: 1,
						fssaiValidDate: 1,
						organic: 1,
						teaBoardRegNo: 1,
						gardenAdvance: 1,
						isActive: 1,
					};
				}
				const doc = await ctx.mongo.collection("mark").findOne(query, {projection: projection});
				return {status: true, msg: "Ok", doc: doc};
			} catch (err) {
				return {status: false, msg: "encountered an unexpected error."};
			}
		},
		listDependencies: async (query) => {
			try {
				const docs = await ctx.mongo.collection("client").aggregate([
					{$project: {name: 1, code: 1}},
					{$group: {_id: null, clients: {$push: "$$ROOT"}}},
					{$lookup: {from: "category", pipeline: [{$project: {name: 1, code: 1}}], as: "categories"}},
					{$lookup: {from: "location", pipeline: [{$project: {name: 1, code: 1}}], as: "locations"}},
				]).toArray();
				if (docs.length!=1) {
					return {status: true, msg: "Ok", doc: {clients: [], categories: [], locations: []}};
				} else {
					return {status: true, msg: "Ok", doc: docs[0]};
				}
			} catch (err) {
				return {status: false, msg: "encountered an unexpected error."};
			}
		},
		listWithGrades: async () => {
			try {
				const docs = await ctx.mongo.collection("mark").aggregate([
					{$project: {name: 1, code: 1, categoryId: 1, companyId: 1}},
					{$group: {_id: null, marks: {$push: "$$ROOT"}}},
					{$lookup: {from: "grade", pipeline: [
						{$project: {code: 1, slno: 1}},
					], as: "grades"}},
				]).toArray();
				if (docs.length==1) {
					return {status: true, msg: "OK", doc: {marks: docs[0].marks, grades: docs[0].grades}};
				}
				return {status: true, msg: "Ok", doc: {marks: [], grades: []}};
			} catch (err) {
				return {status: false, msg: "encountered an unexpected error."};
			}
		},
		listWithLocations: async () => {
			try {
				const docs = await ctx.mongo.collection("mark").aggregate([
					{$project: {name: 1, code: 1, categoryId: 1, companyId: 1}},
					{$group: {_id: null, marks: {$push: "$$ROOT"}}},
					{$lookup: {from: "location", pipeline: [
						{$project: {name: 1}},
					], as: "locations"}},
				]).toArray();
				if (docs.length==1) {
					return {status: true, msg: "OK", doc: {marks: docs[0].marks, locations: docs[0].locations}};
				}
				return {status: true, msg: "Ok", doc: {marks: [], locations: []}};
			} catch (err) {
				return {status: false, msg: "encountered an unexpected error."};
			}
		},
		listWithAuctionCenterAndLocations: async () => {
			try {
				const docs = await ctx.mongo.collection("mark").aggregate([
					{$project: {name: 1, code: 1, categoryId: 1, companyId: 1}},
					{$group: {_id: null, marks: {$push: "$$ROOT"}}},
					{$lookup: {from: "location", pipeline: [
						{$project: {name: 1, code: 1}},
					], as: "locations"}},
					{$lookup: {from: "auctioncenter", pipeline: [
						{$project: {name: 1, code: 1}},
					], as: "centers"}},
				]).toArray();
				if (docs.length==1) {
					return {status: true, msg: "OK", doc: {marks: docs[0].marks, locations: docs[0].locations, centers: docs[0].centers}};
				}
				return {status: true, msg: "Ok", doc: {marks: [], locations: [], centers: []}};
			} catch (err) {
				return {status: false, msg: "encountered an unexpected error."};
			}
		},
		serialize: (docs) => {
			try {
				for (let loop=0, length=docs.length; loop<length; loop++) {
					if (docs[loop]["haccpDate"]) {
						docs[loop]["haccpDate"] = docs[loop]["haccpDate"].getTime();
					}
					if (docs[loop]["trusteaValidUpto"]) {
						docs[loop]["trusteaValidUpto"] = docs[loop]["trusteaValidUpto"].getTime();
					}
					if (docs[loop]["raValidUpto"]) {
						docs[loop]["raValidUpto"] = docs[loop]["raValidUpto"].getTime();
					}
					if (docs[loop]["gardenISOValidUpto"]) {
						docs[loop]["gardenISOValidUpto"] = docs[loop]["gardenISOValidUpto"].getTime();
					}
					if (docs[loop]["fssaiValidDate"]) {
						docs[loop]["fssaiValidDate"] = docs[loop]["fssaiValidDate"].getTime();
					}
					if (docs[loop]["createdAt"]) {
						docs[loop]["createdAt"] = docs[loop]["createdAt"].getTime();
					}
					if (docs[loop]["updatedAt"]) {
						docs[loop]["updatedAt"] = docs[loop]["updatedAt"].getTime();
					}
				}
				return {status: true, msg: "Ok", docs: docs};
			} catch (err) {
				return {status: false, msg: "encountered an unexpected error."};
			}
		},
		deserialize: (docs) => {
			try {
				for (let loop=0, length=docs.length; loop<length; loop++) {
					if (docs[loop]["haccpDate"]) {
						docs[loop]["haccpDate"] = new Date(docs[loop]["haccpDate"]);
					}
					if (docs[loop]["trusteaValidUpto"]) {
						docs[loop]["trusteaValidUpto"] = new Date(docs[loop]["trusteaValidUpto"]);
					}
					if (docs[loop]["raValidUpto"]) {
						docs[loop]["raValidUpto"] = new Date(docs[loop]["raValidUpto"]);
					}
					if (docs[loop]["gardenISOValidUpto"]) {
						docs[loop]["gardenISOValidUpto"] = new Date(docs[loop]["gardenISOValidUpto"]);
					}
					if (docs[loop]["fssaiValidDate"]) {
						docs[loop]["fssaiValidDate"] = new Date(docs[loop]["fssaiValidDate"]);
					}
					if (docs[loop]["createdAt"]) {
						docs[loop]["createdAt"] = new Date(docs[loop]["createdAt"]);
					}
					if (docs[loop]["updatedAt"]) {
						docs[loop]["updatedAt"] = new Date(docs[loop]["updatedAt"]);
					}
				}
				return {status: true, msg: "Ok", docs: docs};
			} catch (err) {
				return {status: false, msg: "encountered an unexpected error."};
			}
		},
	};
};
