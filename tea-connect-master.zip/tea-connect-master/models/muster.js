module.exports = (ctx) => {
	return {
		update: async (input) => {
			try {
				if (!input._id) {
					input._id = new ctx.ObjectID();
					/* let season = null;
					let month = null;
					if (input.createdAt) {
						season = input.createdAt.getFullYear();
						month = input.createdAt.getMonth();
					} else {
						const dt = new Date();
						season = dt.getFullYear();
						month = dt.getMonth();
					}
					if (month<1) {
						season --;
					}
					input.season = season; */
				} else {
					input._id = ctx.ObjectID(input._id);
				}
				if (input.companyId) {
					input.companyId = ctx.ObjectID(input.companyId);
				}
				if (input.markId) {
					input.markId = ctx.ObjectID(input.markId);
				}
				if (input.createdBy) {
					input.createdBy = ctx.ObjectID(input.createdBy);
				}
				if (input.updatedBy) {
					input.updatedBy = ctx.ObjectID(input.updatedBy);
				}
				await ctx.mongo.collection("muster").findOneAndUpdate({_id: input._id}, {$set: input}, {upsert: true});
				delete input.companyId;
				// delete input.createdAt;
				delete input.updatedAt;
				delete input.createdBy;
				delete input.updatedBy;
				// delete input.invoices;
				return {status: true, msg: "Ok", doc: input};
			} catch (err) {
				const errMsg = "Encountered an unexpected error.";
				return {status: false, msg: errMsg};
			}
		},
		list: async (query, projection) => {
			if (!projection) {
				projection = {createdAt: 1, assignedTo: 1, tastingDate: 1, markId: 1};
			}
			try {
				const docs = await ctx.mongo.collection("muster").find(query, {projection: projection}).toArray();
				return {status: true, msg: "Ok", docs: docs};
			} catch (err) {
				const errMsg = "Encountered an unexpected error.";
				return {status: false, msg: errMsg};
			}
		},
		listPendingForClient: async (clientId) => {
			try {
				const docs = await ctx.mongo.collection("muster").find({companyId: ctx.ObjectID(clientId), status: "PENDING"}, {projection: {createdAt: 1, assignedTo: 1, tastingDate: 1, markId: 1}}).toArray();
				return {status: true, msg: "Ok", docs: docs};
			} catch (err) {
				const errMsg = "Encountered an unexpected error.";
				return {status: false, msg: errMsg};
			}
		},
		details: async (musterId) => {
			try {
				const docs = await ctx.mongo.collection("muster").aggregate([
					{$match: {_id: ctx.ObjectID(musterId)}},
					{$project: {"companyId": 1, "markId": 1, "invoices.id": 1}},
					{$unwind: "$invoices"},
					{$group: {_id: "$_id", companyId: {$first: "$companyId"}, markId: {$first: "$markId"}, invoices: {$push: "$invoices.id"}}},
					{$lookup: {from: "invoices", let: {invoices: "$invoices"}, pipeline: [{
						$match: {$expr: {$in: ["$_id", "$$invoices"]}}}, {
						$project: {markId: 1, gradeId: 1, noOfPkg: 1, mfgDate: 1, invNo: 1, _invNo: 1, netPerPkg: 1, _id: 0}}], as: "invoices"}},
				]).toArray();
				if (docs.length != 1) {
					return {status: false, msg: "Record not found", doc: null};
				}
				return {status: true, msg: "Ok", doc: docs[0]};
			} catch (err) {
				const errMsg = "Encountered an unexpected error.";
				return {status: false, msg: errMsg};
			}
		},
		updateAssignment: async (musterId, tastingDate, assignedTo, userId) => {
			try {
				for (let loop=0, length = assignedTo.length; loop<length; loop++) {
					assignedTo[loop] = ctx.ObjectID(assignedTo[loop]);
				}
				const users = await ctx.mongo.collection("user").find({_id: {$in: assignedTo}}, {projection: {_id: 1}}).toArray();
				if (users.length != assignedTo.length) {
					return {status: false, msg: "Invalid assignee"};
				}
				await ctx.mongo.collection("muster").findOneAndUpdate({_id: ctx.ObjectID(musterId)}, {$set: {assignedTo: assignedTo, tastingDate: tastingDate, updatedAt: new Date(), updatedBy: ctx.ObjectID(userId)}});
				return {status: true, msg: "Ok"};
			} catch (err) {
				const errMsg = "Encountered an unexpected error.";
				return {status: false, msg: errMsg};
			}
		},
		listWithDetails: async (ids) => {
			try {
				for (let loop=0, length = ids.length; loop<length; loop++) {
					ids[loop] = ctx.ObjectID(ids[loop]);
				}
				const docs = await ctx.mongo.collection("muster").aggregate([
					{$match: {_id: {$in: ids}, status: "PENDING"}},
					{$project: {"markId": 1, "invoices": 1}},
					{$unwind: "$invoices"},
					{$group: {_id: null, ids: {$push: "$invoices.id"}}},
					{$lookup: {from: "invoices", let: {invoices: "$ids"}, pipeline: [{
						$match: {$expr: {$in: ["$_id", "$$invoices"]}}}, {
						$project: {markId: 1, gradeId: 1, noOfPkg: 1, invNo: 1, _invNo: 1, netPerPkg: 1, mfgDate: 1, season: 1}}, {$sort: {invNo: 1}}], as: "invoices2"}},
				]).toArray();
				if (docs.length != 1) {
					return {status: false, msg: "Record not found", doc: null};
				}
				const doc = docs[0];
				const _ = require("lodash");
				doc.invoices2 = _.sortBy(doc.invoices2, ["_invNo"]);
				return {status: true, msg: "Ok", docs: doc.invoices2};
			} catch (err) {
				const errMsg = "Encountered an unexpected error.";
				return {status: false, msg: errMsg};
			}
		},
		serialize: (docs) => {
			try {
				for (let loop=0, length=docs.length; loop<length; loop++) {
					if (docs[loop]["tastingDate"]) {
						docs[loop]["tastingDate"] = docs[loop]["tastingDate"].getTime();
					}
					if (docs[loop]["createdAt"]) {
						docs[loop]["createdAt"] = docs[loop]["createdAt"].getTime();
					}
					if (docs[loop]["updatedAt"]) {
						docs[loop]["updatedAt"] = docs[loop]["updatedAt"].getTime();
					}
					if (docs[loop]["tastedAt"]) {
						docs[loop]["tastedAt"] = docs[loop]["tastedAt"].getTime();
					}
				}
				return {status: true, msg: "Ok", docs: docs};
			} catch (err) {
				return {status: false, msg: "encountered an unexpected error."};
			}
		},
		deserialize: (docs) => {
			try {
				for (let loop=0, length=docs.length; loop<length; loop++) {
					if (docs[loop]["tastingDate"]) {
						docs[loop]["tastingDate"] = new Date(docs[loop]["tastingDate"]);
					}
					if (docs[loop]["createdAt"]) {
						docs[loop]["createdAt"] = new Date(docs[loop]["createdAt"]);
					}
					if (docs[loop]["updatedAt"]) {
						docs[loop]["updatedAt"] = new Date(docs[loop]["updatedAt"]);
					}
					if (docs[loop]["tastedAt"]) {
						docs[loop]["tastedAt"] = new Date(docs[loop]["tastedAt"]);
					}
				}
				return {status: true, msg: "Ok", docs: docs};
			} catch (err) {
				return {status: false, msg: "encountered an unexpected error."};
			}
		},
	};
};
