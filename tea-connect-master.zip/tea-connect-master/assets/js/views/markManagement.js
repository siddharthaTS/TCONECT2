
/* global marks locations categories:true*/
/* eslint no-global-assign:0 */

app.config(["$stateProvider", "$urlRouterProvider", "$locationProvider", function($stateProvider, $urlRouterProvider, $locationProvider) {
	$urlRouterProvider.otherwise("/list");
	$stateProvider
		.state("list", {
			onEnter: function() {
				$(".inner-nav-menu").find("a").removeClass("active");
				$(".inner-nav-menu-list").addClass("active");
			},
			views: {
				"main": {
					templateUrl: "/list.tpl.html",
					controller: "markController",
				},
			},
			url: "/list",
		})
		.state("create", {
			onEnter: function() {
				$(".inner-nav-menu").find("a").removeClass("active");
				$(".inner-nav-menu-create").addClass("active");
			},
			views: {
				"main": {
					templateUrl: "/create.tpl.html",
					controller: "markController",
				},
			},
			url: "/create",
		})
		.state("update", {
			onEnter: function() {
				$(".inner-nav-menu").find("a").removeClass("active");
				$(".inner-nav-menu-update").addClass("active");
			},
			views: {
				"main": {
					templateUrl: "/update.tpl.html",
					controller: "markController",
				},
			},
			url: "/update?markid",
		});
}]);
var currentState = null;
var currentParams = null;
app.run(["$rootScope", "$state", "$location", "$window", function run($rootScope, $state, $location, $window) {
	$rootScope.$on("$stateChangeStart", function(e, toState, toParams, fromState, fromParams) {
	//
	});
	$rootScope.$on("$stateChangeError", function(event, toState, toParams, fromState, fromParams, error) {
	//
	});
	$rootScope.$on("$stateChangeSuccess", function(event, toState, toParams, fromState, fromParams) {
		currentState = toState;
		currentParams = toParams;
	});
	$rootScope.$on("$viewContentLoaded", function(e, toState, toParams, fromState, fromParams) {
		if (currentState && ["update"].indexOf(currentState.name) >= 0) {
			$("#mark_selection").dropdown({forceSelection: false});
			$("#mark_selection").dropdown("setting", "onChange", function(val) {
				setTimeout(function() {
					$("#proxy-mark-change").click();
				}, 200);
			});
			setTimeout(function() {
				if (currentParams.markid) {
					$("#mark_selection").dropdown("set selected", currentParams.markid);
				}
			}, 300);
		}
		if (currentState && ["create"].indexOf(currentState.name) >= 0) {
			$(".create-mark-tabs .item").tab();
			holder = document.getElementById("holder");
			holder.ondragover = function() {
				$(this).addClass("div_drag_hover");
				return false;
			};
			holder.ondragend = function() {
				$(this).removeClass("div_drag_hover");
				return false;
			};
			holder.ondrop = function(e) {
				$(this).removeClass("div_drag_hover");
				e.preventDefault();
				processFileForUpload(e);
			};
			setTimeout(function() {
				$(".boolean-field").checkbox();
				$("input.datepicker").each(function(idx, ele) {
					$(ele).daterangepicker({
						format: "DD MMM YYYY",
						singleDatePicker: true,
						showDropdowns: true,
						startDate: moment(),
					},
					function(start, end, label) {
						$(ele).attr("data-value", start.toDate().getTime());
					});
				});
			}, 500);
		}
	});
}]);

var locationMap = {};
var categoryMap = {};

app.controller("markController", ["$scope", "$rootScope", "$stateParams", "dataFactory", "$state", "$timeout", function($scope, $rootScope, $stateParams, dataFactory, $state, $timeout) {
	$scope.marks = marks;
	$scope.locations = locations;
	$scope.categories = categories;
	$scope.currentMark = {isActive: true};
	$scope.currentMarkOrg = {isActive: true};
	$scope.marksUnderProcessing = {};


	$scope.markChanged = function() {
		var markId = $("#mark_selection input").val();
		if (markId.length > 1) {
			if ($state.current.name == "update") {
				var posInMarks = _.findIndex($scope.marks, ["_id", markId]);
				if (posInMarks > -1) {
					$scope.currentMark = JSON.parse(JSON.stringify($scope.marks[posInMarks]));
					$scope.currentMarkOrg = JSON.parse(JSON.stringify($scope.marks[posInMarks]));
					$(".datepicker").each(function(idx, ele) {
						try {
							$(ele).attr("data-value", $scope.currentMark[$(ele).attr("name")]);
							var tmpMoment = moment($scope.currentMark[$(ele).attr("name")]);
							$(ele).val(tmpMoment.format("DD MMM YYYY"));
							$(ele).daterangepicker({
								format: "DD MMM YYYY",
								singleDatePicker: true,
								showDropdowns: true,
								startDate: tmpMoment,
							},
							function(start, end, label) {
								$(ele).attr("data-value", start.toDate().getTime());
							});
						} catch (e) {
							//
						}
					});
					$(".boolean-field").checkbox("uncheck");
					$(".boolean-field").each(function(idx, ele) {
						try {
							if ($scope.currentMark[$(ele).attr("data-field-name")]) {
								$(ele).checkbox("check");
							}
						} catch (e) {
							//
						}
					});
					$("#submit_update_mark").removeClass("disabled");
					$("#reset_update_mark").removeClass("disabled");
				}
			}
		}
	};

	$scope.navUpdate = function(mark) {
		$state.go("update", {markid: mark._id});
	};

	$scope.submitUpdateMark = function() {
		var parsleyHandle = $("#marks_form").parsley();
		parsleyHandle.validate();
		if (parsleyHandle.isValid()) {
			$("#submit_update_mark").addClass("loading disabled");
			$("#reset_update_mark").addClass("disabled");
			$scope.loadDateAndBooleanFields();
			var _tmp = JSON.parse(JSON.stringify($scope.currentMark));
			delete _tmp.isActive;
			var payload = {
				find: $("#mark_selection input").val(),
				update: _tmp,
			};
			dataFactory.post("update-mark.json", payload).then(function(data) {
				$("#submit_update_mark").removeClass("loading disabled");
				$("#reset_update_mark").removeClass("disabled");
				if (data.status) {
					dataFactory.toastSuccess("Mark updated successfully");
					var posInMarks = _.findIndex(marks, ["_id", $("#mark_selection input").val()]);
					if (posInMarks >= 0) {
						marks[posInMarks] = data.doc;
						$scope.marks = marks;
						$scope.currentMarkOrg = JSON.parse(JSON.stringify(data.doc));
					}
				} else {
					dataFactory.toastError(data.msg);
				}
			}, function() {
				dataFactory.toastError("we have encounterd an unexpected error, plesae try after some time.");
				$("#submit_update_mark").removeClass("loading disabled");
				$("#reset_update_mark").removeClass("disabled");
			});
		}
	};

	$scope.resetUpdateMark = function() {
		$scope.currentMark = JSON.parse(JSON.stringify($scope.currentMarkOrg));
	};

	$scope.setEnableddisabled = function(mark) {
		if ($scope.marksUnderProcessing[mark._id]) {
			return;
		}
		$scope.marksUnderProcessing[mark._id] = true;
		$("." + mark._id).parent().parent().find(".notched.circle.loading").css("visibility", "visible");
		$("." + mark._id).checkbox();
		var payload = {
			find: mark._id,
			update: {isActive: (!mark.isActive)},
		};
		dataFactory.post("update-mark.json", payload).then(function(data) {
			if (data.status) {
				mark.isActive = data.doc.isActive;
				$timeout(function() {
					if (mark.isActive) {
						$("." + mark._id).checkbox("check");
					} else {
						$("." + mark._id).checkbox("uncheck");
					}
					$("." + mark._id).parent().parent().find(".notched.circle.loading").css("visibility", "hidden");
				}, 200);
			} else {
				$("." + mark._id).parent().parent().find(".notched.circle.loading").css("visibility", "hidden");
				dataFactory.toastError(data.msg);
			}
			$scope.marksUnderProcessing[mark._id] = false;
		}, function() {
			$("." + mark._id).parent().parent().find(".notched.circle.loading").hide();
			dataFactory.toastError("we have encounterd an unexpected error, plesae try after some time.");
			$scope.marksUnderProcessing[mark._id] = false;
		});
	};

	$scope.submitCreateMark = function() {
		var parsleyHandle = $("#marks_form").parsley();
		parsleyHandle.validate();
		var additionalValidations = true;
		if (parsleyHandle.isValid() && additionalValidations) {
			$("#submit_create_mark").addClass("loading disabled");
			$("#reset_create_mark").addClass("disabled");
			$scope.loadDateAndBooleanFields();
			dataFactory.post("create-mark.json", $scope.currentMark).then(function(data) {
				$("#submit_create_mark").removeClass("loading disabled");
				$("#reset_create_mark").addClass("disabled");
				if (data.status) {
					marks.push(data.doc);
					$scope.marks = marks;
					$scope.clearCreateMark();
					dataFactory.toastSuccess("Mark created successfully");
				} else {
					dataFactory.toastError(data.msg);
				}
			}, function() {
				dataFactory.toastError("we have encounterd an unexpected error, plesae try after some time.");
				$("#submit_create_mark").removeClass("loading disabled");
			});
		}
	};

	$scope.clearCreateMark = function() {
		$scope.currentMark = {isActive: true};
	};

	$scope.submitCreateMarkBulk = function() {
		$("#submit_create_mark_bulk").addClass("loading");
		$.ajax({
			url: BASE_URL + "bulk-mark-create.json",
			data: window.fileUploadForm,
			cache: false,
			contentType: false,
			processData: false,
			type: "POST",
			dataType: "json",
			success: function(data) {
				if (data.status) {
					$scope.clearCreateMarkBulk();
					uploadResultArray = [];
					for (var loop = 0; loop < data.outcome.length; loop++) {
						uploadResultArray.push([data.outcome[loop]]);
					}
					if (data.docs) {
						marks = data.docs;
						$scope.marks = marks;
					}
					$(".upload-status-modal p span").html(data.successCount + "/" + data.outcome.length + "Marks created.");
					$(".upload-status-modal").modal({closable: false}).modal("show");
				} else {
					dataFactory.toastError(data.msg);
				}
				window.fileUploadForm = null;
				$("#submit_create_mark_bulk").removeClass("loading");
			},
			error: function() {
				$("#submit_create_mark_bulk").removeClass("loading");
				dataFactory.toastError("Currently we are unable to process your request, plesae try later.");
			},
		});
	};

	$scope.clearCreateMarkBulk = function() {
		$(".file-upload-tab .parsley-required").html("");
		$("#holder p label").show();
		$("#holder p a").html("");
		$("#holder p a").hide();
		$("#submit_create_mark_bulk").addClass("disabled");
		$("#reset_create_mark_bulk").addClass("disabled");
		window.fileUploadForm = null;
	};

	$scope.loadDateAndBooleanFields = function() {
		$(".datepicker").each(function(idx, ele) {
			try {
				$scope.currentMark[$(ele).attr("name")] = Number($(ele).attr("data-value"));
			} catch (e) {
				//
			}
		});

		$(".boolean-field").each(function(idx, ele) {
			try {
				$scope.currentMark[$(ele).attr("data-field-name")] = $(ele).hasClass("checked");
			} catch (e) {
				//
			}
		});

		$(".foreign-field").each(function(idx, ele) {
			try {
				$scope.currentMark[$(ele).attr("data-field-name")] = $(ele).find("input").val();
			} catch (e) {
				//
			}
		});
	};

	$scope.getLocationName = function(input) {
		if (!input) {
			return "";
		}
		if (!locationMap[input]) {
			var obj = _.find(locations, {_id: input});
			if (obj) {
				locationMap[input] = obj;
			} else {
				locationMap[input] = {name: "N/A", code: "N/A"};
			}
		}
		return locationMap[input].name;
	};

	$scope.getTypeName = function(input) {
		if (!input) {
			return "";
		}
		if (input == "O") {
			return "Own Leaf";
		} else if (input == "B") {
			return "Bought Leaf";
		}
		return "--";
	};

	$scope.getCategoryName = function(input) {
		if (!input) {
			return "";
		}
		if (!categoryMap[input]) {
			var obj = _.find(categories, {_id: input});
			if (obj) {
				categoryMap[input] = obj;
			} else {
				categoryMap[input] = {name: "N/A", code: "N/A"};
			}
		}
		return categoryMap[input].name;
	};
}]);
var holder = null;

function processFileForUpload(e) {
	try {
		var files = e.target.files || e.dataTransfer.files || e.originalEvent.dataTransfer.files;
		var file = files[0];
		if (file) {
			if (/\.(xls|xlsx|ods)$/i.test(file.name)) {
				var extention = file.name.toUpperCase().split(".");
				extention = extention[extention.length - 1];
				$(".file-upload-tab .parsley-required").html("");
				if (file.size > (512 * 1024 * 1024)) {
					$(".file-upload-tab .parsley-required").html("Please use a file smaller than 512kB");
					return;
				}
				$(".file-upload-tab .parsley-required").html("");
				$("#holder p label").hide();
				$("#holder p a").html(file.name);
				$("#holder p a").show();
				$("#submit_create_mark_bulk").removeClass("disabled");
				$("#reset_create_mark_bulk").removeClass("disabled");
				window.fileUploadForm = new FormData();
				window.fileUploadForm.append("extention", extention);
				window.fileUploadForm.append("upload", file);
				document.getElementById("file_for_upload").value = "";
			} else {
				$(".file-upload-tab .parsley-required").html("Only <i>xls, xlsx, ods<i/> files are allowed.");
			}
		}
		return;
	} catch (err) {
		//
	}
}
var uploadResultArray = [[]];
// eslint-disable-next-line no-unused-vars
function downloadExcel() {
	$(".upload-status-modal .positive").click();
	var wb = new Workbook();
	var ws = sheet_from_array_of_arrays(uploadResultArray);
	wb.SheetNames.push("outcome");
	wb.Sheets["outcome"] = ws;
	var wbout = XLSX.write(wb, {
		bookType: "xlsx",
		bookSST: true,
		type: "binary",
	});
	saveAs(new Blob([s2ab(wbout)], {
		type: "application/octet-stream",
	}), "outcome_" + new Date().getTime() + ".xlsx");
}

