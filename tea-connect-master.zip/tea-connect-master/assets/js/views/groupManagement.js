
/* global groups:true*/
/* eslint no-global-assign:0 */

app.config(["$stateProvider", "$urlRouterProvider", "$locationProvider", function($stateProvider, $urlRouterProvider, $locationProvider) {
	$urlRouterProvider.otherwise("/list");
	$stateProvider
		.state("list", {
			onEnter: function() {
				$(".inner-nav-menu").find("a").removeClass("active");
				$(".inner-nav-menu-list").addClass("active");
			},
			views: {
				"main": {
					templateUrl: "/list.tpl.html",
					controller: "groupController",
				},
			},
			url: "/list",
		})
		.state("create", {
			onEnter: function() {
				$(".inner-nav-menu").find("a").removeClass("active");
				$(".inner-nav-menu-create").addClass("active");
			},
			views: {
				"main": {
					templateUrl: "/create.tpl.html",
					controller: "groupController",
				},
			},
			url: "/create",
		})
		.state("update", {
			onEnter: function() {
				$(".inner-nav-menu").find("a").removeClass("active");
				$(".inner-nav-menu-update").addClass("active");
			},
			views: {
				"main": {
					templateUrl: "/update.tpl.html",
					controller: "groupController",
				},
			},
			url: "/update?groupid",
		});
}]);
var currentState = null;
var currentParams = null;
app.run(["$rootScope", "$state", "$location", "$window", function run($rootScope, $state, $location, $window) {
	$rootScope.$on("$stateChangeStart", function(e, toState, toParams, fromState, fromParams) {
	//
	});
	$rootScope.$on("$stateChangeError", function(event, toState, toParams, fromState, fromParams, error) {
	//
	});
	$rootScope.$on("$stateChangeSuccess", function(event, toState, toParams, fromState, fromParams) {
		currentState = toState;
		currentParams = toParams;
	});
	$rootScope.$on("$viewContentLoaded", function(e, toState, toParams, fromState, fromParams) {
		if (currentState && ["update"].indexOf(currentState.name) >= 0) {
			$("#group_selection").dropdown({forceSelection: false});
			$("#group_selection").dropdown("setting", "onChange", function(val) {
				setTimeout(function() {
					$("#proxy-group-change").click();
				}, 200);
			});
			setTimeout(function() {
				if (currentParams.groupid) {
					$("#group_selection").dropdown("set selected", currentParams.groupid);
				}
			}, 300);
		}
		if (currentState && ["create"].indexOf(currentState.name) >= 0) {
			$(".create-group-tabs .item").tab();
			holder = document.getElementById("holder");
			holder.ondragover = function() {
				$(this).addClass("div_drag_hover");
				return false;
			};
			holder.ondragend = function() {
				$(this).removeClass("div_drag_hover");
				return false;
			};
			holder.ondrop = function(e) {
				$(this).removeClass("div_drag_hover");
				e.preventDefault();
				processFileForUpload(e);
			};
			setTimeout(function() {
				$(".boolean-field").checkbox();
				$("input.datepicker").each(function(idx, ele) {
					$(ele).daterangepicker({
						format: "DD MMM YYYY",
						singleDatePicker: true,
						showDropdowns: true,
						startDate: moment(),
					},
					function(start, end, label) {
						$(ele).attr("data-value", start.toDate().getTime());
					});
				});
			}, 500);
		}
	});
}]);

app.controller("groupController", ["$scope", "$rootScope", "$stateParams", "dataFactory", "$state", "$timeout", function($scope, $rootScope, $stateParams, dataFactory, $state, $timeout) {
	$scope.groups = groups;
	$scope.currentGroup = {isActive: true};
	$scope.currentGroupOrg = {isActive: true};
	$scope.groupsUnderProcessing = {};


	$scope.groupChanged = function() {
		var groupId = $("#group_selection input").val();
		if (groupId.length > 1) {
			if ($state.current.name == "update") {
				var posInGroups = _.findIndex($scope.groups, ["_id", groupId]);
				if (posInGroups > -1) {
					$scope.currentGroup = JSON.parse(JSON.stringify($scope.groups[posInGroups]));
					$scope.currentGroupOrg = JSON.parse(JSON.stringify($scope.groups[posInGroups]));
					$(".datepicker").each(function(idx, ele) {
						try {
							$(ele).attr("data-value", $scope.currentGroup[$(ele).attr("name")]);
							var tmpMoment = moment($scope.currentGroup[$(ele).attr("name")]);
							$(ele).val(tmpMoment.format("DD MMM YYYY"));
							$(ele).daterangepicker({
								format: "DD MMM YYYY",
								singleDatePicker: true,
								showDropdowns: true,
								startDate: tmpMoment,
							},
							function(start, end, label) {
								$(ele).attr("data-value", start.toDate().getTime());
							});
						} catch (e) {
							//
						}
					});
					$(".boolean-field").checkbox("uncheck");
					$(".boolean-field").each(function(idx, ele) {
						try {
							if ($scope.currentGroup[$(ele).attr("data-field-name")]) {
								$(ele).checkbox("check");
							}
						} catch (e) {
							//
						}
					});
					$("#submit_update_group").removeClass("disabled");
					$("#reset_update_group").removeClass("disabled");
				}
			}
		}
	};

	$scope.navUpdate = function(group) {
		$state.go("update", {groupid: group._id});
	};

	$scope.submitUpdateGroup = function() {
		var parsleyHandle = $("#groups_form").parsley();
		parsleyHandle.validate();
		if (parsleyHandle.isValid()) {
			$("#submit_update_group").addClass("loading disabled");
			$("#reset_update_group").addClass("disabled");
			$scope.loadDateAndBooleanFields();
			var _tmp = JSON.parse(JSON.stringify($scope.currentGroup));
			delete _tmp.isActive;
			var payload = {
				find: $("#group_selection input").val(),
				update: _tmp,
			};
			dataFactory.post("update-group.json", payload).then(function(data) {
				$("#submit_update_group").removeClass("loading disabled");
				$("#reset_update_group").removeClass("disabled");
				if (data.status) {
					dataFactory.toastSuccess("Group updated successfully");
					var posInGroups = _.findIndex(groups, ["_id", $("#group_selection input").val()]);
					if (posInGroups >= 0) {
						groups[posInGroups] = data.doc;
						$scope.groups = groups;
						$scope.currentGroupOrg = JSON.parse(JSON.stringify(data.doc));
					}
				} else {
					dataFactory.toastError(data.msg);
				}
			}, function() {
				dataFactory.toastError("we have encounterd an unexpected error, plesae try after some time.");
				$("#submit_update_group").removeClass("loading disabled");
				$("#reset_update_group").removeClass("disabled");
			});
		}
	};

	$scope.resetUpdateGroup = function() {
		$scope.currentGroup = JSON.parse(JSON.stringify($scope.currentGroupOrg));
	};

	$scope.setEnableddisabled = function(group) {
		if ($scope.groupsUnderProcessing[group._id]) {
			return;
		}
		$scope.groupsUnderProcessing[group._id] = true;
		$("." + group._id).parent().parent().find(".notched.circle.loading").css("visibility", "visible");
		$("." + group._id).checkbox();
		var payload = {
			find: group._id,
			update: {isActive: (!group.isActive)},
		};
		dataFactory.post("update-group.json", payload).then(function(data) {
			if (data.status) {
				group.isActive = data.doc.isActive;
				$timeout(function() {
					if (group.isActive) {
						$("." + group._id).checkbox("check");
					} else {
						$("." + group._id).checkbox("uncheck");
					}
					$("." + group._id).parent().parent().find(".notched.circle.loading").css("visibility", "hidden");
				}, 200);
			} else {
				$("." + group._id).parent().parent().find(".notched.circle.loading").css("visibility", "hidden");
				dataFactory.toastError(data.msg);
			}
			$scope.groupsUnderProcessing[group._id] = false;
		}, function() {
			$("." + group._id).parent().parent().find(".notched.circle.loading").hide();
			dataFactory.toastError("we have encounterd an unexpected error, plesae try after some time.");
			$scope.groupsUnderProcessing[group._id] = false;
		});
	};

	$scope.submitCreateGroup = function() {
		var parsleyHandle = $("#groups_form").parsley();
		parsleyHandle.validate();
		var additionalValidations = true;
		if (parsleyHandle.isValid() && additionalValidations) {
			$("#submit_create_group").addClass("loading disabled");
			$("#reset_create_group").addClass("disabled");
			$scope.loadDateAndBooleanFields();
			dataFactory.post("create-group.json", $scope.currentGroup).then(function(data) {
				$("#submit_create_group").removeClass("loading disabled");
				$("#reset_create_group").addClass("disabled");
				if (data.status) {
					groups.push(data.doc);
					$scope.groups = groups;
					$scope.clearCreateGroup();
					dataFactory.toastSuccess("Group created successfully");
				} else {
					dataFactory.toastError(data.msg);
				}
			}, function() {
				dataFactory.toastError("we have encounterd an unexpected error, plesae try after some time.");
				$("#submit_create_group").removeClass("loading disabled");
			});
		}
	};

	$scope.clearCreateGroup = function() {
		$scope.currentGroup = {isActive: true};
	};

	$scope.submitCreateGroupBulk = function() {
		$("#submit_create_group_bulk").addClass("loading");
		$.ajax({
			url: BASE_URL + "bulk-group-create.json",
			data: window.fileUploadForm,
			cache: false,
			contentType: false,
			processData: false,
			type: "POST",
			dataType: "json",
			success: function(data) {
				if (data.status) {
					$scope.clearCreateGroupBulk();
					uploadResultArray = [];
					for (var loop = 0; loop < data.outcome.length; loop++) {
						uploadResultArray.push([data.outcome[loop]]);
					}
					if (data.docs) {
						groups = data.docs;
						$scope.groups = groups;
					}
					$(".upload-status-modal p span").html(data.successCount + "/" + data.outcome.length + "Groups created.");
					$(".upload-status-modal").modal({closable: false}).modal("show");
				} else {
					dataFactory.toastError(data.msg);
				}
				window.fileUploadForm = null;
				$("#submit_create_group_bulk").removeClass("loading");
			},
			error: function() {
				$("#submit_create_group_bulk").removeClass("loading");
				dataFactory.toastError("Currently we are unable to process your request, plesae try later.");
			},
		});
	};

	$scope.clearCreateGroupBulk = function() {
		$(".file-upload-tab .parsley-required").html("");
		$("#holder p label").show();
		$("#holder p a").html("");
		$("#holder p a").hide();
		$("#submit_create_group_bulk").addClass("disabled");
		$("#reset_create_group_bulk").addClass("disabled");
		window.fileUploadForm = null;
	};

	$scope.loadDateAndBooleanFields = function() {
		$(".datepicker").each(function(idx, ele) {
			try {
				$scope.currentGroup[$(ele).attr("name")] = Number($(ele).attr("data-value"));
			} catch (e) {
				//
			}
		});

		$(".boolean-field").each(function(idx, ele) {
			try {
				$scope.currentGroup[$(ele).attr("data-field-name")] = $(ele).hasClass("checked");
			} catch (e) {
				//
			}
		});

		$(".foreign-field").each(function(idx, ele) {
			try {
				$scope.currentGroup[$(ele).attr("data-field-name")] = $(ele).find("input").val();
			} catch (e) {
				//
			}
		});
	};
}]);
var holder = null;

function processFileForUpload(e) {
	try {
		var files = e.target.files || e.dataTransfer.files || e.originalEvent.dataTransfer.files;
		var file = files[0];
		if (file) {
			if (/\.(xls|xlsx|ods)$/i.test(file.name)) {
				var extention = file.name.toUpperCase().split(".");
				extention = extention[extention.length - 1];
				$(".file-upload-tab .parsley-required").html("");
				if (file.size > (512 * 1024 * 1024)) {
					$(".file-upload-tab .parsley-required").html("Please use a file smaller than 512kB");
					return;
				}
				$(".file-upload-tab .parsley-required").html("");
				$("#holder p label").hide();
				$("#holder p a").html(file.name);
				$("#holder p a").show();
				$("#submit_create_group_bulk").removeClass("disabled");
				$("#reset_create_group_bulk").removeClass("disabled");
				window.fileUploadForm = new FormData();
				window.fileUploadForm.append("extention", extention);
				window.fileUploadForm.append("upload", file);
				document.getElementById("file_for_upload").value = "";
			} else {
				$(".file-upload-tab .parsley-required").html("Only <i>xls, xlsx, ods<i/> files are allowed.");
			}
		}
		return;
	} catch (err) {
		//
	}
}
var uploadResultArray = [[]];
// eslint-disable-next-line no-unused-vars
function downloadExcel() {
	$(".upload-status-modal .positive").click();
	var wb = new Workbook();
	var ws = sheet_from_array_of_arrays(uploadResultArray);
	wb.SheetNames.push("outcome");
	wb.Sheets["outcome"] = ws;
	var wbout = XLSX.write(wb, {
		bookType: "xlsx",
		bookSST: true,
		type: "binary",
	});
	saveAs(new Blob([s2ab(wbout)], {
		type: "application/octet-stream",
	}), "outcome_" + new Date().getTime() + ".xlsx");
}

