
/* global grades sellers categories users:true*/
/* eslint no-global-assign:0 */

app.config(["$stateProvider", "$urlRouterProvider", "$locationProvider", function($stateProvider, $urlRouterProvider, $locationProvider) {
	$urlRouterProvider.otherwise("/list");
	$stateProvider
		.state("list", {
			onEnter: function() {
				$(".inner-nav-menu").find("a").removeClass("active");
				$(".inner-nav-menu-list").addClass("active");
			},
			views: {
				"main": {
					templateUrl: "/list.tpl.html",
					controller: "invoiceController",
				},
			},
			url: "/list",
		})
		.state("create", {
			onEnter: function() {
				$(".inner-nav-menu").find("a").removeClass("active");
				$(".inner-nav-menu-create").addClass("active");
			},
			views: {
				"main": {
					templateUrl: "/create.tpl.html",
					controller: "invoiceController",
				},
			},
			url: "/create?clientid",
		})
		.state("details", {
			onEnter: function() {
				$(".inner-nav-menu").find("a").removeClass("active");
				// $(".inner-nav-menu-create").addClass("active");
			},
			views: {
				"main": {
					templateUrl: "/create.tpl.html",
					controller: "invoiceController",
				},
			},
			url: "/details?musterid",
		});
}]);
var currentState = null;
var currentParams = null;
app.run(["$rootScope", "$state", "$location", "$window", function run($rootScope, $state, $location, $window) {
	$rootScope.$on("$stateChangeStart", function(e, toState, toParams, fromState, fromParams) {
	//
	});
	$rootScope.$on("$stateChangeError", function(event, toState, toParams, fromState, fromParams, error) {
	//
	});
	$rootScope.$on("$stateChangeSuccess", function(event, toState, toParams, fromState, fromParams) {
		currentState = toState;
		currentParams = toParams;
	});
	$rootScope.$on("$viewContentLoaded", function(e, toState, toParams, fromState, fromParams) {
		if (currentState && ["create"].indexOf(currentState.name) >= 0) {
			$("#submit_update").hide();
			setTimeout(function() {
				if (currentParams.clientid) {
					$("#proxy_client_selection").attr("data-clientid", currentParams.clientid);
					$("#proxy_client_selection").click();
				}
			}, 300);
		} else if (currentState && ["details"].indexOf(currentState.name) >= 0) {
			$("#submit_create").hide();
			setTimeout(function() {
				if (currentParams.musterid) {
					$("#proxy_muster_selection").attr("data-musterid", currentParams.musterid);
					$("#proxy_muster_selection").click();
				}
			}, 300);
		}
	});
}]);
var clientMap = {};
var gradeMap = {};
var gradeReverseMap = {};
var categoryMap = {};
var markMap = {};
var markSellerMapping = {};
var userMap = {};
var loop=0;
var length = 0;

for (loop=0, length=sellers.length; loop<length; loop++) {
	clientMap[sellers[loop]._id] = loop;
	var _marks = [];
	sellers[loop]._assignedCount = 0;
	for (var inner=0, innerLen = sellers[loop].marks.length; inner<innerLen; inner++) {
		_marks.push(sellers[loop].marks[inner].name);
		markSellerMapping[sellers[loop].marks[inner]._id] = sellers[loop]._id;
	}
	sellers[loop]._marks = _marks.join(", ");
	for (inner=0, innerLen = sellers[loop].samples.length; inner<innerLen; inner++) {
		if (sellers[loop].samples[inner].assignedTo) {
			sellers[loop]._assignedCount++;
		}
	}
}

for (loop=0, length=grades.length; loop<length; loop++) {
	gradeMap[grades[loop]._id] = loop;
	gradeReverseMap[grades[loop].code] = grades[loop]._id;
}

for (loop=0, length=categories.length; loop<length; loop++) {
	categoryMap[categories[loop]._id] = loop;
}

for (loop=0, length=users.length; loop<length; loop++) {
	userMap[users[loop]._id] = loop;
}

app.controller("invoiceController", ["$scope", "$rootScope", "$stateParams", "dataFactory", "$state", "$timeout", function($scope, $rootScope, $stateParams, dataFactory, $state, $timeout) {
	$scope.grades = grades;
	$scope.sellers = sellers;
	$scope.categories = categories;
	var dt = new Date();
	$scope.selection = {clientId: "", markId: "", season: dt.getFullYear()};
	if (dt.getMonth()<=2) {
		$scope.selection.season --;
	}
	$scope.currentRecord = {};
	$scope.currentGrade = {isActive: true};
	$scope.currentGradeOrg = {isActive: true};
	$scope.gradesUnderProcessing = {};
	$scope.currentPageNumberInList = 1;
	$scope.samples = [];
	$scope.users = users;

	$scope.marks = [];
	$scope.records = [];
	$scope.mode = "LISTING";
	$scope.disableClientSelection = false;

	var editPos = -1;
	var musterId;

	$scope.assignedConfig = {
		valueField: "_id",
		labelField: "userName",
		searchField: ["userName"],
		maxOptions: 25,
		// maxItems: 1,
		// closeAfterSelect: true,
		create: false,
	};

	$scope.assignClientId = function() {
		var id = $("#proxy_client_selection").attr("data-clientid");
		if (id) {
			$scope.selection.clientId = id;
			$scope.clientChanged();
		}
	};

	$scope.clientChanged = function() {
		$scope.marks = $scope.sellers[clientMap[$scope.selection.clientId]].marks;
		$scope.markChanged();
	};

	$scope.markChanged = function() {
		if (!$scope.disableClientSelection) {
			$scope.currentRecord = {};
			$scope.records = [];
		}
		$scope.currentPageNumberInList = 1;
		editPos = -1;
	};

	$scope.navCreate = function(obj) {
		$state.go("create", {clientid: obj._id});
	};

	$scope.addCurrentRecord = function() {
		if (!$scope.currentRecord.invNo) {
			dataFactory.toastError("Invoice Number must be entered");
			return;
		}
		if (!$scope.currentRecord.gradeId) {
			dataFactory.toastError("Grade must be selected");
			return;
		}
		if (!$scope.currentRecord.mfgDate) {
			dataFactory.toastError("Manufacture Date must be entered");
			return;
		}
		if (!$scope.currentRecord.noOfPkg) {
			dataFactory.toastError("Number of Packages must be entered");
			return;
		}
		if (!$scope.currentRecord.netPerPkg) {
			// dataFactory.toastError("Net per package must be entered");
			// return;
		}
		var _rec = {
			invNo: $scope.currentRecord.invNo.toUpperCase(),
			gradeId: "" + $scope.currentRecord.gradeId,
			mfgDate: $scope.currentRecord.mfgDate.getTime(),
			mfgDateStr: date2String($scope.currentRecord.mfgDate),
			noOfPkg: 0 + $scope.currentRecord.noOfPkg,
		};
		if ($scope.currentRecord.netPerPkg) {
			_rec.netPerPkg = 0 + $scope.currentRecord.netPerPkg;
		}
		if (editPos == -1) {
			$scope.records.push(_rec);
		} else {
			$scope.records[editPos] = _rec;
		}
		$scope.currentRecord.invNo = "";
		$("#current-invoice-number").focus();
		editPos = -1;
	};

	$scope.pageChangeHandler=function(pos) {
		$scope.currentPageNumberInList = pos;
	};

	$scope.getActualPos = function(pos) {
		return (($scope.currentPageNumberInList - 1) * 40) + pos;
	};

	$scope.getGradeCode = function(input) {
		if (!input) {
			return "";
		}
		var pos = gradeMap[input];
		if (pos==null) {
			return "n/a";
		}
		return $scope.grades[pos].code;
	};

	$scope.removeInvoice = function(pos) {
		pos = $scope.getActualPos(pos);
		$scope.records.splice(pos, 1);
	};

	$scope.editInvoice = function(pos) {
		pos = $scope.getActualPos(pos);
		editPos = pos;
		var ref = $scope.records[editPos];
		$scope.currentRecord.invNo = ref.invNo.toUpperCase();
		$scope.currentRecord.gradeId = ref.gradeId + "";
		$scope.currentRecord.mfgDate = new Date(ref.mfgDate);
		$scope.currentRecord.noOfPkg = ref.noOfPkg + 0;
		if (ref.netPerPkg) {
			$scope.currentRecord.netPerPkg = ref.netPerPkg + 0;
		} else {
			delete $scope.currentRecord.netPerPkg;
		}
	};

	$scope.processFileForUpload = function(e) {
		$("#loader").show();
		try {
			e.stopPropagation();
			e.preventDefault();
			var files = e.target.files || e.dataTransfer.files || e.originalEvent.dataTransfer.files;
			var file = files[0];
			if (file) {
				if (/\.(xls|xlsx|ods)$/i.test(file.name)) {
					var reader = new FileReader();
					reader.onload = function(e) {
						var data = e.target.result;
						var workbook = XLSX.read(data, {type: "binary"});
						var first_sheet_name = workbook.SheetNames[0];
						var worksheet = workbook.Sheets[first_sheet_name];
						var requiredJson = XLSX.utils.sheet_to_json(worksheet);
						$scope.appendRecords(requiredJson);
					};
					reader.readAsBinaryString(file);
				}
				document.getElementById("file_for_upload").value = "";
			}
			return;
		} catch (err) {
			$("#loader").hide();
		}
	};

	$scope.appendRecords = function(docs) {
		if ((!docs) || (docs.length==0)) {
			$("#loader").hide();
		}
		for (var loop=0, length = docs.length; loop<length; loop++) {
			try {
				var invNum = docs[loop]["Inv/Batch"];
				if (!invNum) {
					continue;
				}
				invNum = ""+invNum;
				var grade = docs[loop].Grade;
				var gradeId = null;
				if (grade) {
					grade = ""+grade;
					grade = grade.trim().toUpperCase();
					gradeId = gradeReverseMap[grade];
					if (!gradeId) {
						continue;
					}
				}
				var season = docs[loop].Season;
				if (season) {
					if (!isNaN(season)) {
						season = Number(season);
					} else {
						season = null;
					}
				}
				var mfgDate = docs[loop]["MFG Date"];
				if (isNaN(mfgDate)) {
					continue;
				}
				mfgDate = excelDateToJSDate(mfgDate);
				var noOfPkg = docs[loop].PKGS;
				if (isNaN(noOfPkg)) {
					continue;
				}
				var netPerPkg = null;
				var tmp = docs[loop].KGS;
				if (tmp && (tmp!="null") && (tmp != "undefined")) {
					if (!isNaN(tmp)) {
						netPerPkg = Number(tmp)/Number(noOfPkg);
					}
				}
				var _rec = {
					invNo: invNum.toUpperCase(),
					gradeId: gradeId,
					mfgDate: mfgDate.getTime(),
					mfgDateStr: date2String(mfgDate),
					noOfPkg: Number(noOfPkg),
				};
				if (season) {
					_rec.season = season;
				}
				if (netPerPkg) {
					_rec.netPerPkg = netPerPkg;
				}
				$scope.records.push(_rec);
			} catch (err) {
				//
			}
		}
		try {
			$scope.$apply();
		} catch (err) {
			//
		}
		$("#loader").hide();
	};

	$scope.saveRecords = function() {
		if (!$scope.selection.season) {
			dataFactory.toastSuccess("season is required");
			return;
		}
		$("#loader").show();
		var payload = {
			sellerId: $scope.selection.clientId,
			season: $scope.selection.season,
			markId: $scope.selection.markId,
			records: $scope.records,
		};
		if ($scope.disableClientSelection) {
			payload._id = musterId;
		}
		dataFactory.post("update-musters.json", payload).then(function(data) {
			$("#loader").hide();
			if (data.status) {
				if (!$scope.disableClientSelection) {
					dataFactory.toastSuccess("records successfully created");
					$scope.selection.markId = "";
					$scope.markChanged();
					var ref = sellers[clientMap[$scope.selection.clientId]];
					ref.samples.push({_id: data.doc._id, createdAt: data.doc.createdAt});
				} else {
					dataFactory.toastSuccess("records successfully updated");
					$state.go("list");
				}
			} else {
				dataFactory.toastError(data.msg);
			}
		}, function() {
			dataFactory.toastError("we have encounterd an unexpected error, plesae try after some time.");
			$("#loader").hide();
		});
	};

	$scope.getClientName = function(input) {
		if (!input) {
			return "";
		}
		var pos = clientMap[input];
		if (pos==null) {
			return "n/a";
		}
		return $scope.sellers[pos].name;
	};

	$scope.getMarkName = function(input) {
		if (!input) {
			return "";
		}
		var val = markMap[input];
		if (!val) {
			val = _.find($scope.marks, {_id: input});
			if (!val) {
				val = {name: "n/a"};
			} else {
				// val = val.name;
				markMap[input] = val;
			}
		}
		return val.name;
	};

	$scope.showPendingSamples = function(clientId, musters) {
		if (!musters) {
			return;
		}
		var count = musters.length;
		if (!count) {
			return;
		}
		$("#loader").show();
		var ids = [];
		for (var loop=0; loop<count; loop++) {
			ids.push(musters[loop]._id);
		}
		var payload = {
			ids: ids,
		};
		dataFactory.post("pending-muster-summary.json", payload).then(function(data) {
			$("#loader").hide();
			if (data.status) {
				if (data.docs.length>0) {
					$scope.samplesOrg = JSON.parse(JSON.stringify(data.docs));
					$scope.selection.clientId = clientId;
					$scope.marks = $scope.sellers[clientMap[$scope.selection.clientId]].marks;
					for (var loop=0, length =data.docs.length; loop<length; loop++) {
						if (data.docs[loop].tastingDate) {
							data.docs[loop].tastingDate = new Date(data.docs[loop].tastingDate);
						}
					}
					$scope.samples = data.docs;
					$scope.mode = "PENDING";
				} else {
					dataFactory.toastError("No pending records found");
				}
			} else {
				dataFactory.toastError(data.msg);
			}
		}, function() {
			dataFactory.toastError("we have encounterd an unexpected error, plesae try after some time.");
			$("#loader").hide();
		});
	};

	$scope.navClientListing = function() {
		$scope.mode = "LISTING";
	};

	$scope.updateAssignment = function(sample) {
		if ((!sample.assignedTo) || (sample.assignedTo.length==0) || (!sample.tastingDate)) {
			dataFactory.toastError("Both assignee and tasting date is required");
			return;
		}
		var locationId = markMap[sample.markId].locationId;
		for (var loop=0, length = sample.assignedTo.length; loop<length; loop++) {
			var userLocation = users[userMap[sample.assignedTo[loop]]].locationId;
			if (userLocation && (userLocation != locationId)) {
				dataFactory.toastError("Assigned user location and mark location must match");
				return;
			}
		}
		$("#loader").show();
		var payload = {
			musterId: sample._id,
			assignedTo: sample.assignedTo,
			tastingDate: sample.tastingDate.getTime(),
		};
		dataFactory.post("update-musters-assignment.json", payload).then(function(data) {
			$("#loader").hide();
			if (data.status) {
				var obj = _.find($scope.samplesOrg, {_id: sample._id});
				if ((!obj.assignedTo) || (obj.assignedTo.length==0)) {
					$scope.sellers[clientMap[$scope.selection.clientId]]._assignedCount++;
				}
				dataFactory.toastSuccess("Record updated");
			} else {
				dataFactory.toastError(data.msg);
			}
		}, function() {
			dataFactory.toastError("we have encounterd an unexpected error, plesae try after some time.");
			$("#loader").hide();
		});
	};

	$scope.navDetails = function(obj) {
		$state.go("details", {musterid: obj._id});
	};

	$scope.assignMusterId = function() {
		var id = $("#proxy_muster_selection").attr("data-musterid");
		$scope.disableClientSelection = true;
		if (id) {
			$("#loader").show();
			var payload = {musterId: id};
			dataFactory.post("muster-details.json", payload).then(function(data) {
				$("#loader").hide();
				if (data.status && data.doc) {
					$scope.selection.clientId = markSellerMapping[data.doc.markId];
					$scope.marks = $scope.sellers[clientMap[$scope.selection.clientId]].marks;
					$scope.selection.markId = data.doc.markId;
					$scope.currentRecord = {};
					for (var loop=0, length = data.doc.invoices.length; loop<length; loop++) {
						var tmp = new Date(data.doc.invoices[loop].mfgDate);
						data.doc.invoices[loop].mfgDateStr = date2String(tmp);
					}
					$scope.records = data.doc.invoices;
					musterId = id;
				} else {
					dataFactory.toastError(data.status?"Details not found":data.msg);
					$state.go("list");
				}
			}, function() {
				dataFactory.toastError("we have encounterd an unexpected error, plesae try after some time.");
				$("#loader").hide();
				$state.go("list");
			});
		} else {
			$state.go("list");
		}
	};

	$scope.navClientListing2 = function() {
		$state.go("list");
	};
}]);
