/* global params categories:true*/
/* eslint no-global-assign:0 */

app.config(["$stateProvider", "$urlRouterProvider", "$locationProvider", function($stateProvider, $urlRouterProvider, $locationProvider) {
	$urlRouterProvider.otherwise("/list");
	$stateProvider
		.state("list", {
			onEnter: function() {
				$(".inner-nav-menu").find("a").removeClass("active");
				$(".inner-nav-menu-list").addClass("active");
			},
			views: {
				"main": {
					templateUrl: "/list.tpl.html",
					controller: "paramController",
				},
			},
			url: "/list",
		})
		.state("create", {
			onEnter: function() {
				$(".inner-nav-menu").find("a").removeClass("active");
				$(".inner-nav-menu-create").addClass("active");
			},
			views: {
				"main": {
					templateUrl: "/create.tpl.html",
					controller: "paramController",
				},
			},
			url: "/create",
		})
		.state("update", {
			onEnter: function() {
				$(".inner-nav-menu").find("a").removeClass("active");
				$(".inner-nav-menu-update").addClass("active");
			},
			views: {
				"main": {
					templateUrl: "/update.tpl.html",
					controller: "paramController",
				},
			},
			url: "/update?paramid",
		});
}]);
var currentState = null;
var currentParams = null;
app.run(["$rootScope", "$state", "$location", "$window", function run($rootScope, $state, $location, $window) {
	$rootScope.$on("$stateChangeStart", function(e, toState, toParams, fromState, fromParams) {
	});
	$rootScope.$on("$stateChangeError", function(event, toState, toParams, fromState, fromParams, error) {
	});
	$rootScope.$on("$stateChangeSuccess", function(event, toState, toParams, fromState, fromParams) {
		currentState = toState;
		currentParams = toParams;
	});
	$rootScope.$on("$viewContentLoaded", function(e, toState, toParams, fromState, fromParams) {
		if (currentState && ["update"].indexOf(currentState.name) >= 0) {
			$("#param_selection").dropdown({forceSelection: false});
			$("#param_selection").dropdown("setting", "onChange", function(val) {
				setTimeout(function() {
					$("#proxy-param-change").click();
				}, 200);
			});
			setTimeout(function() {
				if (currentParams.paramid) {
					$("#param_selection").dropdown("set selected", currentParams.paramid);
				}
			}, 300);
		}
		/* if (currentState && ["create"].indexOf(currentState.name) >= 0) {
			setTimeout(function() {
				$(".boolean-field").checkbox();
				$("input.datepicker").each(function(idx, ele) {
					$(ele).daterangepicker({
						format: "DD MMM YYYY",
						singleDatePicker: true,
						showDropdowns: true,
						startDate: moment(),
					},
					function(start, end, label) {
						$(ele).attr("data-value", start.toDate().getTime());
					});
				});
			}, 500);
		} */
	});
}]);

app.controller("paramController", ["$scope", "$rootScope", "$stateParams", "dataFactory", "$state", "$timeout", function($scope, $rootScope, $stateParams, dataFactory, $state, $timeout) {
	$scope.params = params;
	$scope.categories = categories;
	$scope.currentParam = {isActive: true, values: [{name: ""}], categories: []};
	$scope.currentParamOrg = {isActive: true};
	$scope.paramsUnderProcessing = {};
	$scope.notes = [];
	$scope.suggestions = [];
	// $scope.categories = [];

	$scope.notesConfig = {
		valueField: "value",
		labelField: "value",
		searchField: ["value"],
		maxOptions: 25,
		// maxItems: 1,
		closeAfterSelect: true,
		create: function(text) {
			return {value: text.toUpperCase()};
		},
	};

	$scope.suggestionConfig = {
		valueField: "value",
		labelField: "value",
		searchField: ["value"],
		maxOptions: 25,
		// maxItems: 1,
		readonly: true,
		closeAfterSelect: true,
		create: false,
	};

	$scope.categoryConfig = {
		valueField: "_id",
		labelField: "code",
		searchField: ["name"],
		maxOptions: 25,
		// maxItems: 1,
		// closeAfterSelect: true,
		create: false,
	};


	$scope.paramChanged = function() {
		var paramId = $("#param_selection input").val();
		if (paramId.length > 1) {
			if ($state.current.name == "update") {
				var posInParams = _.findIndex($scope.params, ["_id", paramId]);
				if (posInParams > -1) {
					$scope.currentParam = JSON.parse(JSON.stringify($scope.params[posInParams]));
					$scope.currentParamOrg = JSON.parse(JSON.stringify($scope.params[posInParams]));
					$scope.notes = [];
					$scope.suggestions = [];
					if (!$scope.currentParam.values) {
						$scope.currentParam.values = [];
						$scope.currentParamOrg.values = [];
					}
					if (!$scope.currentParam.categories) {
						$scope.currentParam.categories = [];
						$scope.currentParamOrg.categories = [];
					}
					if (!$scope.currentParam.notes) {
						$scope.currentParam.notes = [];
						$scope.currentParamOrg.notes = [];
					}
					if (!$scope.currentParam.suggestions) {
						$scope.currentParam.suggestions = [];
						$scope.currentParamOrg.suggestions = [];
					}
					$scope.suggestions = $scope.currentParam.suggestions.map(function(x) {
						return {value: x};
					});
					$scope.notes = $scope.currentParam.notes.map(function(x) {
						return {value: x};
					});
					if ($scope.currentParam.values.length>0) {
						if ($scope.currentParam.values[$scope.currentParam.values.length -1].name) {
							$scope.currentParam.values.push({name: ""});
							$scope.currentParamOrg.values.push({name: ""});
						}
					} else {
						$scope.currentParam.values.push({name: ""});
						$scope.currentParamOrg.values.push({name: ""});
					}
					$(".datepicker").each(function(idx, ele) {
						try {
							$(ele).attr("data-value", $scope.currentParam[$(ele).attr("name")]);
							var tmpMoment = moment($scope.currentParam[$(ele).attr("name")]);
							$(ele).val(tmpMoment.format("DD MMM YYYY"));
							$(ele).daterangepicker({
								format: "DD MMM YYYY",
								singleDatePicker: true,
								showDropdowns: true,
								startDate: tmpMoment,
							},
							function(start, end, label) {
								$(ele).attr("data-value", start.toDate().getTime());
							});
						} catch (e) {
							//
						}
					});
					$(".boolean-field").checkbox("uncheck");
					$(".boolean-field").each(function(idx, ele) {
						try {
							if ($scope.currentParam[$(ele).attr("data-field-name")]) {
								$(ele).checkbox("check");
							}
						} catch (e) {
							//
						}
					});
					$("#submit_update_param").removeClass("disabled");
					$("#reset_update_param").removeClass("disabled");
				}
			}
		}
	};

	$scope.navUpdate = function(param) {
		$state.go("update", {paramid: param._id});
	};

	$scope.submitUpdateParam = function() {
		var parsleyHandle = $("#params_form").parsley();
		parsleyHandle.validate();
		var additionalValidations = !$scope.validateParamValues();
		if (parsleyHandle.isValid() && additionalValidations) {
			$("#submit_update_param").addClass("loading disabled");
			$("#reset_update_param").addClass("disabled");
			$scope.loadDateAndBooleanFields();
			dataFactory.post("update-tasting-param.json", $scope.currentParam).then(function(data) {
				$("#submit_update_param").removeClass("loading disabled");
				$("#reset_update_param").removeClass("disabled");
				if (data.status) {
					dataFactory.toastSuccess("Param updated successfully");
					var posInParams = _.findIndex(params, ["_id", $("#param_selection input").val()]);
					if (posInParams >= 0) {
						params[posInParams] = data.doc;
						$scope.params = params;
						$scope.currentParamOrg = JSON.parse(JSON.stringify(data.doc));
					}
				} else {
					dataFactory.toastError(data.msg);
				}
			}, function() {
				dataFactory.toastError("we have encounterd an unexpected error, plesae try after some time.");
				$("#submit_update_param").removeClass("loading disabled");
				$("#reset_update_param").removeClass("disabled");
			});
		}
	};

	$scope.resetUpdateParam = function() {
		$scope.currentParam = JSON.parse(JSON.stringify($scope.currentParamOrg));
	};

	$scope.setEnableddisabled = function(param) {
		var additionalValidations = !$scope.validateParamValues();
		if (!additionalValidations) {
			return;
		}
		if ($scope.paramsUnderProcessing[param._id]) {
			return;
		}
		$scope.paramsUnderProcessing[param._id] = true;
		$("." + param._id).parent().parent().find(".notched.circle.loading").css("visibility", "visible");
		$("." + param._id).checkbox();
		param.isActive = !param.isActive;
		dataFactory.post("update-tasting-param.json", param).then(function(data) {
			if (data.status) {
				param.isActive = data.doc.isActive;
				$timeout(function() {
					if (param.isActive) {
						$("." + param._id).checkbox("check");
					} else {
						$("." + param._id).checkbox("uncheck");
					}
					$("." + param._id).parent().parent().find(".notched.circle.loading").css("visibility", "hidden");
				}, 200);
			} else {
				$("." + param._id).parent().parent().find(".notched.circle.loading").css("visibility", "hidden");
				dataFactory.toastError(data.msg);
			}
			$scope.paramsUnderProcessing[param._id] = false;
		}, function() {
			$("." + param._id).parent().parent().find(".notched.circle.loading").hide();
			dataFactory.toastError("we have encounterd an unexpected error, plesae try after some time.");
			$scope.paramsUnderProcessing[param._id] = false;
		});
	};

	$scope.submitCreateParam = function() {
		var parsleyHandle = $("#params_form").parsley();
		parsleyHandle.validate();
		var additionalValidations = !$scope.validateParamValues();
		if (parsleyHandle.isValid() && additionalValidations) {
			$("#submit_create_param").addClass("loading disabled");
			$("#reset_create_param").addClass("disabled");
			$scope.loadDateAndBooleanFields();
			dataFactory.post("update-tasting-param.json", $scope.currentParam).then(function(data) {
				$("#submit_create_param").removeClass("loading disabled");
				$("#reset_create_param").addClass("disabled");
				if (data.status) {
					params.push(data.doc);
					$scope.params = params;
					$scope.clearCreateParam();
					dataFactory.toastSuccess("Param created successfully");
				} else {
					dataFactory.toastError(data.msg);
				}
			}, function() {
				dataFactory.toastError("we have encounterd an unexpected error, plesae try after some time.");
				$("#submit_create_param").removeClass("loading disabled");
			});
		}
	};

	$scope.clearCreateParam = function() {
		$scope.currentParam = {isActive: true, values: [{name: ""}]};
		$scope.notes = [];
	};

	$scope.loadDateAndBooleanFields = function() {
		$(".datepicker").each(function(idx, ele) {
			try {
				$scope.currentParam[$(ele).attr("name")] = Number($(ele).attr("data-value"));
			} catch (e) {
				//
			}
		});

		$(".boolean-field").each(function(idx, ele) {
			try {
				$scope.currentParam[$(ele).attr("data-field-name")] = $(ele).hasClass("checked");
			} catch (e) {
				//
			}
		});

		$(".foreign-field").each(function(idx, ele) {
			try {
				$scope.currentParam[$(ele).attr("data-field-name")] = $(ele).find("input").val();
			} catch (e) {
				//
			}
		});
	};

	$scope.addRow = function() {
		$scope.currentParam.values.push({name: ""});
	};

	$scope.validateParamValues = function() {
		var hasErr = false;
		for (var loop=0, length = $scope.currentParam.values.length; loop<length; loop++) {
			if (!$scope.currentParam.values[loop].name) {
				continue;
			}
			if (!$scope.currentParam.values[loop].val) {
				$scope.currentParam.values[loop].err = true;
				hasErr = true;
				continue;
			}
			$scope.currentParam.values[loop].val = Number($scope.currentParam.values[loop].val);
			if (isNaN($scope.currentParam.values[loop].val)) {
				$scope.currentParam.values[loop].err = true;
				hasErr = true;
				continue;
			}
			if (($scope.currentParam.values[loop].val>10) || ($scope.currentParam.values[loop].val<0)) {
				$scope.currentParam.values[loop].err = true;
				hasErr = true;
				continue;
			}
			delete $scope.currentParam.values[loop].err;
		}
		return hasErr;
	};
}]);

