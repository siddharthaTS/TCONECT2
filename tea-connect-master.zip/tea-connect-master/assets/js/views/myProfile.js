/* global currentUser:true*/

app.controller("profileController", ["$scope", "$rootScope", "dataFactory", "$timeout", function($scope, $rootScope, dataFactory, $timeout) {
	$scope.currentUser = currentUser;

	$scope.updateProfile = function() {
		var parsleyHandle = $("#profile_form").parsley();
		parsleyHandle.validate();
		if (parsleyHandle.isValid()) {
			$("#loader").show();
			dataFactory.post("update-profile.json", $scope.currentUser).then(function(data) {
				$("#loader").hide();
				if (data.status) {
					dataFactory.toastSuccess("Profile Updated");
				} else {
					dataFactory.toastError(data.msg);
				}
			}, function() {
				dataFactory.toastError("we have encounterd an unexpected error, plesae try after some time.");
				$("#loader").hide();
			});
		}
	};

	$scope.updatePassword = function() {
		if (!($scope.currentUser.oldPassword && $scope.currentUser.password)) {
			dataFactory.toastError("Both old and new passwords are required.");
			return;
		}
		dataFactory.post("update-password-app.json", {
			oldPassword: $scope.currentUser.oldPassword,
			password: $scope.currentUser.password,
		}).then(function(data) {
			$("#loader").hide();
			if (data.status) {
				dataFactory.toastSuccess("Password Updated");
			} else {
				dataFactory.toastError(data.msg);
			}
		}, function() {
			dataFactory.toastError("we have encounterd an unexpected error, plesae try after some time.");
			$("#loader").hide();
		});
	};
}]);
