/* global params categoryMapping locations musters auctions sellers marks:true*/
/* eslint no-global-assign:0 */

app.config(["$stateProvider", "$urlRouterProvider", "$locationProvider", function($stateProvider, $urlRouterProvider, $locationProvider) {
	$urlRouterProvider.otherwise("/list");
	$stateProvider
		.state("list", {
			onEnter: function() {
				// $(".inner-nav-menu").find("a").removeClass("active");
				// $(".inner-nav-menu-list").addClass("active");
			},
			views: {
				"main": {
					templateUrl: "/list.tpl.html",
					controller: "tastingController",
				},
			},
			url: "/list",
		})
		.state("manage", {
			onEnter: function() {
				// $(".inner-nav-menu").find("a").removeClass("active");
				// $(".inner-nav-menu-create").addClass("active");
			},
			views: {
				"main": {
					templateUrl: "/manage.tpl.html",
					controller: "tastingController",
				},
			},
			url: "/manage",
		})
		.state("update", {
			onEnter: function() {
				// $(".inner-nav-menu").find("a").removeClass("active");
				// $(".inner-nav-menu-update").addClass("active");
			},
			views: {
				"main": {
					templateUrl: "/update.tpl.html",
					controller: "tastingController",
				},
			},
			url: "/update?reportid",
		});
}]);
var currentState = null;
// eslint-disable-next-line no-unused-vars
var currentParams = null;
app.run(["$rootScope", "$state", "$location", "$window", function run($rootScope, $state, $location, $window) {
	$rootScope.$on("$stateChangeStart", function(e, toState, toParams, fromState, fromParams) {
	//
	});
	$rootScope.$on("$stateChangeError", function(event, toState, toParams, fromState, fromParams, error) {
	//
	});
	$rootScope.$on("$stateChangeSuccess", function(event, toState, toParams, fromState, fromParams) {
		currentState = toState;
		currentParams = toParams;
	});
	$rootScope.$on("$viewContentLoaded", function(e, toState, toParams, fromState, fromParams) {
		if (currentState && ["list"].indexOf(currentState.name) >= 0) {
			$(".menu .item.tasting").tab();
		}
		if (currentState && ["update"].indexOf(currentState.name) >= 0) {
			//
		}
		if (currentState && ["create"].indexOf(currentState.name) >= 0) {
			//
		}
	});
}]);
var locationMap = {};
var marksMap = {};
var clientMap = {};
for (var loop=0, length = locations.length; loop<length; loop++) {
	locationMap[locations[loop]._id] = loop;
}
for (loop=0, length = marks.length; loop<length; loop++) {
	marksMap[marks[loop]._id] = loop;
}
for (loop=0, length = sellers.length; loop<length; loop++) {
	clientMap[sellers[loop]._id] = loop;
}
var selectedParams = null;
var invoices = null;
var tastingType = null;
var clientId = null;
var musterIds = null;
var auctionId = null;
var userProfile = localStorage.getItem("userprofile");
if (userProfile) {
	userProfile = JSON.parse(userProfile);
} else {
	userProfile = {};
}
var reportId = "";
var summaryObj = {display: "Summary", values: []};
app.controller("tastingController", ["$scope", "$rootScope", "$stateParams", "dataFactory", "$state", "$timeout", function($scope, $rootScope, $stateParams, dataFactory, $state, $timeout) {
	$scope.musters = musters;
	$scope.auctions = auctions;
	$scope.selectInvoices = false;
	$scope.auctionMarks = [];
	$scope.auctionGrades = [];
	$scope.auctionMarkPosMap = [];
	$scope.auctionGradePosMap = [];
	var _invoices = [];
	$scope.selectedInvoices = [];
	$scope.selectedParams = [];
	$scope.currentInvoice = {};
	$scope.currentInvoicePos = 0;

	$scope.search = {display: ""};
	var invoicePosMap = {};
	$scope.displaySummary = false;
	$scope.summaryObj = summaryObj;

	var remarksSuggestions = [];

	$scope.notesConfig = {
		valueField: "name",
		labelField: "name",
		searchField: ["name"],
		maxOptions: 25,
		// maxItems: 1,
		closeAfterSelect: true,
		create: function(text) {
			return {name: text.toUpperCase()};
		},
	};

	$scope.setupTastingTable = function() {
		$("#loader").show();
		invoicePosMap = {};
		remarksSuggestions = [];
		var first = true;
		for (var loop=0, length = invoices.length; loop<length; loop++) {
			invoices[loop].remarks = "";
			if (!reportId) {
				invoices[loop].values = [];
				invoices[loop].priceIdea = 0;
			}
			invoices[loop].display = invoices[loop].mark + " "+ invoices[loop].invNo +" " + invoices[loop].grade;
			invoicePosMap[invoices[loop].display] = loop;
			for (var inner=0, innerLen = selectedParams.length; inner<innerLen; inner++) {
				if (first) {
					selectedParams[inner]._notes = [];
					for (var nLoop=0, nLen = selectedParams[inner].notes.length; nLoop<nLen; nLoop++) {
						selectedParams[inner]._notes.push({name: selectedParams[inner].notes[nLoop]});
					}
					selectedParams[inner]._valueMap = {};
					for (var vLoop=0, vLen = selectedParams[inner].values.length; vLoop<vLen; vLoop++) {
						selectedParams[inner]._valueMap[selectedParams[inner].values[vLoop].val] = selectedParams[inner].values[vLoop].id;
					}

					// selectedParams[inner].suggestions = [];
					selectedParams[inner].notesConfig = {
						valueField: "name",
						labelField: "name",
						searchField: ["name"],
						maxOptions: 25,
						// maxItems: 1,
						closeAfterSelect: true,
						_suggestionPos: inner,
						create: function(text) {
							remarksSuggestions[this.settings._suggestionPos].push(text.toUpperCase());
							return {name: text.toUpperCase()};
						},
					};
					if (!reportId) {
						$scope.summaryObj.values.push({
							param: selectedParams[inner].name,
							paramId: selectedParams[inner]._id,
							remarks: [""],
						});
					}
					remarksSuggestions.push([]);
				}
				if (!reportId) {
					invoices[loop].values.push({
						param: selectedParams[inner].name,
						paramId: selectedParams[inner]._id,
						remarks: selectedParams[inner].descriptiveRemarks?[""]:[],
					});
				} else if (!selectedParams[inner].descriptiveRemarks) {
					for (var rLoop=0, rLen = invoices[loop].values[inner].remarks.length; rLoop<rLen; rLoop++) {
						var _rem = invoices[loop].values[inner].remarks[rLoop];
						if (selectedParams[inner].notes.indexOf(_rem)<0) {
							selectedParams[inner].notes.push(_rem);
							selectedParams[inner]._notes.push({name: _rem});
						}
					}
				}
			}
			first = false;
		}
		$scope.selectedParams = selectedParams;
		$scope.selectedInvoices = invoices;
		$scope.currentInvoice = $scope.selectedInvoices[0];
		$("#loader").hide();
	};

	if (currentState && ["manage"].indexOf(currentState.name) >= 0) {
		if ((!tastingType) || (invoices == null) || (invoices.length==0) || (!selectedParams)) {
			$state.go("list");
			return;
		}
		$scope.setupTastingTable();
	} else if (currentState && ["update"].indexOf(currentState.name) >= 0) {
		if (!currentParams.reportid) {
			$state.go("list");
			return;
		}
		$("#loader").show();
		dataFactory.post("app/tasting-report-details.json", {reportId: currentParams.reportid}).then(function(data) {
			$("#loader").hide();
			if (data.status) {
				reportId = currentParams.reportid;
				summaryObj = data.doc.summary;
				summaryObj.display = "Summary";
				invoices = data.doc.invoices;
				tastingType = data.doc.type;
				if (data.doc.type == "MUSTER") {
					clientId = data.doc.companyId;
					musterIds = data.doc.musterIds;
					selectedParams = setUpTastingParams(data.doc.type, data.doc.categoryId);
				} else if (data.doc.type == "AUCTION") {
					auctionId = data.doc.auctionId;
					selectedParams = setUpTastingParams(data.doc.type, "");
				}
				$state.go("manage");
			} else {
				$state.go("list");
			}
		}, function() {
			$state.go("list");
		});
	} else if (currentState && ["list"].indexOf(currentState.name) >= 0) {
		summaryObj = {display: "Summary", values: []};
		$scope.summaryObj = summaryObj;
	}

	$scope.getClientName = function(companyId) {
		var ref = clientMap[companyId];
		if (ref==null) {
			return "--";
		}
		return sellers[ref].name;
	};
	$scope.getMarkName = function(markId) {
		var ref = marksMap[markId];
		if (ref==null) {
			return "--";
		}
		return marks[ref].name;
	};
	$scope.getLocationName = function(locationId) {
		var ref = locationMap[locationId];
		if (ref==null) {
			return "--";
		}
		return locations[ref].name;
	};

	$scope.getCenterCode = function(id) {
		var ref = locationMap[id];
		if (ref==null) {
			return "--";
		}
		return locations[ref].code;
	};

	$scope.createMusterReport = function() {
		var markId = "";
		// var clientId = "";
		musterIds = [];
		for (var loop=0, length = musters.length; loop<length; loop++) {
			if (!musters[loop].selected) {
				continue;
			}
			var currMarkId = musters[loop].markId;
			if (!markId) {
				markId = currMarkId;
				clientId = musters[loop].companyId;
			} else if (markId != currMarkId) {
				dataFactory.toastError("Muster report can contain only 1 mark");
				return;
			}
			musterIds.push(musters[loop]._id);
		}
		if (musterIds.length==0) {
			dataFactory.toastError("Nothing selected");
			return;
		}
		var ref = marksMap[markId];
		if (ref==null) {
			// dataFactory.toastError("Nothing selected");
			return;
		}
		var categoryId = marks[ref].category;
		$("#loader").show();
		dataFactory.post("app/muster-invoices-for-tasting.json", {
			clientId: clientId,
			mark: $scope.getMarkName(markId),
			musterIds: musterIds,
		}).then(function(data) {
			if (data.status) {
				invoices = data.docs;
				tastingType = "MUSTER";
				selectedParams = setUpTastingParams("MUSTER", categoryId);
				$("#loader").hide();
				// console.log(JSON.stringify(musterIds));
				// console.log(clientId);
				// console.log(JSON.stringify(invoices));
				$state.go("manage");
			} else {
				$("#loader").hide();
				dataFactory.toastError(data.msg);
			}
		}, function() {
			dataFactory.toastError("we have encounterd an unexpected error, plesae try after some time.");
			$("#loader").hide();
		});
	};

	$scope.initAuctionReport = function(auction) {
		$("#loader").show();
		auctionId = auction._id;
		dataFactory.post("app/auction-invoices-for-tasting.json", {
			auctionId: auctionId,
		}).then(function(data) {
			if (data.status) {
				_invoices = data.docs;
				tastingType = "AUCTION";
				$scope.selectInvoices = true;
				$scope.auctionMarks = [];
				$scope.auctionGrades = [];
				$scope.auctionMarkPosMap = [];
				$scope.auctionGradePosMap = [];
				var _marks = [];
				var _grades = [];
				for (var loop=0, length = _invoices.length; loop<length; loop++) {
					var mark = _invoices[loop].mark;
					var grade = _invoices[loop].grade;
					var markPos = _marks.indexOf(mark);
					var gradePos = _grades.indexOf(grade);
					if (markPos<0) {
						_marks.push(mark);
						markPos = $scope.auctionMarks.length;
						$scope.auctionMarks.push({name: mark, checked: true});
						$scope.auctionMarkPosMap.push([]);
					}
					$scope.auctionMarkPosMap[markPos].push(loop);
					if (gradePos<0) {
						_grades.push(grade);
						gradePos =$scope.auctionGrades.length;
						$scope.auctionGrades.push({name: grade, checked: true});
						$scope.auctionGradePosMap.push([]);
					}
					$scope.auctionGradePosMap[gradePos].push(loop);
				}
				$("#loader").hide();
			} else {
				dataFactory.toastError(data.msg);
				$("#loader").hide();
			}
		}, function() {
			dataFactory.toastError("we have encounterd an unexpected error, plesae try after some time.");
			$("#loader").hide();
		});
	};

	$scope.applyAuctionFilter = function() {
		$("#loader").show();
		var allowedMarks = [];
		var allowedGrades = [];
		var loop=0;
		var length = 0;
		for (loop=0, length = $scope.auctionMarks.length; loop<length; loop++) {
			if (!$scope.auctionMarks[loop].checked) {
				continue;
			}
			allowedMarks = allowedMarks.concat($scope.auctionMarkPosMap[loop]);
		}
		for (loop=0, length = $scope.auctionGrades.length; loop<length; loop++) {
			if (!$scope.auctionGrades[loop].checked) {
				continue;
			}
			allowedGrades = allowedGrades.concat($scope.auctionGradePosMap[loop]);
		}
		invoices = [];
		for (loop=0, length = _invoices.length; loop<length; loop++) {
			if ((allowedMarks.indexOf(loop)>=0) && (allowedGrades.indexOf(loop)>=0)) {
				invoices.push(_invoices[loop]);
			}
		}
		$("#loader").hide();
		if (invoices.length==0) {
			dataFactory.toastError("Nothing selected");
			invoices = null;
			return;
		}
		selectedParams = setUpTastingParams("AUCTION", "");
		$state.go("manage");
	};

	$scope.cancelAuctionFilter = function() {
		_invoices = [];
		tastingType = null;
		$scope.selectInvoices = false;
		$scope.auctionMarks = [];
		$scope.auctionGrades = [];
		$scope.auctionMarkPosMap = [];
		$scope.auctionGradePosMap = [];
	};

	$scope.displayInvoiceRemark = function(params) {
		if (!params) {
			return "";
		}
		var arr = [];
		for (var loop=0, length = params.length; loop<length; loop++) {
			var _rem = params[loop].remarks.join(" ");
			if (_rem) {
				arr.push(_rem);
			}
		}
		return arr.join(", ");
	};

	$scope.selectInvoice = function(invoice, index) {
		if ($scope.displaySummary) {
			return;
		}
		$scope.currentInvoice = invoice;
		$scope.currentInvoicePos = invoicePosMap[invoice.display];
		$scope.search = {display: ""};
	};

	$scope.navInvoiceNext = function() {
		if ($scope.displaySummary) {
			return;
		}
		if ($scope.currentInvoicePos >= ($scope.selectedInvoices.length -1)) {
			return;
		}
		$scope.currentInvoicePos ++;
		$scope.currentInvoice = $scope.selectedInvoices[$scope.currentInvoicePos];
	};

	$scope.navInvoicePrev = function() {
		if ($scope.displaySummary) {
			return;
		}
		if ($scope.currentInvoicePos <= 0) {
			return;
		}
		$scope.currentInvoicePos --;
		$scope.currentInvoice = $scope.selectedInvoices[$scope.currentInvoicePos];
	};

	$scope.applyToAll = function() {
		var currId = $scope.currentInvoice._id || $scope.currentInvoice.id;
		if (!currId) {
			return;
		}
		var currentGradeType = $scope.currentInvoice.gradeType;
		$("#loader").show();
		for (var loop=0, length = $scope.selectedInvoices.length; loop<length; loop++) {
			var ref = $scope.selectedInvoices[loop];
			var id = ref._id || ref.id;
			if (!id) {
				continue;
			}
			if ($scope.currentInvoice.priceIdea && (!ref.priceIdea)) {
				ref.priceIdea = $scope.currentInvoice.priceIdea;
			}
			var gradeType = ref.gradeType;
			for (var inner=0, innerLen = selectedParams.length; inner<innerLen; inner++) {
				if (selectedParams[inner].copyGradesByType && (currentGradeType != gradeType)) {
					continue;
				}
				if ($scope.currentInvoice.values[inner].val && (!ref.values[inner].val)) {
					ref.values[inner].val = $scope.currentInvoice.values[inner].val;
				}
				if ((ref.values[inner].remarks.length==0) || (!ref.values[inner].remarks[0])) {
					ref.values[inner].remarks = $scope.currentInvoice.values[inner].remarks;
				}
			}
		}
		// $scope.selectedInvoices
		$("#loader").hide();
	};

	$scope.validateEntries = function() {
		$("#loader").show();
		for (var loop=0, length = $scope.selectedInvoices.length; loop<length; loop++) {
			var ref = $scope.selectedInvoices[loop];
			if (isNaN(ref.priceIdea)) {
				dataFactory.toastError("Invalid price idea for "+ ref.display);
				$("#loader").hide();
				return;
			}
			ref.priceIdea = Number(ref.priceIdea);
			if (ref.priceIdea<0) {
				dataFactory.toastError("Invalid price idea for "+ ref.display);
				$("#loader").hide();
				return;
			}
			for (var inner=0, innerLen = selectedParams.length; inner<innerLen; inner++) {
				if (ref.values[inner].val) {
					var valueId = selectedParams[inner]._valueMap[""+ref.values[inner].val];
					if (!valueId) {
						dataFactory.toastError("Invalid value for "+selectedParams[inner].name+ " in "+ ref.display);
						$("#loader").hide();
						return;
					}
					ref.values[inner].val = Number(ref.values[inner].val);
					ref.values[inner].label = ""+ref.values[inner].val;
					ref.values[inner].valueId = valueId;
				}
				if (ref.values[inner].remarks[0]) {
					ref.values[inner].remarks[0] = ref.values[inner].remarks[0].toUpperCase();
				}
			}
			ref.remarks = $scope.displayInvoiceRemark(ref.values);
		}
		for (inner=0, innerLen = selectedParams.length; inner<innerLen; inner++) {
			selectedParams[inner]._descriptiveRemarks = selectedParams[inner].descriptiveRemarks;
			selectedParams[inner].descriptiveRemarks = true;
		}
		$scope.currentInvoice = $scope.summaryObj;
		$scope.displaySummary = true;
		$("#loader").hide();
	};

	$scope.editInvoices = function() {
		for (var inner=0, innerLen = selectedParams.length; inner<innerLen; inner++) {
			selectedParams[inner].descriptiveRemarks = selectedParams[inner]._descriptiveRemarks;
			delete selectedParams[inner]._descriptiveRemarks;
		}
		$scope.currentInvoice = $scope.selectedInvoices[0];
		$scope.currentInvoicePos = 0;
		$scope.displaySummary = false;
	};

	$scope.saveReport = function() {
		$("#loader").show();
		var ref = $scope.summaryObj;
		var suggestions = [];
		for (var inner=0, innerLen = selectedParams.length; inner<innerLen; inner++) {
			if (ref.values[inner].val) {
				var valueId = selectedParams[inner]._valueMap[""+ref.values[inner].val];
				if (!valueId) {
					dataFactory.toastError("Invalid value for "+selectedParams[inner].name+ " in "+ ref.display);
					$("#loader").hide();
					return;
				}
				ref.values[inner].val = Number(ref.values[inner].val);
				ref.values[inner].label = ""+ref.values[inner].val;
				ref.values[inner].valueId = valueId;
			}
			if (ref.values[inner].remarks[0]) {
				ref.values[inner].remarks[0] = ref.values[inner].remarks[0].toUpperCase();
			}
			if (remarksSuggestions[inner].length>0) {
				suggestions.push({_id: selectedParams[inner]._id, suggestions: selectedParams[inner].notesConfig._suggestions});
			}
		}
		ref.remarks = $scope.displayInvoiceRemark(ref.values);
		var payload = {invoices: $scope.selectedInvoices, summary: $scope.summaryObj, location: userProfile.locationId};
		if (tastingType=="MUSTER") {
			payload.clientId = clientId;
			payload.musterIds = musterIds;
		} else if (tastingType =="AUCTION") {
			payload.auctionId = auctionId;
		}
		if (reportId) {
			payload.reportId = reportId;
		}
		if (suggestions.length>0) {
			payload.suggestions = suggestions;
		}

		dataFactory.post("app/save-tasting-report.json", payload).then(function(data) {
			$("#loader").hide();
			if (data.status) {
				dataFactory.toastSuccess("Record Saved");
				if (!reportId) {
					setTimeout(function() {
						window.location.href = "/tea-tasting.html";
					}, 1000);
				}
			} else {
				dataFactory.toastError(data.msg);
			}
		}, function() {
			dataFactory.toastError("we have encounterd an unexpected error, plesae try after some time.");
			$("#loader").hide();
		});
	};
}]);

// eslint-disable-next-line no-unused-vars
function setUpTastingParams(type, selectedCategory) {
	// console.log(selectedCategory);
	var requiredParams = [];
	var descriptiveRemarks = false;
	var loop =0;
	var length = 0;
	var _requiredParams;
	if (selectedCategory) {
		_requiredParams = categoryMapping[selectedCategory].params;
		for (loop = 0, length = _requiredParams.length; loop < length; loop++) {
			requiredParams.push(_requiredParams[loop]);
		}
		descriptiveRemarks = categoryMapping[selectedCategory].category.descriptiveRemarks;
	} else {
		var allCategories = Object.keys(categoryMapping);
		for (loop=0, length = allCategories.length; loop<length; loop++) {
			var catName = categoryMapping[allCategories[loop]].category.name;
			if (catName=="AUCTION") {
				_requiredParams = categoryMapping[allCategories[loop]].params;
				for (loop=0, length = _requiredParams.length; loop<length; loop++) {
					requiredParams.push(_requiredParams[loop]);
				}
				break;
			}
		}
	}

	var selectedParams = [];
	var filterParams = (requiredParams.length==0)? false: true;
	for (loop=0, length = params.length; loop<length; loop++) {
		var param = params[loop];
		var doCopy = false;
		if (filterParams) {
			if (requiredParams.indexOf(param._id)>=0) {
				doCopy = true;
			}
		} else {
			doCopy = true;
		}
		if (doCopy) {
			var copyParam = JSON.parse(JSON.stringify(param));
			copyParam.descriptiveRemarks = (descriptiveRemarks?true: false);
			selectedParams.push(copyParam);
		}
	}
	return selectedParams;
}
