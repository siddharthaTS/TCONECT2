/* eslint no-unreachable: 0 */
/* eslint no-console: 0 */

const Koa = require("koa");
const Router = require("koa-router");
const Cors = require("@koa/cors");
const BodyParser = require("koa-better-body");
const Helmet = require("koa-helmet");
const respond = require("koa-respond");
const serve = require("koa-static");
const session = require("koa-session");
const views = require("koa-views");
const conditional = require("koa-conditional-get");
const etag = require("koa-etag");
const formidable = require("formidable");


const app = new Koa();

app.use(conditional());
app.use(etag());
app.use(serve("assets", {maxage: 1000 * 60 * 60 * 24 * 15}));
app.use(session({key: "koa.sess", renew: true}, app));
const router = new Router();

icplApp.appPath = __dirname;

const viewUtil = require("./config/view");

// require("./config/email");

app.use(Helmet());

app.use(Cors());

app.use(respond());
const checkLicense = false;
if (checkLicense) {
	const license = require("icpl-license");
	app.context.secret = license.validate();
} else {
	app.context.secret = "7e146918-50f1-406d-9a57-98535a4b9a0c";
}
app.keys = [];
app.keys.push(app.context.secret);

app.use(views("views", {
	map: {
		hbs: "handlebars",
	},
	extension: "hbs",
	options: {
		partials: viewUtil.partials,
		helpers: viewUtil.helpers,
	},
}));
const mobile = require("is-mobile");
app.use(async function(ctx, next) {
	if (!ctx.renderView) {
		ctx.renderView = function(view, viewData) {
			if (!viewData) {
				viewData = {};
			}
			viewData["IS_MOBILE"] = false;
			try {
				viewData["IS_MOBILE"] = mobile({ua: ctx.req, tablet: true, featureDetect: true});
			} catch (err) {
				//
			}
			viewData["view"] = {path: view};
			viewData["icplApp"] = icplApp;
			return ctx.render(view, viewData);
		};
	}
	await next();
});

app.use(async function errorHandler(ctx, next) {
	try {
		await next();
		const status = ctx.status || 404;
		if (status === 404 || status === 403 || status === 500) {
			throw {status: status};
		} else if (status === 405) {
			throw {status: 403};
		}
	} catch (err) {
		if (err.status === 404) {
			ctx.status = err.status;
			switch (ctx.accepts("html", "json")) {
			case "html":
				return ctx.renderView("404");
				break;
			case "json":
				ctx.type = "json";
				ctx.body = {
					status: false,
					msg: "Not Found",
				};
				break;
			default:
				ctx.type = "text";
				ctx.body = "Page Not Found";
			}
		} else if (err.status === 403) {
			ctx.status = 403;
			var redirect = err.redirect;
			if (redirect) {
				return ctx.redirect(redirect);
			}
			switch (ctx.accepts("html", "json")) {
			case "html":
				return ctx.renderView("403");
				break;
			case "json":
				ctx.status = err.contextStatus || 403;
				ctx.type = "json";
				ctx.body = {
					status: false,
					msg: "You don't have permission",
				};
				break;
			default:
				ctx.type = "text";
				ctx.body = "You don't have permission";
			}
		} else {
			console.log(err);
			ctx.status = 500;
			switch (ctx.accepts("html", "json")) {
			case "html":
				return ctx.renderView("500");
				break;
			case "json":
				ctx.type = "json";
				ctx.body = {
					status: false,
					msg: "Internal Server Error",
				};
				break;
			default:
				ctx.type = "text";
				ctx.body = "Internal Server Error";
			}
		}
		return;
	}
});
const path = require("path");
const incomingForm = new formidable.IncomingForm();
incomingForm.uploadDir = path.join(__dirname, "uploads");
incomingForm.keepExtensions = true;

incomingForm.on("error", function() {
});

incomingForm.on("aborted", function() {
});

const convert = require("koa-convert");

app.use(convert(BodyParser({
	jsonLimit: "2mb",
	formLimit: "2mb",
	strict: true,
	IncomingForm: incomingForm,
	onerror: function(err, ctx) {
		throw err;
	},
})));

require("./config/mongoDb")(app);

const Policies = require("./config/policy");
app.use(Policies.policyHandler);

// API routes
require("./routes")(router);
app.use(router.routes());
app.use(router.allowedMethods());

require("./config/misc");

app.on("error", function() {
});
module.exports = app;
